package apicollector.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Montoya-free snapshot of one request/response, copied cheaply on Burp's HTTP thread and parsed
 * later on the capture worker thread. Bodies are raw bytes so nothing is lost to charset guesses;
 * a body is {@code null} when it was absent, too large, or not worth parsing.
 */
public final class RawExchange {
    public String method;
    public boolean secure;
    public String host;
    public int port;
    /** Request path including any query string, exactly as sent. */
    public String path;
    public final List<String[]> requestHeaders = new ArrayList<>();   // {name, value}
    public byte[] requestBody;
    public int requestBodyLength;

    /** 0 when there was no response. */
    public int status;
    public String responseContentType;
    public byte[] responseBody;
    public int responseBodyLength;

    /** scheme://host[:port], port omitted when it is the scheme default. */
    public String origin() {
        String scheme = secure ? "https" : "http";
        String h = host == null ? "" : host.toLowerCase(Locale.ROOT);
        if (h.indexOf(':') >= 0 && !h.startsWith("[")) h = "[" + h + "]";   // bare IPv6
        boolean defaultPort = port <= 0 || (secure && port == 443) || (!secure && port == 80);
        return scheme + "://" + h + (defaultPort ? "" : ":" + port);
    }

    public String requestHeader(String name) {
        for (String[] h : requestHeaders) if (h[0].equalsIgnoreCase(name)) return h[1];
        return null;
    }
}
