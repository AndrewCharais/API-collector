package apicollector.model;

import java.util.LinkedHashSet;
import java.util.Set;

/**
 * A logical endpoint (one origin + normalized shape) plus a representative sample, a hit count and
 * the response statuses seen. Mutated only under CaptureStore's lock; readers get {@link #copy()}s.
 */
public final class Endpoint {
    private static final int MAX_STATUSES = 12;

    public final EndpointShape shape;
    public final String origin;
    public Observation representative;
    public int count;
    public int lastStatus;
    public final Set<Integer> statuses = new LinkedHashSet<>();
    /** True once any response showed the endpoint actually exists (see CoverageTracker#isReachable). */
    public boolean reachable;

    public Endpoint(EndpointShape shape) { this(shape, ""); }
    public Endpoint(EndpointShape shape, String origin) { this.shape = shape; this.origin = origin == null ? "" : origin; }

    /** Fold one observation in. Prefers a representative whose response proved the endpoint reachable. */
    public void observe(Observation o, boolean isReachable) {
        count++;
        lastStatus = o.status;
        if (statuses.size() < MAX_STATUSES) statuses.add(o.status);
        if (representative == null || (isReachable && !reachable)) representative = o;
        reachable |= isReachable;
    }

    /** Same data under a new shape (used when path learning merges endpoints). */
    public Endpoint reshaped(EndpointShape newShape) {
        Endpoint e = new Endpoint(newShape, origin);
        e.mergeFrom(this);
        return e;
    }

    public void mergeFrom(Endpoint other) {
        if (representative == null || (other.reachable && !reachable)) representative = other.representative;
        count += other.count;
        lastStatus = other.lastStatus;
        for (Integer s : other.statuses) if (statuses.size() < MAX_STATUSES) statuses.add(s);
        reachable |= other.reachable;
    }

    public Endpoint copy() { return reshaped(shape); }
}
