package apicollector.model;

import apicollector.core.JsonFlattener;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Montoya-free, fully parsed view of one exchange. Built from a {@link RawExchange} by
 * {@code ObservationBuilder} and handed to {@code CaptureStore}, so all core logic stays testable
 * without Burp.
 */
public final class Observation {
    public enum BodyKind { NONE, JSON, FORM, XML, MULTIPART, TEXT }

    public String method;
    /** scheme://host[:port] the request was sent to. */
    public String origin;
    /** Path only, no query string. */
    public String path;
    /** HTTP status of the response, 0 when there was none. */
    public int status;
    /** Identity of this exchange, used to make proxy-history rescans idempotent. */
    public long fingerprint;

    /** Decoded query parameters (last value wins) — feed the Known Values registry. */
    public final Map<String, String> queryParams    = new LinkedHashMap<>();
    /** Query parameters exactly as sent (still percent-encoded), in order — used for export. */
    public final List<String[]> queryRaw             = new ArrayList<>();
    /** Request body leaves (JSON) or fields (form), last value wins. */
    public final Map<String, String> bodyParams      = new LinkedHashMap<>();
    public final List<JsonFlattener.Leaf> bodyLeaves = new ArrayList<>();
    /** Fields seen in the RESPONSE body. */
    public final Map<String, String> responseParams  = new LinkedHashMap<>();
    /** Every request header as sent ({name, value}); HeaderPolicy decides what is exported. */
    public final List<String[]> headers              = new ArrayList<>();

    public BodyKind bodyKind = BodyKind.NONE;
    /** Request body as text (UTF-8 if valid, else ISO-8859-1), null when absent or too large. */
    public String bodyText;
    /** True when a request body existed but was too large to keep. */
    public boolean bodyTruncated;

    public String header(String name) {
        for (String[] h : headers) if (h[0].equalsIgnoreCase(name)) return h[1];
        return null;
    }
}
