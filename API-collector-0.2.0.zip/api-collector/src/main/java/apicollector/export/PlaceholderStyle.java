package apicollector.export;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Configurable placeholder wrapper. Postman/Bruno use {{name}}; others differ. */
public final class PlaceholderStyle {
    /**
     * Placeholder name: starts with a letter or underscore and does not end in '.' or '-', so
     * {@code :8443} in a URL or a sentence-ending period is never mistaken for a placeholder.
     */
    public static final String NAME = "([A-Za-z_](?:[A-Za-z0-9_.\\-]*[A-Za-z0-9_])?)";

    public final String prefix, suffix;
    private final Pattern pattern;

    public PlaceholderStyle(String prefix, String suffix) {
        this.prefix = prefix == null ? "" : prefix;
        this.suffix = suffix == null ? "" : suffix;
        this.pattern = Pattern.compile(Pattern.quote(this.prefix) + NAME + (this.suffix.isEmpty() ? "" : Pattern.quote(this.suffix)));
    }
    public static final PlaceholderStyle DOUBLE_CURLY = new PlaceholderStyle("{{", "}}");

    public String wrap(String name) { return prefix + name + suffix; }

    /** Compiled once per style; group 1 is the name. */
    public Pattern pattern() { return pattern; }

    /**
     * One pattern matching ANY of the styles, so a multi-format substitution is a single pass and a
     * substituted value is never re-scanned by another format. Use {@link #nameOf} on a match.
     */
    public static Pattern combined(List<PlaceholderStyle> styles) {
        StringBuilder sb = new StringBuilder();
        for (PlaceholderStyle s : styles) {
            if (sb.length() > 0) sb.append('|');
            sb.append("(?:").append(Pattern.quote(s.prefix)).append(NAME)
              .append(s.suffix.isEmpty() ? "" : Pattern.quote(s.suffix)).append(')');
        }
        return Pattern.compile(sb.toString());
    }
    /** The name captured by whichever alternative of a {@link #combined} pattern matched. */
    public static String nameOf(Matcher m) {
        for (int g = 1; g <= m.groupCount(); g++) if (m.group(g) != null) return m.group(g);
        return null;
    }

    @Override public boolean equals(Object o) { return o instanceof PlaceholderStyle p && p.prefix.equals(prefix) && p.suffix.equals(suffix); }
    @Override public int hashCode() { return prefix.hashCode() * 31 + suffix.hashCode(); }
}
