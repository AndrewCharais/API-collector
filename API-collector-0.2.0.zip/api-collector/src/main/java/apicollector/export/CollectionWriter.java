package apicollector.export;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.Map;

/** Writes an exporter's filename->content map under a target directory — and never outside it. */
public final class CollectionWriter {
    public void write(Path dir, Map<String, String> files) throws IOException {
        Path base = dir.toAbsolutePath().normalize();
        for (Map.Entry<String, String> e : files.entrySet()) {
            Path p = base.resolve(e.getKey()).normalize();
            if (!p.startsWith(base) || p.equals(base))
                throw new IOException("Refusing to write outside the export folder: " + e.getKey());
            if (p.getParent() != null) Files.createDirectories(p.getParent());
            Files.writeString(p, e.getValue(), StandardCharsets.UTF_8,
                StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE);
        }
    }
}
