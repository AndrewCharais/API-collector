package apicollector.export;

import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Bruno collection: bruno.json + one .bru per request + environments/<env>.bru.
 * Deliberately a very different on-disk format from Postman, to exercise the IR.
 *
 * <p>Safety: file names are unique per folder (no silent overwrite when two names slug the same),
 * slugs can never be "." or "..", single-line fields have CR/LF flattened so captured values cannot
 * break the .bru grammar, and body lines are indented so a "}" in a body cannot close the block.
 */
public final class BrunoExporter implements CollectionExporter {
    @Override public String id() { return "bruno"; }

    @Override public Map<String, String> export(Collection c, EnvironmentModel env, String baseName) {
        String display = baseName == null || baseName.isBlank() ? c.name : baseName;
        String root = slug(display);
        Map<String, String> out = new LinkedHashMap<>();

        Map<String, Object> meta = new LinkedHashMap<>();
        meta.put("version", "1");
        meta.put("name", display);
        meta.put("type", "collection");
        out.put(root + "/bruno.json", Json.write(meta));

        Set<String> used = new HashSet<>();
        int seq = 1;
        for (Collection.Folder f : c.folders) {
            String dir = slug(f.name);
            for (Collection.Request r : f.requests) {
                String base = root + "/" + dir + "/" + slug(r.name);
                String path = base + ".bru";
                for (int n = 2; !used.add(path.toLowerCase(Locale.ROOT)); n++) path = base + "_" + n + ".bru";
                out.put(path, bru(r, seq++));
            }
        }
        if (env != null) out.put(root + "/environments/" + slug(env.name) + ".bru", envBru(env));
        return out;
    }

    private String bru(Collection.Request r, int seq) {
        StringBuilder b = new StringBuilder();
        b.append("meta {\n")
         .append("  name: ").append(line(r.name)).append("\n")
         .append("  type: http\n")
         .append("  seq: ").append(seq).append("\n}\n\n");

        String method = r.method.toLowerCase(Locale.ROOT);
        b.append(method).append(" {\n")
         .append("  url: ").append(line(fullUrl(r))).append("\n")
         .append("  body: ").append("raw".equals(r.bodyMode) ? r.bodyLanguage : "none").append("\n")
         .append("  auth: none\n}\n\n");

        if (!r.headers.isEmpty()) {
            b.append("headers {\n");
            for (String[] h : r.headers) b.append("  ").append(line(h[0])).append(": ").append(line(h[1])).append("\n");
            b.append("}\n\n");
        }
        if (!r.query.isEmpty()) {
            b.append("params:query {\n");
            for (String[] q : r.query) b.append("  ").append(line(q[0])).append(": ").append(line(q[1])).append("\n");
            b.append("}\n\n");
        }
        if ("raw".equals(r.bodyMode) && r.bodyRaw != null) {
            b.append("body:").append(r.bodyLanguage).append(" {\n").append(indent(r.bodyRaw)).append("\n}\n\n");
        }
        if (r.description != null && !r.description.isBlank()) {
            b.append("docs {\n").append(indent(r.description)).append("\n}\n\n");
        }
        return b.toString().stripTrailing() + "\n";
    }

    private String fullUrl(Collection.Request r) {
        StringBuilder u = new StringBuilder(r.urlTemplate);
        for (int i = 0; i < r.query.size(); i++) {
            u.append(i == 0 && r.urlTemplate.indexOf('?') < 0 ? "?" : "&");
            u.append(r.query.get(i)[0]).append("=").append(r.query.get(i)[1]);
        }
        return u.toString();
    }

    private String envBru(EnvironmentModel env) {
        StringBuilder b = new StringBuilder("vars {\n");
        for (Map.Entry<String, String> e : env.values.entrySet())
            b.append("  ").append(line(e.getKey())).append(": ").append(line(e.getValue())).append("\n");
        b.append("}\n");
        return b.toString();
    }

    /** Single-line field: CR/LF would start a new .bru statement. */
    static String line(String s) { return s == null ? "" : s.replaceAll("[\\r\\n]+", " "); }

    /** Bruno's own writer indents block bodies by two spaces; a "}" line can then never close the block. */
    static String indent(String s) {
        StringBuilder sb = new StringBuilder();
        String[] lines = s.split("\\r?\\n", -1);
        for (int i = 0; i < lines.length; i++) { if (i > 0) sb.append('\n'); sb.append("  ").append(lines[i]); }
        return sb.toString();
    }

    /** File-system safe, never "", "." or "..". */
    static String slug(String s) {
        String out = s == null ? "x" : s.replaceAll("[^A-Za-z0-9._-]+", "_").replaceAll("^[_.]+|_+$", "");
        return out.isEmpty() || out.chars().allMatch(ch -> ch == '.') ? "_" : out;
    }
}
