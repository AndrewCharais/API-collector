package apicollector.export;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Minimal JSON writer + reader (no external dependency).
 *
 * <p>Reader hardening: nesting depth is capped (a hostile response of 20k '[' used to blow the
 * stack), {@code \}u escapes are bounds-checked, and numbers are kept as their exact source text
 * ({@link Num}) so 64-bit IDs such as 1234567890123456789 are never rounded through a double.
 */
public final class Json {
    private Json() {}

    /** Default maximum nesting depth for {@link #read(String)}. */
    public static final int DEFAULT_MAX_DEPTH = 256;

    /** A JSON number, held as its exact lexeme. {@code toString()} returns that lexeme. */
    public static final class Num {
        public final String text;
        public Num(String text) { this.text = text; }
        public double doubleValue() { return Double.parseDouble(text); }
        @Override public String toString() { return text; }
        @Override public boolean equals(Object o) { return o instanceof Num n && n.text.equals(text); }
        @Override public int hashCode() { return text.hashCode(); }
    }

    /** Written verbatim (unquoted), e.g. a {{placeholder}} standing in for a number or boolean. */
    public static final class Raw {
        public final String text;
        public Raw(String text) { this.text = text; }
        @Override public String toString() { return text; }
    }

    // ---------- writer ----------
    public static String write(Object o) { StringBuilder sb = new StringBuilder(); write(o, sb, 0); return sb.toString(); }
    private static void write(Object o, StringBuilder sb, int d) {
        if (o == null) sb.append("null");
        else if (o instanceof String s) str(s, sb);
        else if (o instanceof Num n) sb.append(n.text);
        else if (o instanceof Raw r) sb.append(r.text);
        else if (o instanceof Number || o instanceof Boolean) sb.append(o.toString());
        else if (o instanceof Map<?, ?> m) {
            if (m.isEmpty()) { sb.append("{}"); return; }
            sb.append("{"); int i = 0;
            for (Map.Entry<?, ?> e : m.entrySet()) {
                if (i++ > 0) sb.append(",");
                nl(sb, d + 1); str(String.valueOf(e.getKey()), sb); sb.append(": "); write(e.getValue(), sb, d + 1);
            }
            nl(sb, d); sb.append("}");
        } else if (o instanceof List<?> l) {
            if (l.isEmpty()) { sb.append("[]"); return; }
            sb.append("["); int i = 0;
            for (Object it : l) { if (i++ > 0) sb.append(","); nl(sb, d + 1); write(it, sb, d + 1); }
            nl(sb, d); sb.append("]");
        } else str(o.toString(), sb);
    }
    private static void nl(StringBuilder sb, int n) { sb.append('\n'); for (int i = 0; i < n; i++) sb.append("  "); }
    private static void str(String s, StringBuilder sb) { sb.append('"'); escapeInto(s, sb); sb.append('"'); }

    /** JSON string-content escaping (no surrounding quotes). */
    public static String escape(String s) { StringBuilder sb = new StringBuilder(s.length() + 8); escapeInto(s, sb); return sb.toString(); }
    private static void escapeInto(String s, StringBuilder sb) {
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"' -> sb.append("\\\"");
                case '\\' -> sb.append("\\\\");
                case '\n' -> sb.append("\\n");
                case '\r' -> sb.append("\\r");
                case '\t' -> sb.append("\\t");
                case '\b' -> sb.append("\\b");
                case '\f' -> sb.append("\\f");
                default -> { if (c < 0x20 || c == 0x2028 || c == 0x2029) sb.append(String.format("\\u%04x", (int) c)); else sb.append(c); }
            }
        }
    }

    // ---------- reader ----------
    /** Parse JSON text into Map / List / String / {@link Num} / Boolean / null. Depth-limited. */
    public static Object read(String text) { return read(text, DEFAULT_MAX_DEPTH); }
    public static Object read(String text, int maxDepth) {
        if (text == null) throw new IllegalArgumentException("JSON: null input");
        return new P(text, maxDepth).top();
    }

    @SuppressWarnings("unchecked")
    public static Map<String, Object> readObject(String text) {
        Object o = read(text);
        return o instanceof Map ? (Map<String, Object>) o : new LinkedHashMap<>();
    }

    private static final class P {
        private final String s; private final int maxDepth; private int i; private int depth;
        P(String s, int maxDepth) { this.s = s; this.maxDepth = maxDepth; }
        Object top() { Object v = value(); ws(); return v; }
        private Object value() {
            ws();
            char c = peek();
            return switch (c) {
                case '{' -> object();
                case '[' -> array();
                case '"' -> string();
                case 't', 'f' -> bool();
                case 'n' -> nul();
                default -> number();
            };
        }
        private void enter() { if (++depth > maxDepth) throw err("nesting deeper than " + maxDepth); }
        private Map<String, Object> object() {
            enter();
            Map<String, Object> m = new LinkedHashMap<>(); expect('{'); ws();
            if (peek() == '}') { i++; depth--; return m; }
            while (true) {
                ws(); String k = string(); ws(); expect(':');
                m.put(k, value()); ws();
                char c = next();
                if (c == '}') break;
                if (c != ',') throw err("expected , or }");
            }
            depth--;
            return m;
        }
        private List<Object> array() {
            enter();
            List<Object> a = new ArrayList<>(); expect('['); ws();
            if (peek() == ']') { i++; depth--; return a; }
            while (true) {
                a.add(value()); ws();
                char c = next();
                if (c == ']') break;
                if (c != ',') throw err("expected , or ]");
            }
            depth--;
            return a;
        }
        private String string() {
            expect('"'); StringBuilder b = new StringBuilder();
            while (true) {
                char c = next();
                if (c == '"') break;
                if (c == '\\') {
                    char e = next();
                    switch (e) {
                        case '"' -> b.append('"');   case '\\' -> b.append('\\');
                        case '/' -> b.append('/');   case 'n' -> b.append('\n');
                        case 't' -> b.append('\t');  case 'r' -> b.append('\r');
                        case 'b' -> b.append('\b');  case 'f' -> b.append('\f');
                        case 'u' -> {
                            if (i + 4 > s.length()) throw err("truncated \\u escape");
                            try { b.append((char) Integer.parseInt(s.substring(i, i + 4), 16)); }
                            catch (NumberFormatException nfe) { throw err("bad \\u escape"); }
                            i += 4;
                        }
                        default -> throw err("bad escape");
                    }
                } else b.append(c);
            }
            return b.toString();
        }
        private Num number() {
            int start = i;
            while (i < s.length() && "+-0123456789.eE".indexOf(s.charAt(i)) >= 0) i++;
            String lex = s.substring(start, i);
            if (lex.isEmpty()) throw err("unexpected character");
            try { Double.parseDouble(lex); } catch (NumberFormatException nfe) { throw err("bad number"); }
            return new Num(lex);
        }
        private Boolean bool() {
            if (s.startsWith("true", i)) { i += 4; return Boolean.TRUE; }
            if (s.startsWith("false", i)) { i += 5; return Boolean.FALSE; }
            throw err("bad literal");
        }
        private Object nul() { if (s.startsWith("null", i)) { i += 4; return null; } throw err("bad literal"); }
        private void ws() { while (i < s.length() && Character.isWhitespace(s.charAt(i))) i++; }
        private char peek() { ws(); return i < s.length() ? s.charAt(i) : '\0'; }
        private char next() { if (i >= s.length()) throw err("unexpected end of input"); return s.charAt(i++); }
        private void expect(char c) { ws(); if (next() != c) throw err("expected " + c); }
        private RuntimeException err(String m) { return new IllegalArgumentException("JSON @" + i + ": " + m); }
    }
}
