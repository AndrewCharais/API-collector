package apicollector.burp;

import apicollector.core.CapturePipeline;
import burp.api.montoya.MontoyaApi;
import burp.api.montoya.proxy.ProxyHttpRequestResponse;

import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.IntConsumer;

/**
 * Seed capture from Burp's existing Proxy HTTP history. Call it OFF the Swing thread.
 *
 * <p>Scope, static-asset and CORS-preflight filtering run inside Burp's {@code history(filter)}
 * so only matching items are materialised. Each item is fingerprinted, so a rescan skips
 * exchanges already captured (live or by an earlier scan) instead of double-counting them.
 */
public final class ProxyHistoryImporter {
    public record Result(int matched, int added, int skipped) {}

    public Result importInto(MontoyaApi api, LiveHttpHandler handler, CapturePipeline pipeline,
                             BooleanSupplier cancelled, IntConsumer progress) {
        if (!handler.isEnabled()) return new Result(0, 0, 0);
        List<ProxyHttpRequestResponse> items =
            api.proxy().history(it -> handler.worthCapturing(it.finalRequest()));
        int added = 0, skipped = 0, i = 0;
        for (ProxyHttpRequestResponse it : items) {
            if (cancelled != null && cancelled.getAsBoolean()) break;
            if (pipeline.processNow(ExchangeSnapshots.of(it.finalRequest(), it.response()))) added++;
            else skipped++;   // already captured (or unparseable)
            if (progress != null && (++i % 250 == 0)) progress.accept(i);
        }
        return new Result(items.size(), added, skipped);
    }
}
