package apicollector.burp;

import apicollector.core.CaptureFilter;
import apicollector.model.RawExchange;
import burp.api.montoya.core.ByteArray;
import burp.api.montoya.http.HttpService;
import burp.api.montoya.http.message.HttpHeader;
import burp.api.montoya.http.message.requests.HttpRequest;
import burp.api.montoya.http.message.responses.HttpResponse;

/**
 * Montoya -> {@link RawExchange}. Runs on Burp's HTTP thread, so it only COPIES: headers, the
 * request body (if under the size cap) and the response body only when it might be JSON. All
 * parsing happens later on the capture worker. This is the only Montoya-coupled capture code.
 */
public final class ExchangeSnapshots {
    private ExchangeSnapshots() {}

    public static RawExchange of(HttpRequest req, HttpResponse resp) {
        RawExchange x = new RawExchange();
        x.method = req.method();
        x.path = req.path();
        HttpService svc = req.httpService();
        if (svc != null) { x.secure = svc.secure(); x.host = svc.host(); x.port = svc.port(); }
        for (HttpHeader h : req.headers()) x.requestHeaders.add(new String[]{h.name(), h.value()});

        ByteArray body = req.body();
        x.requestBodyLength = body == null ? 0 : body.length();
        if (CaptureFilter.wantRequestBody(x.requestBodyLength)) x.requestBody = body.getBytes();

        if (resp != null) {
            x.status = resp.statusCode();
            x.responseContentType = resp.headerValue("Content-Type");
            ByteArray rb = resp.body();
            x.responseBodyLength = rb == null ? 0 : rb.length();
            if (CaptureFilter.wantResponseBody(x.responseContentType, x.responseBodyLength)) x.responseBody = rb.getBytes();
        }
        return x;
    }
}
