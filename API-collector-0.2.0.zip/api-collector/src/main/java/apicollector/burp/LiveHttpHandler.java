package apicollector.burp;

import apicollector.core.CaptureFilter;
import apicollector.core.CapturePipeline;
import apicollector.core.CaptureStore;
import apicollector.core.LiveSubstitution;
import apicollector.core.LiveSubstitution.Context;
import apicollector.export.PlaceholderStyle;
import burp.api.montoya.MontoyaApi;
import burp.api.montoya.core.ByteArray;
import burp.api.montoya.core.ToolSource;
import burp.api.montoya.core.ToolType;
import burp.api.montoya.http.handler.*;
import burp.api.montoya.http.message.HttpHeader;
import burp.api.montoya.http.message.requests.HttpRequest;

import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.Pattern;

/**
 * Live capture, plus optional on-the-wire placeholder substitution for API-only testing.
 *
 * <p>Capture records only responses from the tools you choose (Proxy by default) so Scanner /
 * Intruder probes never pollute values or mark endpoints "seen". The Burp thread only snapshots
 * bytes; parsing happens on the {@link CapturePipeline} worker.
 *
 * <p>Auto-fill rewrites the request part by part through Montoya (path, each header, body bytes),
 * encoding every value for where it lands and refusing unsafe ones; {@code withBody} recomputes
 * Content-Length from the real bytes and HTTP/2 / binary bodies are preserved.
 */
public final class LiveHttpHandler implements HttpHandler {
    private final CaptureStore store;
    private final ScopeController scope;
    private final CapturePipeline pipeline;
    private final MontoyaApi api;
    private final LiveSubstitution substitution = new LiveSubstitution();

    private volatile boolean enabled = true;               // capture
    private volatile boolean substituteLive = false;       // rewrite outgoing requests
    private volatile boolean skipStatic = true;            // ignore js/css/images when capturing
    private volatile List<PlaceholderStyle> styles = List.of(PlaceholderStyle.DOUBLE_CURLY);
    private volatile Pattern stylePattern = PlaceholderStyle.combined(styles);
    /** Tools whose outgoing requests get auto-filled. */
    private volatile Set<ToolType> tools = Set.of(ToolType.PROXY, ToolType.REPEATER, ToolType.INTRUDER);
    /** Tools whose responses are captured (and count as "seen"). */
    private volatile Set<ToolType> captureTools = Set.of(ToolType.PROXY);
    private volatile String baseUrlOverride = "";

    public LiveHttpHandler(CaptureStore store, ScopeController scope, CapturePipeline pipeline, MontoyaApi api) {
        this.store = store; this.scope = scope; this.pipeline = pipeline; this.api = api;
    }

    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean e) { this.enabled = e; }
    public boolean isSubstituteLive() { return substituteLive; }
    public void setSubstituteLive(boolean s) { this.substituteLive = s; }
    public void setSkipStatic(boolean s) { this.skipStatic = s; }
    public boolean isSkipStatic() { return skipStatic; }
    public void setPlaceholderStyles(List<PlaceholderStyle> s) {
        if (s != null && !s.isEmpty()) { this.styles = List.copyOf(s); this.stylePattern = PlaceholderStyle.combined(this.styles); }
    }
    public List<PlaceholderStyle> placeholderStyles() { return styles; }
    public void setTools(Set<ToolType> t) { if (t != null) this.tools = Set.copyOf(t); }
    public Set<ToolType> tools() { return tools; }
    public void setCaptureTools(Set<ToolType> t) { if (t != null) this.captureTools = Set.copyOf(t); }
    public Set<ToolType> captureTools() { return captureTools; }
    public void setBaseUrlOverride(String s) { this.baseUrlOverride = s == null ? "" : s.trim(); }
    public String baseUrlOverride() { return baseUrlOverride; }

    /** Shared with the proxy-history importer: in scope, not a static asset, not a CORS preflight. */
    boolean worthCapturing(HttpRequest req) {
        if (req == null || !scope.inScope(req)) return false;
        if ("OPTIONS".equalsIgnoreCase(req.method()) && req.hasHeader("Access-Control-Request-Method")) return false;
        return !(skipStatic && CaptureFilter.isStaticAsset(req.path()));
    }

    // ---------------- capture ----------------
    @Override public ResponseReceivedAction handleHttpResponseReceived(HttpResponseReceived resp) {
        try {
            if (!enabled) return ResponseReceivedAction.continueWith(resp);
            ToolSource src = resp.toolSource();
            if (src == null || !captureTools.contains(src.toolType())) return ResponseReceivedAction.continueWith(resp);
            HttpRequest req = resp.initiatingRequest();
            if (worthCapturing(req)) pipeline.submit(ExchangeSnapshots.of(req, resp));
        } catch (Exception | StackOverflowError e) {
            api.logging().logToError("API Collector capture error", e);
        }
        return ResponseReceivedAction.continueWith(resp);
    }

    // ---------------- auto-fill ----------------
    @Override public RequestToBeSentAction handleHttpRequestToBeSent(HttpRequestToBeSent req) {
        if (!substituteLive) return RequestToBeSentAction.continueWith(req);
        try {
            if (!toolAllowed(req) || !scope.inScope(req) || !mayContainPlaceholder(req))
                return RequestToBeSentAction.continueWith(req);

            Map<String, String> values = store.substitutionValues(baseUrlOverride);
            if (!baseUrlOverride.isBlank()) values.put("baseUrl", baseUrlOverride);
            Pattern pat = stylePattern;
            Set<String> filled = new LinkedHashSet<>(), missing = new LinkedHashSet<>(), rejected = new LinkedHashSet<>();
            HttpRequest out = req;

            // path + query (percent-encoded)
            String full = req.path();
            int q = full.indexOf('?');
            var po = substitution.apply(q >= 0 ? full.substring(0, q) : full, pat, values, Context.PATH);
            var qo = substitution.apply(q >= 0 ? full.substring(q) : "", pat, values, Context.QUERY);
            collect(po, filled, missing, rejected); collect(qo, filled, missing, rejected);
            if (po.changed || qo.changed) out = out.withPath(po.text + qo.text);

            // headers (control characters refused)
            for (HttpHeader h : req.headers()) {
                if (h.name().startsWith(":")) continue;
                var ho = substitution.apply(h.value(), pat, values, Context.HEADER);
                collect(ho, filled, missing, rejected);
                if (ho.changed) out = out.withUpdatedHeader(h.name(), ho.text);
            }

            // body: byte-exact ISO-8859-1 view, values spliced as UTF-8 bytes, Montoya fixes Content-Length
            ByteArray body = req.body();
            if (body != null && body.length() > 0) {
                String te = req.headerValue("Transfer-Encoding");
                if (te != null && te.toLowerCase(Locale.ROOT).contains("chunked")) {
                    api.logging().logToOutput("API Collector: skipped body auto-fill (chunked) for " + req.method() + " " + req.pathWithoutQuery());
                } else if (body.length() <= CaptureFilter.MAX_BODY_BYTES) {
                    String view = new String(body.getBytes(), StandardCharsets.ISO_8859_1);
                    var bo = substitution.apply(view, pat, values, bodyContext(req), true);
                    collect(bo, filled, missing, rejected);
                    if (bo.changed) out = out.withBody(ByteArray.byteArray(bo.text.getBytes(StandardCharsets.ISO_8859_1)));
                }
            }

            if (!rejected.isEmpty())
                api.logging().logToError("API Collector: NOT filled " + rejected + " in " + req.method() + " "
                    + req.pathWithoutQuery() + " — captured value contains control characters (CR/LF) unsafe for that position");
            if (filled.isEmpty()) return RequestToBeSentAction.continueWith(req);
            missing.removeAll(filled);
            api.logging().logToOutput("API Collector: filled " + filled + " in "
                + req.method() + " " + req.pathWithoutQuery()
                + (missing.isEmpty() ? "" : "  (no value yet for " + missing + ")"));
            return RequestToBeSentAction.continueWith(out);
        } catch (Exception | StackOverflowError e) {
            api.logging().logToError("API Collector substitution error", e);
            return RequestToBeSentAction.continueWith(req);
        }
    }

    private static void collect(LiveSubstitution.Outcome o, Set<String> f, Set<String> m, Set<String> r) {
        f.addAll(o.filled); m.addAll(o.missing); r.addAll(o.rejected);
    }

    private static Context bodyContext(HttpRequest req) {
        return switch (req.contentType()) {
            case JSON -> Context.BODY_JSON;
            case URL_ENCODED -> Context.BODY_FORM;
            case XML -> Context.BODY_XML;
            default -> Context.BODY_RAW;
        };
    }

    /** Cheap pre-check so requests without any configured prefix are never rebuilt. */
    private boolean mayContainPlaceholder(HttpRequest req) {
        for (PlaceholderStyle s : styles) if (!s.prefix.isEmpty() && req.contains(s.prefix, true)) return true;
        return false;
    }

    private boolean toolAllowed(HttpRequestToBeSent req) {
        try {
            var src = req.toolSource();
            return src == null || tools.contains(src.toolType());
        } catch (Exception e) { return true; }
    }
}
