package apicollector.core;

import apicollector.model.Endpoint;
import apicollector.model.EndpointShape;

import java.util.*;

/**
 * Expected (from spec) vs observed (from traffic), compared purely on EndpointShape.
 *
 * <p>An endpoint only counts as SEEN when a response showed it exists. One that only ever returned
 * 404 / 405 / 410 / 501 (or no response) is NOT_FOUND and stays on the not-seen deliverable.
 */
public final class CoverageTracker {
    public enum Status { SEEN, NOT_FOUND, NOT_SEEN }

    private final Set<EndpointShape> expected = new LinkedHashSet<>();
    private final Set<EndpointShape> seen     = new LinkedHashSet<>();
    private final Set<EndpointShape> notFound = new LinkedHashSet<>();

    /** Did this response prove the route exists? */
    public static boolean isReachable(int status) {
        return status >= 100 && status != 404 && status != 405 && status != 410 && status != 501;
    }

    public synchronized void addExpected(EndpointShape s) { expected.add(s); }

    public synchronized void markObserved(EndpointShape s, boolean reachable) {
        if (reachable) { seen.add(s); notFound.remove(s); }
        else if (!seen.contains(s)) notFound.add(s);
    }
    /** Back-compat: an observation with a reachable response. */
    public synchronized void markSeen(EndpointShape s) { markObserved(s, true); }

    /** Recompute observed sets from endpoints (after path learning merges shapes). */
    public synchronized void rebuildObserved(Collection<Endpoint> endpoints) {
        seen.clear(); notFound.clear();
        for (Endpoint ep : endpoints) markObserved(ep.shape, ep.reachable);
    }

    public synchronized Status status(EndpointShape s) {
        if (seen.contains(s)) return Status.SEEN;
        if (notFound.contains(s)) return Status.NOT_FOUND;
        return Status.NOT_SEEN;
    }

    public synchronized List<EndpointShape> seenExpected() {
        List<EndpointShape> out = new ArrayList<>();
        for (EndpointShape e : expected) if (seen.contains(e)) out.add(e);
        return out;
    }
    /** Expected endpoints never successfully triggered (includes NOT_FOUND). */
    public synchronized List<EndpointShape> notSeen() {
        List<EndpointShape> out = new ArrayList<>();
        for (EndpointShape e : expected) if (!seen.contains(e)) out.add(e);
        return out;
    }
    public synchronized int expectedCount() { return expected.size(); }
    public synchronized int seenExpectedCount() {
        int n = 0; for (EndpointShape e : expected) if (seen.contains(e)) n++; return n;
    }
    public synchronized int seenCount() { return seen.size(); }
    public synchronized void clearExpected() { expected.clear(); }
    public synchronized void clearSeen() { seen.clear(); notFound.clear(); }
}
