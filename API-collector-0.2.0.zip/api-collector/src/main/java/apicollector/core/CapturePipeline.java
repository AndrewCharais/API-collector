package apicollector.core;

import apicollector.model.RawExchange;

import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.BiConsumer;

/**
 * Moves parsing + recording off Burp's HTTP thread. Burp hands us a cheap {@link RawExchange}
 * snapshot; a single worker builds the Observation and records it. The queue is bounded: when it
 * is full we drop (and count) rather than block Burp's traffic.
 */
public final class CapturePipeline {
    public static final int QUEUE_CAPACITY = 10_000;

    private final CaptureStore store;
    private final ObservationBuilder builder = new ObservationBuilder();
    private final BiConsumer<String, Throwable> errorLog;
    private final AtomicLong dropped = new AtomicLong();
    private final ThreadPoolExecutor exec;

    public CapturePipeline(CaptureStore store, BiConsumer<String, Throwable> errorLog) {
        this.store = store;
        this.errorLog = errorLog == null ? (m, t) -> { } : errorLog;
        this.exec = new ThreadPoolExecutor(1, 1, 0L, TimeUnit.MILLISECONDS,
            new ArrayBlockingQueue<>(QUEUE_CAPACITY),
            r -> { Thread t = new Thread(r, "api-collector-capture"); t.setDaemon(true); return t; },
            (r, e) -> dropped.incrementAndGet());
    }

    /** Non-blocking. Returns false when the exchange was dropped (queue full or shut down). */
    public boolean submit(RawExchange x) {
        if (exec.isShutdown()) return false;
        long before = dropped.get();
        exec.execute(() -> process(x, false));
        return dropped.get() == before;
    }

    /** Synchronous variant for the proxy-history importer (already on its own background thread). */
    public boolean processNow(RawExchange x) { return process(x, true); }

    private boolean process(RawExchange x, boolean skipIfDuplicate) {
        try {
            return store.record(builder.build(x), skipIfDuplicate) != null;
        } catch (Exception | StackOverflowError e) {   // never let hostile input kill the worker
            errorLog.accept("API Collector capture error", e);
            return false;
        }
    }

    public long dropped() { return dropped.get(); }
    public int queued() { return exec.getQueue().size(); }

    public void shutdown() {
        exec.shutdownNow();
    }
}
