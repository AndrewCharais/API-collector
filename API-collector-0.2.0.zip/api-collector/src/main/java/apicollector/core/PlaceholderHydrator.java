package apicollector.core;

import apicollector.export.Json;
import apicollector.export.PlaceholderStyle;

import java.util.*;
import java.util.regex.Matcher;

/**
 * Fills placeholders in an arbitrary collection/text with known values (the inverse of
 * export). Text-level match-and-replace, so it works on any format (Postman JSON, Bruno,
 * raw requests). A placeholder whose name isn't known is left untouched and reported.
 *
 * <p>When the target text is JSON (a Postman collection), values are JSON-string escaped so a
 * captured value containing a quote or newline cannot corrupt the file.
 */
public final class PlaceholderHydrator {
    public static final class Result {
        public final String text;
        public final int replacements;                                // total tokens replaced
        public final Set<String> resolved   = new LinkedHashSet<>();  // distinct names filled
        public final Set<String> unresolved = new LinkedHashSet<>();  // distinct names left as-is
        Result(String text, int replacements) { this.text = text; this.replacements = replacements; }
    }

    public Result hydrate(String text, PlaceholderStyle style, Map<String, String> values) {
        return hydrate(text, style, values, looksLikeJson(text));
    }

    public Result hydrate(String text, PlaceholderStyle style, Map<String, String> values, boolean jsonEscape) {
        if (text == null) return new Result("", 0);
        Matcher m = style.pattern().matcher(text);
        StringBuilder out = new StringBuilder();
        int count = 0;
        Set<String> resolved = new LinkedHashSet<>(), unresolved = new LinkedHashSet<>();
        while (m.find()) {
            String name = m.group(1);
            String val = values.get(name);
            if (val != null) {
                m.appendReplacement(out, Matcher.quoteReplacement(jsonEscape ? Json.escape(val) : val));
                count++; resolved.add(name);
            } else { m.appendReplacement(out, Matcher.quoteReplacement(m.group())); unresolved.add(name); }
        }
        m.appendTail(out);
        Result r = new Result(out.toString(), count);
        r.resolved.addAll(resolved);
        r.unresolved.addAll(unresolved);
        return r;
    }

    static boolean looksLikeJson(String text) {
        if (text == null) return false;
        String t = text.stripLeading();
        return t.startsWith("{") || t.startsWith("[");
    }
}
