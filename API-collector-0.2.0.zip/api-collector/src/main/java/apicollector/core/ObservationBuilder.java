package apicollector.core;

import apicollector.export.Json;
import apicollector.model.Observation;
import apicollector.model.Observation.BodyKind;
import apicollector.model.RawExchange;

import java.util.Locale;

/**
 * {@link RawExchange} -> {@link Observation}. All parsing lives here (off Burp's HTTP thread):
 * query string, JSON / form request bodies, JSON response bodies. Pure — no Montoya types.
 */
public final class ObservationBuilder {
    private final JsonFlattener flattener = new JsonFlattener();

    public Observation build(RawExchange x) {
        Observation o = new Observation();
        o.method = x.method == null ? "GET" : x.method.toUpperCase(Locale.ROOT);
        o.origin = x.origin();
        o.status = x.status;

        String full = x.path == null || x.path.isEmpty() ? "/" : x.path;
        int q = full.indexOf('?');
        o.path = q >= 0 ? full.substring(0, q) : full;
        if (q >= 0) parseQuery(full.substring(q + 1), o);

        for (String[] h : x.requestHeaders) if (!h[0].startsWith(":")) o.headers.add(new String[]{h[0], h[1]});

        String ct = x.requestHeader("Content-Type");
        if (x.requestBody != null) {
            o.bodyText = Text.decodeBody(x.requestBody);
            o.bodyKind = kindOf(ct, o.bodyText);
            switch (o.bodyKind) {
                case JSON -> {
                    Object tree = tryJson(o.bodyText);
                    if (tree != null) {
                        o.bodyLeaves.addAll(flattener.leaves(tree));
                        for (JsonFlattener.Leaf l : o.bodyLeaves) o.bodyParams.put(l.name(), l.value());
                    } else o.bodyKind = BodyKind.TEXT;
                }
                case FORM -> parseForm(o.bodyText, o);
                default -> { }
            }
        } else if (x.requestBodyLength > 0) {
            o.bodyTruncated = true;
            o.bodyKind = kindOf(ct, null);
        }

        if (x.responseBody != null) {
            String text = Text.decodeBody(x.responseBody);
            Object tree = looksLikeJson(text) ? tryJson(text) : null;
            if (tree != null) for (JsonFlattener.Leaf l : flattener.leaves(tree)) o.responseParams.put(l.name(), l.value());
        }

        o.fingerprint = fingerprint(x);
        return o;
    }

    static BodyKind kindOf(String contentType, String body) {
        String ct = contentType == null ? "" : contentType.toLowerCase(Locale.ROOT);
        if (ct.contains("json")) return BodyKind.JSON;
        if (ct.contains("x-www-form-urlencoded")) return BodyKind.FORM;
        if (ct.contains("multipart/")) return BodyKind.MULTIPART;
        if (ct.contains("xml")) return BodyKind.XML;
        if (body != null && looksLikeJson(body)) return BodyKind.JSON;
        return BodyKind.TEXT;
    }

    private static boolean looksLikeJson(String s) {
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (Character.isWhitespace(c)) continue;
            return c == '{' || c == '[';
        }
        return false;
    }

    /** Parse JSON, treating hostile input (too deep, malformed) as "not JSON". */
    private static Object tryJson(String s) {
        try { return Json.read(s); }
        catch (RuntimeException | StackOverflowError notJson) { return null; }
    }

    private static void parseQuery(String qs, Observation o) {
        for (String pair : qs.split("&")) {
            if (pair.isEmpty()) continue;
            int eq = pair.indexOf('=');
            String rawK = eq >= 0 ? pair.substring(0, eq) : pair;
            String rawV = eq >= 0 ? pair.substring(eq + 1) : "";
            o.queryRaw.add(new String[]{rawK, rawV});
            o.queryParams.put(Text.urlDecode(rawK, true), Text.urlDecode(rawV, true));
        }
    }

    private static void parseForm(String body, Observation o) {
        for (String pair : body.split("&")) {
            if (pair.isEmpty()) continue;
            int eq = pair.indexOf('=');
            String k = Text.urlDecode(eq >= 0 ? pair.substring(0, eq) : pair, true);
            String v = Text.urlDecode(eq >= 0 ? pair.substring(eq + 1) : "", true);
            o.bodyParams.put(k.trim(), v);
        }
    }

    /** FNV-1a over the parts that identify an exchange. Same request + same response = same value. */
    static long fingerprint(RawExchange x) {
        long h = 0xcbf29ce484222325L;
        h = mix(h, x.method); h = mix(h, x.origin()); h = mix(h, x.path);
        h = mix(h, x.requestBody); h = mix(h, Integer.toString(x.requestBodyLength));
        h = mix(h, Integer.toString(x.status));
        h = mix(h, x.responseBody); h = mix(h, Integer.toString(x.responseBodyLength));
        return h;
    }
    private static long mix(long h, String s) {
        if (s != null) for (int i = 0; i < s.length(); i++) { h ^= s.charAt(i); h *= 0x100000001b3L; }
        h ^= 0x1f; h *= 0x100000001b3L;
        return h;
    }
    private static long mix(long h, byte[] b) {
        if (b != null) for (byte v : b) { h ^= (v & 0xff); h *= 0x100000001b3L; }
        h ^= 0x1e; h *= 0x100000001b3L;
        return h;
    }
}
