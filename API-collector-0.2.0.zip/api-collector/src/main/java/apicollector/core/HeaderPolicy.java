package apicollector.core;

import apicollector.export.PlaceholderStyle;

import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Which request headers go into an exported collection, and how credentials are templated.
 *
 * <ul>
 *   <li>DROP — transport / browser noise the API client sets itself (Host, Content-Length, sec-*, ...).</li>
 *   <li>CREDENTIAL — Authorization, Cookie and API-key / token / CSRF-style headers: exported as
 *       a placeholder, with the captured value recorded under {@link #varFor}.</li>
 *   <li>LITERAL — everything else (Accept, Content-Type, X-Tenant, ...) exported as captured.</li>
 * </ul>
 */
public final class HeaderPolicy {
    private HeaderPolicy() {}

    public enum Kind { DROP, LITERAL, CREDENTIAL }

    private static final Set<String> DROP = Set.of(
        "host", "content-length", "connection", "keep-alive", "proxy-connection", "transfer-encoding",
        "te", "trailer", "upgrade", "expect", "accept-encoding", "accept-language", "user-agent", "referer",
        "cache-control", "pragma", "if-none-match", "if-modified-since", "if-match", "if-unmodified-since",
        "upgrade-insecure-requests", "priority", "dnt", "purpose", "x-requested-with-app");
    private static final Pattern CREDENTIAL_NAME = Pattern.compile(
        "(?i).*(api[-_]?key|token|csrf|xsrf|session|secret|auth).*");

    public static Kind classify(String name) {
        if (name == null || name.isEmpty() || name.startsWith(":")) return Kind.DROP;
        String n = name.toLowerCase(Locale.ROOT);
        if (DROP.contains(n) || n.startsWith("sec-") || n.startsWith("proxy-")) return Kind.DROP;
        if (n.equals("authorization") || n.equals("cookie") || CREDENTIAL_NAME.matcher(n).matches()) return Kind.CREDENTIAL;
        return Kind.LITERAL;
    }

    /** Variable that holds a credential header's value: accessToken / basicAuth / authorization / cookie / xCsrfToken. */
    public static String varFor(String name, String value) {
        String n = name.toLowerCase(Locale.ROOT);
        if (n.equals("authorization")) {
            String scheme = scheme(value);
            if (scheme.equalsIgnoreCase("bearer")) return "accessToken";
            if (scheme.equalsIgnoreCase("basic")) return "basicAuth";
            return "authorization";
        }
        if (n.equals("cookie")) return "cookie";
        return camel(name);
    }

    /** The part of the header value stored in the variable (the token without its "Bearer " scheme). */
    public static String credentialValue(String name, String value) {
        if (!name.equalsIgnoreCase("authorization") || value == null) return value;
        String scheme = scheme(value);
        if (scheme.equalsIgnoreCase("bearer") || scheme.equalsIgnoreCase("basic")) return value.substring(scheme.length()).trim();
        return value;
    }

    /** Exported header value: "Bearer {{accessToken}}", "{{cookie}}", "{{xCsrfToken}}", ... */
    public static String templated(String name, String value, PlaceholderStyle ph) {
        String var = varFor(name, value);
        if (name.equalsIgnoreCase("authorization")) {
            String scheme = scheme(value);
            if (var.equals("accessToken") || var.equals("basicAuth")) return scheme + " " + ph.wrap(var);
        }
        return ph.wrap(var);
    }

    private static String scheme(String value) {
        if (value == null) return "";
        String v = value.trim();
        int sp = v.indexOf(' ');
        return sp > 0 ? v.substring(0, sp) : "";
    }

    /** "X-CSRF-Token" -> "xCsrfToken". */
    static String camel(String header) {
        StringBuilder sb = new StringBuilder();
        boolean up = false;
        for (char c : header.toCharArray()) {
            if (!Character.isLetterOrDigit(c)) { up = sb.length() > 0; continue; }
            if (sb.length() == 0) sb.append(Character.toLowerCase(c));
            else if (up) { sb.append(Character.toUpperCase(c)); up = false; }
            else sb.append(Character.toLowerCase(c));
        }
        return sb.length() == 0 ? "header" : sb.toString();
    }
}
