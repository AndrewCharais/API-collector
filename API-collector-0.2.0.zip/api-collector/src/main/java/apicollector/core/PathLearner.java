package apicollector.core;

import apicollector.model.EndpointShape;

import java.util.*;
import java.util.regex.Pattern;

/**
 * Learns identifier positions from cardinality, catching IDs the regex heuristic is too
 * conservative for (short codes like {@code A7K2Q9}, slugs with digits).
 *
 * <p>A slot is identified by the shaped prefix before it plus the total segment count, so
 * {@code /orders/A7K2Q9} and {@code /orders/B8L3R0/items} are different slots. Once
 * {@link #threshold} distinct <em>value-like</em> literals (containing a digit, not a version like
 * {@code v2}) are seen in one slot, that slot collapses to {@link EndpointShape#PARAM}. Plain words
 * never count, so {@code /api/users} and {@code /api/orders} are never merged.
 */
public final class PathLearner {
    private static final Pattern VERSION = Pattern.compile("(?i)^v\\d+(\\.\\d+)*$");
    private static final Pattern HAS_DIGIT = Pattern.compile(".*\\d.*");

    private final int threshold;
    private final Map<String, Set<String>> candidates = new HashMap<>();
    private final Set<String> variable = new HashSet<>();

    public PathLearner() { this(4); }
    public PathLearner(int threshold) { this.threshold = Math.max(2, threshold); }

    /** Collapse every slot already learned to be variable. */
    public EndpointShape apply(EndpointShape shape) {
        if (variable.isEmpty()) return shape;
        List<String> segs = shape.segments();
        List<String> out = new ArrayList<>(segs.size());
        boolean changed = false;
        for (int i = 0; i < segs.size(); i++) {
            String s = segs.get(i);
            if (!EndpointShape.PARAM.equals(s) && variable.contains(key(out, i, segs.size()))) {
                out.add(EndpointShape.PARAM); changed = true;
            } else out.add(s);
        }
        return changed ? new EndpointShape(shape.method(), out) : shape;
    }

    /** Record the literals of an (already applied) shape. Returns true if a new slot became variable. */
    public boolean observe(EndpointShape shape) {
        List<String> segs = shape.segments();
        boolean learned = false;
        for (int i = 0; i < segs.size(); i++) {
            String s = segs.get(i);
            if (EndpointShape.PARAM.equals(s) || !valueLike(s)) continue;
            String k = key(segs.subList(0, i), i, segs.size());
            if (variable.contains(k)) continue;
            Set<String> seen = candidates.computeIfAbsent(k, x -> new HashSet<>());
            seen.add(s);
            if (seen.size() >= threshold) { variable.add(k); candidates.remove(k); learned = true; }
        }
        return learned;
    }

    public void clear() { candidates.clear(); variable.clear(); }

    static boolean valueLike(String seg) {
        if (seg.contains("@")) return true;
        return HAS_DIGIT.matcher(seg).matches() && !VERSION.matcher(seg).matches();
    }

    private static String key(List<String> prefix, int idx, int total) {
        return String.join("/", prefix) + "|" + idx + "|" + total;
    }
}
