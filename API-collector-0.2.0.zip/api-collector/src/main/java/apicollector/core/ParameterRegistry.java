package apicollector.core;

import java.util.*;

/**
 * name -> distinct observed values (with provenance) + a user-selectable "active" value.
 * Backs the Known Values tab, live auto-fill and the exported environment file.
 *
 * <p>Bounded: at most {@link #MAX_VALUES_PER_NAME} values per name (least-recently-seen evicted,
 * the active value is never evicted) and {@link #MAX_SOURCES_PER_VALUE} sources per value, so a
 * 10k-item list response does not grow memory forever.
 *
 * <p>Source prefixes: {@code req:} request field, {@code resp:} response field, {@code path:}
 * path segment, {@code hdr:} credential header.
 */
public final class ParameterRegistry {
    public static final int MAX_VALUES_PER_NAME = 50;
    public static final int MAX_SOURCES_PER_VALUE = 20;

    public static final class Value {
        public final String value;
        public final Set<String> sources = new LinkedHashSet<>(); // e.g. "resp:GET /users/{}"
        public Value(String value) { this.value = value; }
    }

    /** Immutable row for the UI, built under one lock. */
    public record Row(String name, String active, int count, String sources, boolean pinned, boolean waiting) {}

    private final Map<String, LinkedHashMap<String, Value>> byName = new LinkedHashMap<>();
    private final Map<String, String> active = new LinkedHashMap<>();
    /** Where each active value came from — auto-refresh only accepts a newer value from the SAME call. */
    private final Map<String, String> activeSource = new LinkedHashMap<>();
    /** Placeholder names a loaded collection needs — shown even before a value is captured. */
    private final Set<String> wanted = new LinkedHashSet<>();
    /** Names the user chose explicitly — never auto-overwritten. */
    private final Set<String> pinned = new LinkedHashSet<>();
    /** When true, a newly captured value replaces the active one (e.g. refreshed auth tokens). */
    private volatile boolean autoRefresh = true;

    public synchronized void record(String name, String value, String source) {
        if (name == null || name.isBlank() || value == null || value.isEmpty() || source == null) return;
        var vals = byName.computeIfAbsent(name, k -> new LinkedHashMap<>());
        Value v = vals.remove(value);                 // re-insert = most recently seen
        if (v == null) v = new Value(value);
        vals.put(value, v);
        if (v.sources.size() < MAX_SOURCES_PER_VALUE) v.sources.add(source);
        evict(name, vals);

        if (!active.containsKey(name)) {                       // first sighting wins the slot
            active.put(name, value);
            activeSource.put(name, source);
        } else if (autoRefresh && !pinned.contains(name)
                   && source.equals(activeSource.get(name))) {  // same call returned a new value
            active.put(name, value);                            // e.g. re-login -> fresh token
        }
        // a same-named field from a DIFFERENT call is recorded but never steals the active slot
    }

    private void evict(String name, LinkedHashMap<String, Value> vals) {
        if (vals.size() <= MAX_VALUES_PER_NAME) return;
        String keep = active.get(name);
        for (Iterator<String> it = vals.keySet().iterator(); it.hasNext() && vals.size() > MAX_VALUES_PER_NAME; ) {
            String k = it.next();
            if (!k.equals(keep)) it.remove();
        }
    }

    /** Register a placeholder the loaded collection needs. Appears in the table as "waiting". */
    public synchronized void markWanted(String name) { if (name != null && !name.isBlank()) wanted.add(name); }
    public synchronized void clearWanted() { wanted.clear(); }
    public synchronized boolean isWanted(String name) { return wanted.contains(name); }
    public synchronized Set<String> wanted() { return new LinkedHashSet<>(wanted); }
    /** Wanted names that still have no captured value. */
    public synchronized List<String> missing() {
        List<String> out = new ArrayList<>();
        for (String w : wanted) if (!byName.containsKey(w)) out.add(w);
        return out;
    }

    /** Captured names plus any wanted-but-not-yet-captured names. */
    public synchronized List<String> names() {
        LinkedHashSet<String> all = new LinkedHashSet<>(byName.keySet());
        all.addAll(wanted);
        return new ArrayList<>(all);
    }
    public synchronized int nameCount() {
        int n = byName.size();
        for (String w : wanted) if (!byName.containsKey(w)) n++;
        return n;
    }
    public synchronized List<Value> valuesOf(String name) {
        var v = byName.get(name); return v == null ? List.of() : new ArrayList<>(v.values());
    }
    public synchronized List<String> valueStrings(String name) {
        var v = byName.get(name); return v == null ? List.of() : new ArrayList<>(v.keySet());
    }

    /** True if {@code value} was seen for {@code name} from a source starting with one of the prefixes. */
    public synchronized boolean seenFrom(String name, String value, String... prefixes) {
        var vals = byName.get(name);
        if (vals == null) return false;
        Value v = vals.get(value);
        if (v == null) return false;
        for (String s : v.sources) for (String p : prefixes) if (s.startsWith(p)) return true;
        return false;
    }

    public synchronized String active(String name) { return active.get(name); }
    public synchronized void setActive(String name, String value) {
        if (byName.containsKey(name) && byName.get(name).containsKey(value)) {
            active.put(name, value);
            var v = byName.get(name).get(value);
            if (v != null && !v.sources.isEmpty()) activeSource.put(name, v.sources.iterator().next());
            pinned.add(name); // explicit choice wins over auto-refresh
        }
    }
    public synchronized boolean isPinned(String name) { return pinned.contains(name); }
    public synchronized void unpin(String name) { pinned.remove(name); }
    public void setAutoRefresh(boolean b) { this.autoRefresh = b; }
    public boolean autoRefresh() { return autoRefresh; }
    public synchronized String activeSource(String name) { return activeSource.get(name); }
    public synchronized Map<String, String> activeSnapshot() { return new LinkedHashMap<>(active); }
    public synchronized boolean knows(String name) { return byName.containsKey(name); }

    /** Every row the Known Values table shows, in one consistent snapshot. */
    public synchronized List<Row> rows() {
        List<Row> out = new ArrayList<>();
        for (String n : names()) {
            var vals = byName.get(n);
            int count = vals == null ? 0 : vals.size();
            String src = "";
            if (vals != null) {
                Set<String> s = new LinkedHashSet<>();
                for (Value v : vals.values()) { s.addAll(v.sources); if (s.size() > 8) break; }
                List<String> l = new ArrayList<>(s);
                src = String.join(", ", l.subList(0, Math.min(8, l.size()))) + (l.size() > 8 ? ", …" : "");
            }
            out.add(new Row(n, active.get(n), count, src, pinned.contains(n), !active.containsKey(n)));
        }
        return out;
    }

    public synchronized void clear() { byName.clear(); active.clear(); activeSource.clear(); pinned.clear(); }
    public synchronized void clearAllIncludingWanted() { clear(); wanted.clear(); }
}
