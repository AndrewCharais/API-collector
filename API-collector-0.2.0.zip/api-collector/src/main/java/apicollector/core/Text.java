package apicollector.core;

import java.io.IOException;
import java.net.URLDecoder;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.Charset;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/** Charset-safe text helpers. */
public final class Text {
    private Text() {}

    /** Strict UTF-8 decode, falling back to the given charset when the bytes are not valid UTF-8. */
    public static String decode(byte[] bytes, Charset fallback) {
        if (bytes == null) return null;
        try {
            return StandardCharsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT)
                .decode(ByteBuffer.wrap(bytes)).toString();
        } catch (CharacterCodingException notUtf8) {
            return new String(bytes, fallback);
        }
    }

    /** HTTP bodies: UTF-8 if valid, else ISO-8859-1 (byte-preserving). */
    public static String decodeBody(byte[] bytes) { return decode(bytes, StandardCharsets.ISO_8859_1); }

    /**
     * Read a user-supplied text file: UTF-8 (BOM stripped) if valid, else Windows-1252 — which is
     * what Excel writes when it saves CSV on Windows. Never throws MalformedInputException.
     */
    public static String readFile(Path p) throws IOException {
        byte[] b = Files.readAllBytes(p);
        String s = decode(b, Charset.forName("windows-1252"));
        return s.startsWith("﻿") ? s.substring(1) : s;
    }

    /** Percent-decode leniently: a malformed escape leaves the input as-is rather than throwing. */
    public static String urlDecode(String s, boolean plusIsSpace) {
        if (s == null) return null;
        String in = plusIsSpace ? s : s.replace("+", "%2B");
        try { return URLDecoder.decode(in, StandardCharsets.UTF_8); }
        catch (IllegalArgumentException bad) { return s; }
    }

    /** Percent-encode everything except RFC 3986 unreserved characters (safe in a path segment or query value). */
    public static String percentEncode(String s) {
        StringBuilder sb = new StringBuilder();
        for (byte b : s.getBytes(StandardCharsets.UTF_8)) {
            int c = b & 0xff;
            if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9')
                || c == '-' || c == '.' || c == '_' || c == '~') sb.append((char) c);
            else sb.append('%').append(Character.toUpperCase(Character.forDigit(c >> 4, 16)))
                   .append(Character.toUpperCase(Character.forDigit(c & 0xf, 16)));
        }
        return sb.toString();
    }

    /** True if the string contains a control character (CR, LF, NUL, ...). Tab is allowed only if {@code allowTab}. */
    public static boolean hasControlChars(String s, boolean allowTab) {
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if ((c < 0x20 && !(allowTab && c == '\t')) || c == 0x7f || c == 0x85 || c == 0x2028 || c == 0x2029) return true;
        }
        return false;
    }

    /** Map a Java string to a String whose chars are its UTF-8 bytes (for splicing into an ISO-8859-1 byte view). */
    public static String utf8AsLatin1(String s) {
        return new String(s.getBytes(StandardCharsets.UTF_8), StandardCharsets.ISO_8859_1);
    }
}
