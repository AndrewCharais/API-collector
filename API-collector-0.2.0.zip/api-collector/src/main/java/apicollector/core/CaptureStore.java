package apicollector.core;

import apicollector.model.Endpoint;
import apicollector.model.EndpointShape;
import apicollector.model.Observation;

import java.util.*;

/**
 * Central, thread-safe state tying grouping + coverage + known-values together.
 * Montoya-free: fed Observation DTOs. This is the object the UI tabs read from.
 *
 * <p>Endpoints are keyed by origin + shape (so two hosts never merge); coverage is keyed by
 * shape only (a spec has no host). Readers get copies, never live objects.
 */
public final class CaptureStore {
    /** Fingerprints remembered for history-import dedupe. */
    static final int MAX_FINGERPRINTS = 200_000;

    private record Key(String origin, EndpointShape shape) {}

    private final PathNormalizer norm;
    private final PathLearner learner;
    private Map<Key, Endpoint> endpoints = new LinkedHashMap<>();
    private final ParameterRegistry params = new ParameterRegistry();
    private final CoverageTracker coverage = new CoverageTracker();
    private final LinkedHashSet<Long> fingerprints = new LinkedHashSet<>();
    private final Map<String, Integer> originHits = new LinkedHashMap<>();
    private volatile long version;
    private volatile LoadedCollection collection;

    public CaptureStore() { this(new PathNormalizer()); }
    public CaptureStore(PathNormalizer norm) { this(norm, new PathLearner()); }
    public CaptureStore(PathNormalizer norm, PathLearner learner) { this.norm = norm; this.learner = learner; }

    public Endpoint record(Observation o) { return record(o, false); }

    /**
     * Record one observation. With {@code skipIfDuplicate} (proxy-history import) an exchange whose
     * fingerprint was already recorded is ignored, so rescans never double-count.
     *
     * @return a copy of the updated endpoint, or null if skipped.
     */
    public synchronized Endpoint record(Observation o, boolean skipIfDuplicate) {
        if (o == null) return null;
        boolean fresh = fingerprints.add(o.fingerprint);
        if (!fresh && skipIfDuplicate) return null;
        if (fresh && fingerprints.size() > MAX_FINGERPRINTS) {
            Iterator<Long> it = fingerprints.iterator(); it.next(); it.remove();
        }

        EndpointShape shape = learner.apply(norm.shapeObserved(o.method, o.path));
        if (learner.observe(shape)) { shape = learner.apply(shape); relearn(); }

        boolean reachable = CoverageTracker.isReachable(o.status);
        String origin = o.origin == null ? "" : o.origin;
        Endpoint ep = endpoints.computeIfAbsent(new Key(origin, shape), k -> new Endpoint(k.shape(), k.origin()));
        ep.observe(o, reachable);
        coverage.markObserved(shape, reachable);
        originHits.merge(origin, 1, Integer::sum);

        recordPathParams(shape, o.path);
        String src = "req:" + shape.canonical();
        o.queryParams.forEach((k, v) -> params.record(k, v, src));
        o.bodyParams.forEach((k, v)  -> params.record(k, v, src));
        // response fields are the important ones (order_id needed as input elsewhere)
        String rsrc = "resp:" + shape.canonical();
        o.responseParams.forEach((k, v) -> params.record(k, v, rsrc));
        // credentials: a constant source per header, so a fresh token always refreshes the active one
        for (String[] h : o.headers) {
            if (HeaderPolicy.classify(h[0]) != HeaderPolicy.Kind.CREDENTIAL) continue;
            params.record(HeaderPolicy.varFor(h[0], h[1]), HeaderPolicy.credentialValue(h[0], h[1]), "hdr:" + h[0]);
        }
        version++;
        return ep.copy();
    }

    private void recordPathParams(EndpointShape shape, String path) {
        List<String> concrete = split(path);
        List<String> shaped = shape.segments();
        for (int i = 0; i < shaped.size() && i < concrete.size(); i++) {
            if (EndpointShape.PARAM.equals(shaped.get(i))) {
                params.record(PathParamNamer.nameFor(shaped, i), Text.urlDecode(concrete.get(i), false), "path:" + shape.canonical());
            }
        }
    }

    /** A slot just became variable: re-key every endpoint and merge the ones that now collide. */
    private void relearn() {
        Map<Key, Endpoint> merged = new LinkedHashMap<>();
        for (Endpoint ep : endpoints.values()) {
            EndpointShape ns = learner.apply(ep.shape);
            Key k = new Key(ep.origin, ns);
            Endpoint into = merged.get(k);
            if (into == null) merged.put(k, ns.equals(ep.shape) ? ep : ep.reshaped(ns));
            else into.mergeFrom(ep);
            if (!ns.equals(ep.shape) && ep.representative != null) recordPathParams(ns, ep.representative.path);
        }
        endpoints = merged;
        coverage.rebuildObserved(endpoints.values());
    }

    public synchronized void importExpected(String method, String path) {
        coverage.addExpected(norm.shapeExpected(method, path));
        version++;
    }

    /** The client-provided collection being hydrated, if one is loaded. */
    public LoadedCollection collection() { return collection; }

    public synchronized void loadCollection(LoadedCollection lc) {
        this.collection = lc;
        params.clearWanted();
        if (lc != null) for (String n : lc.placeholderNames()) params.markWanted(n);
        version++;
    }
    public synchronized void unloadCollection() { this.collection = null; params.clearWanted(); version++; }

    /** Bumped on every mutation so the UI can refresh only when something actually changed. */
    public long version() { return version; }
    /** For UI-side changes that live outside the store (e.g. pin/unpin). */
    public void touch() { version++; }

    /** Forget captured traffic (endpoints + known values + seen marks); keeps the imported list. */
    public synchronized void clearCaptured() {
        endpoints.clear(); params.clear(); coverage.clearSeen(); fingerprints.clear(); originHits.clear();
        learner.clear(); version++;
    }
    /** Forget the imported expected-endpoint list; keeps captured traffic. */
    public synchronized void clearExpected() { coverage.clearExpected(); version++; }

    public synchronized void clearAll() {
        clearCaptured(); coverage.clearExpected();
        collection = null; params.clearWanted();   // a full reset drops the loaded client collection too
        version++;
    }

    /** Copies — safe to read without the lock. */
    public synchronized List<Endpoint> endpoints() {
        List<Endpoint> out = new ArrayList<>(endpoints.size());
        for (Endpoint e : endpoints.values()) out.add(e.copy());
        return out;
    }
    public synchronized int endpointCount() { return endpoints.size(); }

    /** Hits per shape summed across origins (coverage table). */
    public synchronized Map<EndpointShape, Integer> hitsByShape() {
        Map<EndpointShape, Integer> m = new HashMap<>();
        for (Endpoint e : endpoints.values()) m.merge(e.shape, e.count, Integer::sum);
        return m;
    }
    /** Last status per shape (coverage table). */
    public synchronized Map<EndpointShape, Integer> lastStatusByShape() {
        Map<EndpointShape, Integer> m = new HashMap<>();
        for (Endpoint e : endpoints.values()) m.put(e.shape, e.lastStatus);
        return m;
    }

    /**
     * One base-URL variable per captured origin, most-hit first: {@code baseUrl}, then
     * {@code baseUrl_auth_client_com}, ... A non-blank override replaces the primary value.
     */
    public synchronized LinkedHashMap<String, String> baseUrlVars(String override) {
        String ov = override == null ? "" : override.trim();
        while (ov.endsWith("/")) ov = ov.substring(0, ov.length() - 1);
        LinkedHashMap<String, String> out = new LinkedHashMap<>();
        for (Map.Entry<String, String> e : originVarNames().entrySet())
            out.put(e.getValue(), out.isEmpty() && !ov.isEmpty() ? ov : e.getKey());
        if (out.isEmpty() && !ov.isEmpty()) out.put("baseUrl", ov);
        return out;
    }

    /** origin -> base-URL variable name, most-hit origin first (that one is {@code baseUrl}). */
    public synchronized LinkedHashMap<String, String> originVarNames() {
        List<Map.Entry<String, Integer>> byHits = new ArrayList<>(originHits.entrySet());
        byHits.removeIf(e -> e.getKey().isEmpty());
        byHits.sort((a, b) -> Integer.compare(b.getValue(), a.getValue()));
        LinkedHashMap<String, String> out = new LinkedHashMap<>();
        Set<String> used = new HashSet<>();
        for (Map.Entry<String, Integer> e : byHits) {
            String var = used.isEmpty() ? "baseUrl" : "baseUrl_" + hostLabel(e.getKey());
            String v = var;
            for (int n = 2; used.contains(v); n++) v = var + "_" + n;
            used.add(v);
            out.put(e.getKey(), v);
        }
        return out;
    }
    static String hostLabel(String origin) {
        String h = origin.replaceFirst("^[a-zA-Z]+://", "");
        return h.replaceAll("[^A-Za-z0-9]+", "_").replaceAll("^_+|_+$", "");
    }

    /** Values for live auto-fill: active known values plus base URLs (override wins for baseUrl). */
    public Map<String, String> substitutionValues(String baseUrlOverride) {
        Map<String, String> values = new LinkedHashMap<>(params.activeSnapshot());
        baseUrlVars(baseUrlOverride).forEach(values::putIfAbsent);
        return values;
    }

    public ParameterRegistry params()  { return params; }
    public CoverageTracker coverage()  { return coverage; }

    private static List<String> split(String p) {
        List<String> out = new ArrayList<>();
        if (p == null) return out;
        int q = p.indexOf('?'); if (q >= 0) p = p.substring(0, q);
        for (String s : p.split("/")) if (!s.isEmpty()) out.add(s);
        return out;
    }
}
