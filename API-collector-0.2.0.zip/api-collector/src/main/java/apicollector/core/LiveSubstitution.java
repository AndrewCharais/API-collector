package apicollector.core;

import apicollector.export.Json;
import apicollector.export.PlaceholderStyle;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * On-the-wire placeholder substitution for API-only testing (no web UI to walk).
 * You fire a request containing {{orderId}} from Postman/Repeater; this swaps in the value
 * captured from an earlier response before the request leaves Burp.
 *
 * <p>Values come from the target's own responses, so they are untrusted. Each value is encoded
 * for the part of the request it lands in, and refused where encoding cannot make it safe:
 * <ul>
 *   <li>{@link Context#PATH} / {@link Context#QUERY}: percent-encoded (no spaces, '&', '#', CRLF).</li>
 *   <li>{@link Context#HEADER}: refused if it contains any control character (CR/LF = header injection).</li>
 *   <li>{@link Context#BODY_JSON}: JSON-string escaped. {@link Context#BODY_FORM}: form-encoded.
 *       {@link Context#BODY_XML}: XML-escaped. {@link Context#BODY_RAW}: refused if it has control chars.</li>
 * </ul>
 * All configured formats are matched in ONE pass, so a substituted value is never re-scanned.
 * Pure string work (no Burp) — the Burp handler applies it per request part and lets Montoya
 * recompute Content-Length.
 */
public final class LiveSubstitution {
    public enum Context { PATH, QUERY, HEADER, BODY_JSON, BODY_FORM, BODY_XML, BODY_RAW }

    public static final class Outcome {
        public final String text;                // rewritten text
        public final boolean changed;
        public final Set<String> filled;         // placeholder names substituted
        public final Set<String> missing;        // placeholders with no value yet
        public final Set<String> rejected;       // values refused as unsafe for this context
        Outcome(String text, boolean changed, Set<String> filled, Set<String> missing, Set<String> rejected) {
            this.text = text; this.changed = changed; this.filled = filled; this.missing = missing; this.rejected = rejected;
        }
    }

    /** Substitute using a pattern from {@link PlaceholderStyle#combined}. */
    public Outcome apply(String text, Pattern combined, Map<String, String> values, Context ctx) {
        return apply(text, combined, values, ctx, false);
    }

    /**
     * @param byteView true when {@code text} is an ISO-8859-1 view of raw bytes (a request body):
     *                 substituted values are then spliced in as their UTF-8 bytes, so the body
     *                 stays byte-exact and Content-Length can be computed from real bytes.
     */
    public Outcome apply(String text, Pattern combined, Map<String, String> values, Context ctx, boolean byteView) {
        Set<String> filled = new LinkedHashSet<>(), missing = new LinkedHashSet<>(), rejected = new LinkedHashSet<>();
        if (text == null || text.isEmpty() || combined == null) return new Outcome(text, false, filled, missing, rejected);
        Matcher m = combined.matcher(text);
        StringBuilder out = null;
        int last = 0;
        while (m.find()) {
            String name = PlaceholderStyle.nameOf(m);
            String val = name == null ? null : values.get(name);
            if (val == null) { missing.add(name); continue; }
            String enc = encode(val, ctx);
            if (enc == null) { rejected.add(name); continue; }
            if (byteView) enc = Text.utf8AsLatin1(enc);
            if (out == null) out = new StringBuilder(text.length() + 32);
            out.append(text, last, m.start()).append(enc);
            last = m.end();
            filled.add(name);
        }
        if (out == null) return new Outcome(text, false, filled, missing, rejected);
        out.append(text, last, text.length());
        return new Outcome(out.toString(), true, filled, missing, rejected);
    }

    /** Convenience for one style. */
    public Outcome apply(String text, PlaceholderStyle style, Map<String, String> values, Context ctx) {
        return apply(text, PlaceholderStyle.combined(List.of(style)), values, ctx);
    }

    /** Encode a value for its destination, or null when it cannot be made safe there. */
    public static String encode(String v, Context ctx) {
        return switch (ctx) {
            case PATH, QUERY -> Text.percentEncode(v);
            case HEADER      -> Text.hasControlChars(v, true) ? null : v;
            case BODY_JSON   -> Json.escape(v);
            case BODY_FORM   -> URLEncoder.encode(v, StandardCharsets.UTF_8);
            case BODY_XML    -> xmlEscape(v);
            case BODY_RAW    -> Text.hasControlChars(v, true) ? null : v;
        };
    }

    private static String xmlEscape(String s) {
        StringBuilder sb = new StringBuilder(s.length() + 16);
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '&' -> sb.append("&amp;"); case '<' -> sb.append("&lt;"); case '>' -> sb.append("&gt;");
                case '"' -> sb.append("&quot;"); case '\'' -> sb.append("&apos;");
                default -> { if (c < 0x20 && c != '\t' && c != '\n' && c != '\r') sb.append("&#").append((int) c).append(';'); else sb.append(c); }
            }
        }
        return sb.toString();
    }
}
