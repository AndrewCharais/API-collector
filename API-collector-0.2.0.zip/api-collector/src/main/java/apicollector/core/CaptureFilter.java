package apicollector.core;

import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Pure decisions about what is worth capturing and parsing. Shared by live capture and history import. */
public final class CaptureFilter {
    private CaptureFilter() {}

    /** Bodies larger than this are neither parsed nor kept (requests or responses). */
    public static final int MAX_BODY_BYTES = 2 * 1024 * 1024;

    private static final Set<String> STATIC_EXT = Set.of(
        "js", "mjs", "css", "png", "jpg", "jpeg", "gif", "svg", "ico", "woff", "woff2", "ttf", "otf",
        "eot", "map", "webp", "avif", "bmp", "mp4", "webm", "mp3", "wav", "pdf");

    /** True when the exchange should not be recorded at all. */
    public static boolean skip(String method, String path, List<String[]> requestHeaders, boolean skipStatic) {
        if (isCorsPreflight(method, requestHeaders)) return true;
        return skipStatic && isStaticAsset(path);
    }

    /** OPTIONS + Access-Control-Request-Method = a browser CORS preflight, not an app call. */
    public static boolean isCorsPreflight(String method, List<String[]> headers) {
        if (method == null || !method.equalsIgnoreCase("OPTIONS") || headers == null) return false;
        for (String[] h : headers) if (h[0].equalsIgnoreCase("Access-Control-Request-Method")) return true;
        return false;
    }

    public static boolean isStaticAsset(String path) {
        String ext = extension(path);
        return ext != null && STATIC_EXT.contains(ext);
    }

    static String extension(String path) {
        if (path == null) return null;
        String p = path;
        int q = p.indexOf('?'); if (q >= 0) p = p.substring(0, q);
        int h = p.indexOf('#'); if (h >= 0) p = p.substring(0, h);
        int slash = p.lastIndexOf('/');
        String last = slash >= 0 ? p.substring(slash + 1) : p;
        int dot = last.lastIndexOf('.');
        return dot >= 0 && dot < last.length() - 1 ? last.substring(dot + 1).toLowerCase(Locale.ROOT) : null;
    }

    /**
     * Should the response body be copied off Burp's thread at all? Only plausibly-JSON bodies under
     * the size cap. The parser makes the final call (it checks the first character).
     */
    public static boolean wantResponseBody(String contentType, int length) {
        if (length <= 0 || length > MAX_BODY_BYTES) return false;
        if (contentType == null || contentType.isBlank()) return true;
        String ct = contentType.toLowerCase(Locale.ROOT);
        return ct.contains("json") || ct.startsWith("text/plain") || ct.contains("javascript");
    }

    /** Should the request body be copied? Anything under the cap (it is exported as-is). */
    public static boolean wantRequestBody(int length) {
        return length > 0 && length <= MAX_BODY_BYTES;
    }
}
