package apicollector.ingest;

import apicollector.core.Text;
import org.junit.jupiter.api.Test;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class ImportTest {
    @Test void csvQuotedCellsMayContainNewlinesAndCommas() {
        List<List<String>> rows = TabularImporter.parseCsv(
            "method,path,notes\r\nGET,/a,\"line1\nline2, still notes\"\r\nPOST,/b,\"say \"\"hi\"\"\"\n\n");
        assertEquals(3, rows.size());
        assertEquals("line1\nline2, still notes", rows.get(1).get(2));
        assertEquals("say \"hi\"", rows.get(2).get(2));
        var eps = new TabularImporter().fromRows(rows, "t.csv");
        assertEquals(2, eps.size());
        assertEquals("POST /b", eps.get(1).toString());
    }

    @Test void windows1252FilesImportWithoutError() throws Exception {
        Path f = Files.createTempFile("ac", ".csv");
        Files.write(f, new byte[]{'G', 'E', 'T', ' ', '/', 'a', ',', (byte) 0x93, 'x', (byte) 0x94, '\n'});
        String s = Text.readFile(f);
        assertTrue(s.contains("\u201cx\u201d"), s);
        assertEquals(1, new ImportDispatcher().importFile(f).size());
    }

    @Test void utf8BomIsStripped() throws Exception {
        Path f = Files.createTempFile("ac", ".txt");
        Files.write(f, new byte[]{(byte) 0xEF, (byte) 0xBB, (byte) 0xBF, 'G', 'E', 'T', ' ', '/', 'x'});
        assertEquals("GET /x", Text.readFile(f));
    }

    @Test void yamlCannotInstantiateJavaTypes() {
        String evil = "openapi: 3.0.0\npaths:\n  /a:\n    get: {}\nx: !!javax.script.ScriptEngineManager [!!java.net.URLClassLoader [[!!java.net.URL [\"http://127.0.0.1/\"]]]]\n";
        assertThrows(Exception.class, () -> new YamlSpecDecoder().decode(evil, "evil.yaml"));
        var ok = new YamlSpecDecoder().decode("openapi: 3.0.0\npaths:\n  /a/{id}:\n    get: {}\n    delete: {}\n", "ok.yaml");
        assertEquals(2, ok.size());
    }

    @Test void openApiJsonWithBigNumbersStillImports() {
        var eps = new ImportDispatcher().importText("spec.json",
            "{\"openapi\":\"3.0.0\",\"x-id\":1234567890123456789,\"paths\":{\"/u/{id}\":{\"get\":{}}}}");
        assertEquals(1, eps.size());
    }
}
