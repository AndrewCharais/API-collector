package apicollector.export;

import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class ExportSafetyTest {
    private static Collection.Request req(String name, String url) {
        Collection.Request r = new Collection.Request();
        r.name = name; r.method = "GET"; r.urlTemplate = url;
        return r;
    }

    @Test void brunoNeverOverwritesOnSlugCollision() {
        Collection c = new Collection("c");
        c.folder("a").requests.add(req("GET /a/b", "{{baseUrl}}/a/b"));
        c.folder("a").requests.add(req("GET /a_b", "{{baseUrl}}/a_b"));
        Map<String, String> files = new BrunoExporter().export(c, null, "c");
        assertEquals(3, files.size(), files.keySet().toString());   // bruno.json + 2 requests
    }

    @Test void brunoSlugsCannotTraverse() {
        assertEquals("_", BrunoExporter.slug(".."));
        assertEquals("_", BrunoExporter.slug("."));
        assertEquals("_", BrunoExporter.slug(""));
        assertFalse(BrunoExporter.slug("../../etc").contains(".."));
    }

    @Test void brunoValuesCannotBreakTheGrammar() {
        Collection c = new Collection("c");
        Collection.Request r = req("GET /x", "{{baseUrl}}/x");
        r.header("X-A", "v\n}\nget {");
        r.bodyMode = "raw"; r.bodyLanguage = "json"; r.bodyRaw = "{\n\"a\": 1\n}";
        c.folder("x").requests.add(r);
        EnvironmentModel env = new EnvironmentModel("Local").put("k", "line1\nline2");
        Map<String, String> files = new BrunoExporter().export(c, env, "c");
        String bru = files.get("c/x/GET_x.bru");
        assertTrue(bru.contains("  X-A: v } get {\n"), bru);
        assertTrue(bru.contains("body:json {\n  {\n  \"a\": 1\n  }\n}"), bru);
        assertTrue(files.get("c/environments/Local.bru").contains("k: line1 line2"));
    }

    @Test void writerRefusesPathsOutsideTheExportFolder() throws IOException {
        Path dir = Files.createTempDirectory("ac-export");
        CollectionWriter w = new CollectionWriter();
        assertThrows(IOException.class, () -> w.write(dir, Map.of("../evil.txt", "x")));
        assertThrows(IOException.class, () -> w.write(dir, Map.of("a/../../evil.txt", "x")));
        w.write(dir, Map.of("c/x/ok.bru", "ok"));
        assertEquals("ok", Files.readString(dir.resolve("c/x/ok.bru")));
    }

    @Test void postmanCarriesDescription() {
        Collection c = new Collection("c");
        Collection.Request r = req("POST /up", "{{baseUrl}}/up");
        r.description = "Request body omitted";
        c.folder("up").requests.add(r);
        String json = new PostmanExporter().export(c, null, "c").get("c.postman_collection.json");
        assertTrue(json.contains("\"description\": \"Request body omitted\""));
    }
}
