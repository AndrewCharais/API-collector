package apicollector.core;

import apicollector.export.Collection;
import apicollector.export.PlaceholderStyle;
import apicollector.model.RawExchange;
import org.junit.jupiter.api.Test;

import java.nio.charset.StandardCharsets;
import java.util.Map;

import static apicollector.core.TestData.*;
import static org.junit.jupiter.api.Assertions.*;

class CollectionBuilderTest {
    private static CollectionBuilder.Result build(CaptureStore st) {
        return new CollectionBuilder(PlaceholderStyle.DOUBLE_CURLY).build("t", "Local", st, "");
    }
    private static Collection.Request find(CollectionBuilder.Result r, String nameStart) {
        for (var f : r.collection().folders) for (var q : f.requests) if (q.name.startsWith(nameStart)) return q;
        fail("no request " + nameStart); return null;
    }
    private static String hdr(Collection.Request r, String name) {
        for (String[] h : r.headers) if (h[0].equalsIgnoreCase(name)) return h[1];
        return null;
    }

    @Test void bodyKeepsStructureTypesAndOnlyTemplatesIdentifiers() {
        CaptureStore st = new CaptureStore();
        st.record(obs(withJsonBody(raw("POST", "api.example.com", "/api/users?page=2"),
            "{\"user\":{\"id\":1,\"name\":\"a\\\"b\"},\"org\":{\"id\":2},\"admin\":true,\"big\":1234567890123456789}")));
        st.record(obs(withJsonBody(raw("POST", "api.example.com", "/api/products"), "{\"name\":\"Widget\"}")));
        var res = build(st);

        String users = find(res, "POST /api/users").bodyRaw;
        assertTrue(users.contains("\"user\": {"), users);                 // nesting kept
        assertTrue(users.contains("\"id\": {{userId}}"), users);          // qualified, unquoted number
        assertTrue(users.contains("\"id\": {{orgId}}"), users);
        assertTrue(users.contains("\"admin\": true"), users);             // boolean kept, literal
        assertTrue(users.contains("\"name\": \"a\\\"b\""), users);        // literal, still valid JSON
        assertTrue(users.contains("1234567890123456789"), users);         // exact
        assertEquals("2", find(res, "POST /api/users").query.get(0)[1]); // page stays literal

        assertTrue(find(res, "POST /api/products").bodyRaw.contains("\"name\": \"Widget\""), "no cross-endpoint bleed");

        Map<String, String> env = res.environment().values;
        assertEquals("1", env.get("userId"));
        assertEquals("2", env.get("orgId"));
        assertFalse(env.containsKey("page"), "env holds only variables the collection uses");
        assertFalse(env.containsKey("name"));
    }

    @Test void chainedResponseValuesAreTemplated() {
        CaptureStore st = new CaptureStore();
        st.record(obs(withJsonResponse(raw("GET", "h", "/feed"), "{\"cursor\":\"xyz\"}")));
        st.record(obs(raw("GET", "h", "/feed/next?cursor=xyz")));
        st.record(obs(raw("GET", "h", "/feed/other?cursor=typed")));
        var res = build(st);
        assertEquals("{{cursor}}", find(res, "GET /feed/next").query.get(0)[1]);
        assertEquals("typed", find(res, "GET /feed/other").query.get(0)[1]);
        assertEquals("xyz", res.environment().values.get("cursor"));
    }

    @Test void credentialsAreTemplatedWithRealValues() {
        CaptureStore st = new CaptureStore();
        RawExchange x = raw("GET", "h", "/me");
        header(x, "Authorization", "Bearer eyJabc");
        header(x, "Cookie", "sid=1; theme=dark");
        header(x, "X-Api-Key", "k123");
        header(x, "Accept", "application/json");
        header(x, "User-Agent", "Mozilla");
        header(x, "Sec-Fetch-Mode", "cors");
        st.record(obs(x));
        RawExchange b = raw("GET", "h", "/basic");
        header(b, "Authorization", "Basic dXNlcjpwYXNz");
        st.record(obs(b));
        var res = build(st);
        var me = find(res, "GET /me");
        assertEquals("Bearer {{accessToken}}", hdr(me, "Authorization"));
        assertEquals("{{cookie}}", hdr(me, "Cookie"));
        assertEquals("{{xApiKey}}", hdr(me, "X-Api-Key"));
        assertEquals("application/json", hdr(me, "Accept"));
        assertNull(hdr(me, "User-Agent"));
        assertNull(hdr(me, "Sec-Fetch-Mode"));
        assertEquals("Basic {{basicAuth}}", hdr(find(res, "GET /basic"), "Authorization"));
        var env = res.environment().values;
        assertEquals("eyJabc", env.get("accessToken"));
        assertEquals("dXNlcjpwYXNz", env.get("basicAuth"));
        assertEquals("sid=1; theme=dark", env.get("cookie"));
        assertEquals("k123", env.get("xApiKey"));
    }

    @Test void notFoundOnlyEndpointsAreNotExported() {
        CaptureStore st = new CaptureStore();
        st.record(obs("GET", "/real", 200));
        st.record(obs("GET", "/admin.bak", 404));
        var res = build(st);
        int n = 0; for (var f : res.collection().folders) n += f.requests.size();
        assertEquals(1, n);
    }

    @Test void eachHostGetsItsOwnBaseUrl() {
        CaptureStore st = new CaptureStore();
        st.record(obs(raw("GET", "api.client.com", "/a")));
        st.record(obs(raw("GET", "api.client.com", "/b")));
        st.record(obs(raw("POST", "auth.client.com", "/token")));
        var res = build(st);
        assertTrue(find(res, "GET /a").urlTemplate.startsWith("{{baseUrl}}/"));
        assertTrue(find(res, "POST /token").urlTemplate.startsWith("{{baseUrl_auth_client_com}}/"));
        assertEquals("https://auth.client.com", res.environment().values.get("baseUrl_auth_client_com"));
    }

    @Test void formBodiesStayFormEncoded() {
        CaptureStore st = new CaptureStore();
        RawExchange x = raw("POST", "h", "/orders/5/notes");
        x.requestHeaders.add(new String[]{"Content-Type", "application/x-www-form-urlencoded"});
        x.requestBody = "note=hi+there&orderId=5".getBytes(StandardCharsets.UTF_8);
        x.requestBodyLength = x.requestBody.length;
        st.record(obs(x));
        var r = find(build(st), "POST /orders/{id}/notes");
        assertEquals("note=hi+there&orderId={{orderId}}", r.bodyRaw);
        assertEquals("{{baseUrl}}/orders/{{orderId}}/notes", r.urlTemplate);
    }

    @Test void multiElementArraysStayLiteral() {
        CaptureStore st = new CaptureStore();
        st.record(obs(withJsonBody(raw("POST", "h", "/bulk"), "{\"items\":[{\"id\":1},{\"id\":2}]}")));
        String body = find(build(st), "POST /bulk").bodyRaw;
        assertTrue(body.contains("\"id\": 1") && body.contains("\"id\": 2"), body);
    }

    @Test void idLikeNames() {
        assertTrue(CollectionBuilder.isIdLike("userId"));
        assertTrue(CollectionBuilder.isIdLike("order_id"));
        assertTrue(CollectionBuilder.isIdLike("ID"));
        assertTrue(CollectionBuilder.isIdLike("refreshToken"));
        assertFalse(CollectionBuilder.isIdLike("paid"));
        assertFalse(CollectionBuilder.isIdLike("valid"));
        assertFalse(CollectionBuilder.isIdLike("name"));
    }
}
