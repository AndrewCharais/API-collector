package apicollector.core;

import apicollector.core.LiveSubstitution.Context;
import apicollector.export.PlaceholderStyle;
import org.junit.jupiter.api.Test;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import static org.junit.jupiter.api.Assertions.*;

class LiveSubstitutionTest {
    private final LiveSubstitution sub = new LiveSubstitution();
    private final Pattern curly = PlaceholderStyle.combined(List.of(PlaceholderStyle.DOUBLE_CURLY));

    @Test void crlfValueIsRefusedInHeaders() {
        var o = sub.apply("{{orderId}}", curly, Map.of("orderId", "1\r\nX-Injected: yes"), Context.HEADER);
        assertFalse(o.changed);
        assertEquals("{{orderId}}", o.text);
        assertTrue(o.rejected.contains("orderId"));
    }

    @Test void pathAndQueryValuesArePercentEncoded() {
        var p = sub.apply("/orders/{{id}}", curly, Map.of("id", "a b/../c?#"), Context.PATH);
        assertEquals("/orders/a%20b%2F..%2Fc%3F%23", p.text);
        var q = sub.apply("?q={{q}}", curly, Map.of("q", "x&admin=true"), Context.QUERY);
        assertEquals("?q=x%26admin%3Dtrue", q.text);
    }

    @Test void bodyValuesAreEscapedForTheirContentType() {
        assertEquals("{\"n\":\"a\\\"b\"}", sub.apply("{\"n\":\"{{v}}\"}", curly, Map.of("v", "a\"b"), Context.BODY_JSON).text);
        assertEquals("n=a%26b", sub.apply("n={{v}}", curly, Map.of("v", "a&b"), Context.BODY_FORM).text);
        assertEquals("<n>&lt;x&gt;</n>", sub.apply("<n>{{v}}</n>", curly, Map.of("v", "<x>"), Context.BODY_XML).text);
        assertTrue(sub.apply("{{v}}", curly, Map.of("v", "a\nb"), Context.BODY_RAW).rejected.contains("v"));
    }

    @Test void byteViewSplicesUtf8Bytes() {
        String view = new String("{\"n\":\"{{v}}\"}".getBytes(StandardCharsets.UTF_8), StandardCharsets.ISO_8859_1);
        var o = sub.apply(view, curly, Map.of("v", "café"), Context.BODY_JSON, true);
        byte[] wire = o.text.getBytes(StandardCharsets.ISO_8859_1);
        assertEquals("{\"n\":\"café\"}", new String(wire, StandardCharsets.UTF_8));
        assertEquals(13, wire.length);    // é is 2 bytes; what Montoya's withBody will put in Content-Length
    }

    @Test void multipleFormatsAreOnePassAndValuesAreNotRescanned() {
        Pattern both = PlaceholderStyle.combined(List.of(PlaceholderStyle.DOUBLE_CURLY, new PlaceholderStyle(":", "")));
        var o = sub.apply("/a/:id/{{x}}", both, Map.of("id", "{{x}}", "x", "7"), Context.BODY_RAW);
        assertEquals("/a/{{x}}/7", o.text);
    }

    @Test void colonStyleDoesNotMatchPortsOrTrailingDots() {
        Pattern colon = PlaceholderStyle.combined(List.of(new PlaceholderStyle(":", "")));
        var o = sub.apply("https://h:8443/x and :name.", colon, Map.of("8443", "BAD", "name", "ok"), Context.BODY_RAW);
        assertEquals("https://h:8443/x and ok.", o.text);
    }

    @Test void missingValuesAreReportedAndLeftAlone() {
        var o = sub.apply("{{a}} {{b}}", curly, Map.of("a", "1"), Context.BODY_RAW);
        assertEquals("1 {{b}}", o.text);
        assertTrue(o.missing.contains("b"));
    }

    @Test void formatsWithoutPrefixAreRejected() {
        assertTrue(PlaceholderFormats.parse("name}}").isEmpty());
        assertEquals(2, PlaceholderFormats.parse("{{name}}, ${name}").size());
    }

    @Test void hydratorEscapesValuesInJsonCollections() {
        var r = new PlaceholderHydrator().hydrate("{\"url\":\"{{v}}\"}", PlaceholderStyle.DOUBLE_CURLY, Map.of("v", "a\"b"));
        assertEquals("{\"url\":\"a\\\"b\"}", r.text);
        var t = new PlaceholderHydrator().hydrate("url: {{v}}", PlaceholderStyle.DOUBLE_CURLY, Map.of("v", "a\"b"));
        assertEquals("url: a\"b", t.text);
    }
}
