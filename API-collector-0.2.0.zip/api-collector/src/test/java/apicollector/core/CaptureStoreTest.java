package apicollector.core;

import apicollector.model.Endpoint;
import apicollector.model.Observation;
import apicollector.model.RawExchange;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;

import static apicollector.core.TestData.*;
import static org.junit.jupiter.api.Assertions.*;

class CaptureStoreTest {
    @Test void notFoundResponsesDoNotCountAsSeen() {
        CaptureStore st = new CaptureStore();
        st.importExpected("GET", "/api/admin/{id}");
        st.record(obs("GET", "/api/admin/5", 404));
        var cov = st.coverage();
        assertEquals(0, cov.seenExpectedCount());
        assertEquals(CoverageTracker.Status.NOT_FOUND, cov.status(cov.notSeen().get(0)));
        st.record(obs("GET", "/api/admin/6", 200));
        assertEquals(1, cov.seenExpectedCount());
        assertTrue(cov.notSeen().isEmpty());
    }

    @Test void forbiddenAndServerErrorsStillProveTheRouteExists() {
        assertTrue(CoverageTracker.isReachable(403));
        assertTrue(CoverageTracker.isReachable(500));
        assertFalse(CoverageTracker.isReachable(404));
        assertFalse(CoverageTracker.isReachable(0));
    }

    @Test void historyRescanIsIdempotent() {
        CaptureStore st = new CaptureStore();
        Observation o = obs("GET", "/api/users/1");
        assertNotNull(st.record(o, false));            // live
        assertNull(st.record(o, true));                // rescan of the same exchange
        assertNull(st.record(obs("GET", "/api/users/1"), true));
        assertEquals(1, st.endpoints().get(0).count);
    }

    @Test void pathLearningCollapsesShortIdsAndMergesEndpoints() {
        CaptureStore st = new CaptureStore();
        for (String id : List.of("A7K2Q9", "B8L3R0", "C9M4S1", "D0N5T2")) st.record(obs("GET", "/orders/" + id));
        List<Endpoint> eps = st.endpoints();
        assertEquals(1, eps.size(), "four short codes should merge into one endpoint");
        assertEquals("GET /orders/{}", eps.get(0).shape.canonical());
        assertEquals(4, eps.get(0).count);
        assertNotNull(st.params().active("orderId"));
    }

    @Test void pathLearningNeverMergesRouteWords() {
        CaptureStore st = new CaptureStore();
        for (String w : List.of("users", "orders", "products", "invoices", "reports", "v1", "v2", "v3", "v4"))
            st.record(obs("GET", "/api/" + w));
        assertEquals(9, st.endpoints().size());
    }

    @Test void datesCollapseAsIdentifiers() {
        CaptureStore st = new CaptureStore();
        st.record(obs("GET", "/reports/2024-01-31"));
        st.record(obs("GET", "/reports/2024-02-29T10:15:00Z"));
        assertEquals(1, st.endpoints().size());
    }

    @Test void differentHostsStayDifferentEndpoints() {
        CaptureStore st = new CaptureStore();
        st.record(obs(raw("GET", "api.client.com", "/me")));
        st.record(obs(raw("GET", "api.client.com", "/me/x")));
        st.record(obs(raw("GET", "auth.client.com", "/me")));
        assertEquals(3, st.endpoints().size());
        Map<String, String> vars = st.baseUrlVars("");
        assertEquals("https://api.client.com", vars.get("baseUrl"));
        assertEquals("https://auth.client.com", vars.get("baseUrl_auth_client_com"));
        assertEquals("https://staging.local", st.baseUrlVars("https://staging.local/").get("baseUrl"));
    }

    @Test void valuesPerNameAreCappedButActiveIsKept() {
        CaptureStore st = new CaptureStore();
        for (int i = 0; i < 80; i++) st.params().record("id", "v" + i, "resp:GET /items");
        assertEquals(ParameterRegistry.MAX_VALUES_PER_NAME, st.params().valuesOf("id").size());
        assertNotNull(st.params().active("id"));
        assertTrue(st.params().valueStrings("id").contains(st.params().active("id")));
    }

    @Test void credentialHeadersBecomeKnownValuesAndRefresh() {
        CaptureStore st = new CaptureStore();
        st.record(obs(header(raw("GET", "h", "/a"), "Authorization", "Bearer tok1")));
        assertEquals("tok1", st.params().active("accessToken"));
        st.record(obs(header(raw("GET", "h", "/b"), "Authorization", "Bearer tok2")));
        assertEquals("tok2", st.params().active("accessToken"), "re-login token should refresh");
        st.record(obs(header(raw("GET", "h", "/c"), "X-CSRF-Token", "csrf1")));
        assertEquals("csrf1", st.params().active("xCsrfToken"));
    }

    @Test void endpointsAreCopies() {
        CaptureStore st = new CaptureStore();
        st.record(obs("GET", "/a"));
        st.endpoints().get(0).count = 999;
        assertEquals(1, st.endpoints().get(0).count);
    }

    @Test void pipelineSurvivesHostileInput() throws Exception {
        CaptureStore st = new CaptureStore();
        CapturePipeline p = new CapturePipeline(st, null);
        RawExchange evil = withJsonResponse(raw("GET", "h", "/x"), "[".repeat(50_000));
        assertTrue(p.processNow(evil));            // recorded, the hostile body is just not parsed
        assertTrue(p.processNow(raw("GET", "h", "/y")));
        p.shutdown();
        assertEquals(2, st.endpointCount());
    }
}
