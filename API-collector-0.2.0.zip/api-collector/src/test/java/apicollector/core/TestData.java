package apicollector.core;

import apicollector.model.Observation;
import apicollector.model.RawExchange;

import java.nio.charset.StandardCharsets;

/** Builders for test exchanges. */
final class TestData {
    private TestData() {}

    static RawExchange raw(String method, String host, String path) {
        RawExchange x = new RawExchange();
        x.method = method; x.secure = true; x.host = host; x.port = 443; x.path = path;
        x.status = 200;
        return x;
    }
    static RawExchange withJsonBody(RawExchange x, String json) {
        x.requestHeaders.add(new String[]{"Content-Type", "application/json"});
        x.requestBody = json.getBytes(StandardCharsets.UTF_8);
        x.requestBodyLength = x.requestBody.length;
        return x;
    }
    static RawExchange withJsonResponse(RawExchange x, String json) {
        x.responseContentType = "application/json";
        x.responseBody = json.getBytes(StandardCharsets.UTF_8);
        x.responseBodyLength = x.responseBody.length;
        return x;
    }
    static RawExchange header(RawExchange x, String name, String value) {
        x.requestHeaders.add(new String[]{name, value});
        return x;
    }
    static Observation obs(RawExchange x) { return new ObservationBuilder().build(x); }
    static Observation obs(String method, String path) { return obs(raw(method, "api.example.com", path)); }
    static Observation obs(String method, String path, int status) {
        RawExchange x = raw(method, "api.example.com", path); x.status = status; return obs(x);
    }
}
