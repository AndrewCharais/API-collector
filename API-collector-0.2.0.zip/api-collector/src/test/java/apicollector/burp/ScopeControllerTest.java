package apicollector.burp;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ScopeControllerTest {
    @Test void customHostsMatchExactAndSubdomainsOnly() {
        ScopeController s = new ScopeController(null);
        s.setMode(ScopeController.Mode.CUSTOM);
        s.setHosts("client.com\n# comment\nhttps://api.other.io:8443/path\n[::1]");
        assertTrue(s.hostMatches("client.com"));
        assertTrue(s.hostMatches("API.client.com"));
        assertFalse(s.hostMatches("evilclient.com"));
        assertFalse(s.hostMatches("client.com.evil.net"));
        assertTrue(s.hostMatches("api.other.io"));
        assertTrue(s.hostMatches("[::1]"));
        assertFalse(s.hostMatches(""));
    }

    @Test void pastedUrlsAreReducedToTheirHost() {
        assertEquals("target.com", ScopeController.hostOf("https://user:pw@target.com:443/x?y#z"));
        assertEquals("attacker.com", ScopeController.hostOf("https://attacker.com?@target.com"));
        assertEquals("attacker.com", ScopeController.hostOf("https://attacker.com#@target.com"));
    }
}
