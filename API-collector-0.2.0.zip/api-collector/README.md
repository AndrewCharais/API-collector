# API Collector (Burp / Montoya extension)

Generate a working API collection (Postman / Bruno) + environment file from traffic
captured during normal manual web-app testing, and track it against a client-provided
endpoint list to produce a "couldn't-trigger-from-the-UI" deliverable.

## Load it

A prebuilt `api-collector.jar` is included. In Burp: Extensions > Installed > Add >
Java > select the jar. A new "API Collector" suite tab appears.

Or build from source (needs internet for Maven Central / the Gradle plugin portal):

    gradle shadowJar   # -> build/libs/api-collector.jar (bundles SnakeYAML + POI, relocated)
    gradle test        # JUnit 5 suite for the Burp-free core

(No Gradle wrapper is checked in; run `gradle wrapper` once if you want `./gradlew`.)

## Workflow in Burp

1. **Import** — load the in-scope endpoint list (OpenAPI/Swagger, Postman, Bruno folder,
   Excel/CSV, or freeform paste). Rows land in Coverage as "not seen".
2. **Scope** — use Burp target scope, or list custom hosts (one per line, subdomains match).
   **Capture from** chooses which tools' traffic is recorded: Proxy only by default, so
   Scanner / Intruder probes never pollute values or mark endpoints "seen".
3. Walk the web app through Burp. In-scope Proxy traffic is captured automatically; existing
   proxy history is back-filled on load. **Rescan history** runs in the background and skips
   anything already captured, so it never double-counts.
4. **Coverage** updates live: *seen*, *not found* (reached, but only 404/405/410/501), or
   *not seen*, matched by normalized endpoint shape, with the last status code per endpoint.
5. **Captured values** — pick the active value per parameter (pinned values never auto-refresh;
   right-click > Unpin to resume).
6. **Export** — write the Postman/Bruno collection + environment; export the not-seen list as
   the client deliverable (not-found endpoints are annotated).

## What the export contains

- One request per endpoint *per host*. Each captured host gets its own base-URL variable
  (`{{baseUrl}}` for the most-used host, `{{baseUrl_auth_client_com}}` for others). The
  "Base URL override" setting optionally repoints the primary host.
- Request bodies are templated **in place**: JSON keeps its nesting, types and exact numbers;
  form bodies stay form-encoded; XML / multipart / text are exported as captured.
- Only values that matter for chaining become placeholders: path IDs, values that were also
  returned by a response, identifier/token-like names (`userId`, `order_id`, `refreshToken`)
  and credential headers. Generic `id` fields are qualified (`user.id` -> `{{userId}}`, a
  top-level `id` under `/orders` -> `{{orderId}}`). Everything else is exported literally.
- Credentials: `Authorization: Bearer {{accessToken}}` / `Basic {{basicAuth}}`, `Cookie:
  {{cookie}}`, and API-key / token / CSRF-style headers (`X-Api-Key: {{xApiKey}}`). Browser
  noise (User-Agent, sec-*, Accept-Encoding, ...) is dropped.
- The environment holds only the variables the collection uses, with captured values.
  **It contains live credentials** — treat exported environment files as engagement data.
- Endpoints that only ever returned 404/405/410/501 are not exported.

## Live auto-fill (API-only testing)

"Auto-fill live requests" replaces placeholders in outgoing requests (from the tools ticked
under "Apply to") with captured values. Values come from the target's own responses, so each
one is encoded for where it lands — percent-encoded in the path/query, JSON-escaped in JSON
bodies, form-encoded in form bodies, XML-escaped in XML — and **refused** (logged, placeholder
left in place) when it contains CR/LF or other control characters destined for a header, the
URL or a raw body. The request is rewritten part by part through Montoya, so Content-Length is
recomputed from real bytes and HTTP/2 / binary bodies are preserved. Chunked bodies are skipped.

## Layout

    apicollector/
      ApiCollectorExtension     BurpExtension entry point (wires everything, unload handler)
      burp/                     Montoya adapter (the only Burp-coupled code)
        ExchangeSnapshots       HttpRequest/HttpResponse -> RawExchange (copy only, on Burp's thread)
        LiveHttpHandler         capture (tool-filtered) + context-aware live auto-fill
        ProxyHistoryImporter    background, filtered, idempotent proxy-history import
        ScopeController         Burp scope vs custom host include-list
      core/                     pure logic, unit-tested with no Burp dependency
        CapturePipeline         bounded single-worker queue: parse + record off Burp's thread
        ObservationBuilder      RawExchange -> Observation (query, JSON/form bodies, JSON responses)
        CaptureFilter           size caps, JSON gating, static assets, CORS preflights
        HeaderPolicy            which headers are exported; credential templating
        PathNormalizer + IdentifierHeuristic + PathLearner + EndpointShape   grouping / coverage
        CaptureStore            central state (endpoints per host + known values + coverage)
        ParameterRegistry       bounded known-values store, CoverageTracker (seen / not found)
        JsonFlattener           JSON body -> leaves (name, parent, exact value)
        CollectionBuilder       captured endpoints -> export IR + environment
        LiveSubstitution, PlaceholderHydrator, Text
      ingest/                   endpoint-list importers (OpenAPI, Postman, Bruno, tabular, freeform)
      export/                   exporter-agnostic IR + Postman/Bruno exporters + Json + writer
      ui/ApiCollectorTab        Swing suite tab
    src/test/java/...           JUnit 5 tests
    src/main/resources/META-INF/services/burp.api.montoya.BurpExtension   ServiceLoader hook

## Design decisions

1. One normalized `EndpointShape` drives BOTH grouping and coverage, so they can never
   disagree about "the same endpoint". Short codes the regex misses (`A7K2Q9`) are learned
   from cardinality: once a path slot has 4 distinct digit-bearing values it collapses.
   Plain words (`/api/users` vs `/api/orders`) and versions (`v1`, `v2`) never merge.
2. The exporter-agnostic `Collection` IR sits between capture and output; exporters read
   only the IR. Adding Insomnia/OpenAPI = one new `CollectionExporter`.
3. Placeholder templating happens at export time, so one app-walk emits Postman OR Bruno
   with no re-capture.
4. Burp's HTTP thread only copies bytes; all parsing runs on one background worker with a
   bounded queue (drops are counted in the status bar rather than slowing Burp).
5. Hostile input is bounded: JSON nesting depth 256, bodies over 2 MB are not parsed, at most
   50 values per name and 200k remembered fingerprints.

## Import formats

OpenAPI/Swagger (JSON **and** YAML), Postman collections (incl. API-export wrapped),
Bruno collection folders (`.bru`), Excel `.xlsx`, CSV, and freeform paste. Text files are
read as UTF-8, falling back to Windows-1252 (what Excel writes). YAML uses SnakeYAML's
`SafeConstructor`; Excel uses Apache POI 5.4.1. Both are bundled (and relocated) by the shadow build.

The prebuilt `api-collector.jar` bundles SnakeYAML but not POI, so JSON/YAML/Postman/
Bruno/CSV/text work immediately. Excel needs the packaged build — run `gradle shadowJar`;
until then, `.xlsx` import shows a message pointing you to CSV.

## Verify the core without Gradle

    javac -d out $(find src/main -name '*.java' | grep -v /burp/ | grep -v /ui/ | grep -v Extension | grep -v Xlsx | grep -v Yaml | grep -v ImportDispatcher)
    java  -cp out apicollector.demo.CoreDemo
