# Changes in 0.3.3

- **Error messages in coverage.** For 4xx/5xx responses the extension extracts a short message
  from the body (JSON message fields incl. nested / `errors[]` / problem+json / OAuth
  `error_description`; HTML `<title>`/`<h1>`; SOAP `faultstring`; first line of text). The latest
  message per status code is shown in a new *Error messages* column in the Coverage table
  (full text on hover) and in both CSVs, e.g. `403: Refunds require the finance role | 500: ...`.
  Saved with the project. Only the first 64 KB of an error body is copied, binary types skipped.
  `core/ErrorMessages`.

# Changes in 0.3.2

- **Not-seen list, CSV** is back (0.3.1 removed it by mistake). Only the plain-text not-seen
  list is gone. Export now offers *Not-seen list, CSV* and *Full coverage report, CSV*.
- **Which endpoints never got a successful response.** "Seen" now means at least one 2xx / 304
  response. Endpoints that answered only with errors or redirects (401, 403, 400, 500, 302, ...)
  get the new status **No success**. The Coverage table adds a *Status codes* column and a
  *Without a successful response* filter; the status bar counts them; both CSVs add a
  *Status codes seen* column, and the not-seen CSV includes no-success endpoints.
  Coverage % still counts every endpoint that was reached.
- When an endpoint has both failed and successful exchanges, the successful one is exported.
- Projects saved by 0.3.0/0.3.1 load fine (success is derived from their saved status codes).

# Changes in 0.3.1

- *Capture from* now offers Proxy, Repeater, Extensions; *Apply to* (auto-fill) offers Proxy,
  Repeater. Scanner and Intruder are no longer options in either. Settings saved by 0.3.0 that
  ticked them are ignored on load.

# Changes in 0.3.0

## New

- **Saved with the Burp project.** Captured state (endpoints, values, pins, coverage, imported
  list, ignored prefixes, loaded collection, history fingerprints) is gzipped into the project
  file every 30 s when changed and on unload, and restored on load before the history backfill.
  Per-engagement settings are saved in the project; personal preferences in Burp's user
  preferences. Corrupt or unknown saved state is logged and ignored (the extension starts fresh).
  `burp/ProjectPersistence`, `core/StateCodec`.
- **File uploads.** Multipart bodies are parsed byte-exact and exported as Postman form-data /
  Bruno multipart-form, with uploaded files written next to the collection. Text fields template
  like form fields; the stale boundary `Content-Type` is dropped. `core/Multipart`, exporters.
- **Gateway / version prefixes.** *Prefixes…* (Coverage) lists path prefixes stripped from both
  spec and traffic before matching; *Suggest* proposes the one that matches the most endpoints.
  Hits and last status follow the match.
- **CSV deliverable.** *Not-seen list, CSV* and *Full coverage report, CSV*: method, endpoint as
  written in the client's spec, coverage, last HTTP status, hits, source file. RFC-4180 quoting
  and spreadsheet formula-injection protection. The text list now uses the spec's own paths too.
- **Gradle wrapper (8.14.3) + GitHub Actions CI** (`.github/workflows/build.yml` at the repo
  root): test + shadowJar on every push / PR, jar and test reports uploaded as artifacts.
  Shadow plugin moved to its maintained successor `com.gradleup.shadow` 8.3.5. `.gitignore` added.

## Fixed

- Capture queue is now bounded by bytes (256 MB) as well as item count, so a burst of large
  bodies can't pile up in Burp's heap (issue in 0.2.0).

## Removed (dead code)

Unused layout option (`Layout.VALUES_TAB` and its tab view), `showMissing()`, the back-compat
`CollectionBuilder(style, String)` and `Endpoint(shape)` constructors, `JsonFlattener.flatten`,
`ParameterRegistry.isWanted/wanted/missing/valuesOf/knows/activeSource/autoRefresh()/clearAllIncludingWanted`,
`LoadedCollection.tokenCount`, `PlaceholderFormats.describe`, `IdentifierHeuristic.longTokenMinLength`,
`Json.Num.doubleValue`, `LiveSubstitution.apply(…, PlaceholderStyle, …)`, `CoverageTracker.markSeen/notSeen/seenCount`,
unused getters on `LiveHttpHandler` / `ScopeController`, and unused imports.
`CaptureFilter.skip` was only called from tests while the live handler duplicated its logic —
the handler now calls it.

Tests: 67, all passing.

# Changes in 0.2.0

Every item below has a unit test in `src/test/java` (55 tests, all passing).

## Security

| Concern | Fix | Where |
|---|---|---|
| Auto-fill inserted server-supplied values raw (CRLF header injection, unencoded URL values) | Values are encoded for where they land: percent-encoded in path/query, JSON-escaped, form-encoded, XML-escaped. Values containing CR/LF or other control characters are **refused** for headers, the URL and raw bodies; the placeholder stays and an error is logged. All formats are matched in one pass, so a substituted value is never re-scanned. | `core/LiveSubstitution`, `burp/LiveHttpHandler` |
| Hostile response could crash capture (unbounded JSON recursion; whole-body parsing of any size) | JSON nesting capped at 256; bodies over 2 MB are not parsed; response bodies are only copied when they might be JSON; `StackOverflowError` is contained on the worker thread. | `export/Json`, `core/CaptureFilter`, `core/CapturePipeline` |
| poi-ooxml 5.3.0 (CVE-2025-31672); no relocation of bundled libraries | POI 5.4.1; SnakeYAML now uses `SafeConstructor`; shadow jar relocates SnakeYAML and the commons-* libraries. | `build.gradle.kts`, `ingest/YamlSpecDecoder` |
| Bruno folder names could be `..`; scope check re-parsed URL strings | Slugs can never be `.`/`..`; the writer refuses any path outside the export folder; custom scope matches `httpService().host()`. | `export/BrunoExporter`, `export/CollectionWriter`, `burp/ScopeController` |

Not changed, as requested: concern 1 (secrets in exported environment files). Note that exports now *also* carry cookies and API-key/CSRF headers (bug 5), so that concern matters more than before.

## Bugs

1. **Capture now records only the tools you tick** (Proxy by default). Only responses that prove the route exists count as "seen"; 404/405/410/501-only endpoints show as **not found**, stay on the not-seen deliverable (annotated) and are not exported.
2. **Selective templating.** Only path IDs, values also returned by a response, ID/token-like names and credentials become placeholders. Generic `id` fields are qualified (`user.id` → `{{userId}}`). The environment holds only the variables the collection uses.
3. **Bodies are templated in place.** JSON keeps its nesting, types and order; form bodies stay form-encoded; XML/multipart/text are exported verbatim. Bodies over 2 MB get a note instead.
4. **Exact numbers.** The JSON parser keeps number text as written, so `1234567890123456789` no longer becomes `…768`.
5. **Auth works in exports:** `Bearer {{accessToken}}` / `Basic {{basicAuth}}`, `Cookie: {{cookie}}`, `X-Api-Key: {{xApiKey}}`, all with captured values. Useful headers (Accept, tenant headers) are kept; browser noise is dropped.
6. **One base URL per host**, taken from captured traffic (`{{baseUrl}}`, `{{baseUrl_auth_client_com}}`); endpoints on different hosts no longer merge; ports are kept. "Base URL" is now an optional override.
7. **Content-Length is correct after auto-fill.** The request is rewritten through Montoya (`withPath`, `withUpdatedHeader`, `withBody` on the raw bytes), so the length is computed from real bytes and HTTP/2 and binary bodies survive. Chunked bodies are skipped.
8. **Bruno export:** file names are unique (no silent overwrite); line breaks in values are flattened; body lines are indented so a `}` can't close the block.
9. **Unload handler** stops the UI timer, history scans, the backfill thread and the capture worker.
10. **History import** runs in the background (Burp never freezes) and fingerprints each exchange, so rescans skip anything already captured. It respects Capture ON/OFF, the static-asset filter and CORS preflights.
11. **Captured-values table:** refreshes wait until you finish editing a value; your selection is kept; rows are a snapshot; right-click **Unpin**; new Pinned column.
12. **Smaller fixes:**
    - Dates and short codes (via path learning) collapse to `{id}`.
    - The CSV parser handles quoted newlines.
    - Windows-1252 and BOM files import without errors.
    - CORS preflights are skipped.
    - The `CoreDemo` lookup is fixed.
    - The README is updated, and tests were added.
    - **Found while testing:** custom-scope hosts typed without a scheme (`client.com`) were silently discarded, so custom-host mode only worked with full URLs. Fixed.
    - The filled client collection JSON-escapes values.
    - The placeholder-name pattern no longer matches `:8443` or a trailing `.`.
    - Formats with no prefix are rejected.

## Optimizations

- The Burp HTTP thread only copies bytes. Parsing runs on one worker with a bounded queue (10k); when full, items are dropped and counted in the status bar instead of slowing Burp.
- JSON and size gates before any parsing.
- At most 50 values per name (least recently seen dropped first; the active value is always kept) and 20 sources per value.
- Path slots are learned from how many distinct digit-bearing values they take (4 merges them); route words and `v1`/`v2` never merge.
- UI work happens only when data changes: count methods instead of list copies, and one snapshot per reload.
- History is filtered inside Burp's `history(filter)`.
- Placeholder regexes are compiled once per format; requests without any placeholder prefix are never rebuilt.
- The scope host list is copy-on-write, so per-request checks take no lock.

## Behaviour changes to be aware of

- Repeater traffic is **no longer captured by default**. Tick it under *Capture from* if you want it.
- In auto-fill, a value inserted into the **path** is percent-encoded, so `/` becomes `%2F`. That's intended (it blocks traversal), but a placeholder meant to expand into several path segments won't.
- Exported environments are smaller: only variables the collection uses.
