# API Collector (Burp / Montoya extension)

Generate a working API collection (Postman / Bruno) + environment file from traffic
captured during normal manual web-app testing, and track it against a client-provided
endpoint list to produce a "couldn't-trigger-from-the-UI" deliverable.

## Load it

A prebuilt `api-collector.jar` is included. In Burp: Extensions > Installed > Add >
Java > select the jar. A new "API Collector" suite tab appears.

Or build from source with the Gradle wrapper (needs JDK 21 and internet for Maven Central /
the Gradle plugin portal; no local Gradle install required):

    ./gradlew test shadowJar   # -> build/libs/api-collector.jar (bundles SnakeYAML + POI, relocated)

CI (`.github/workflows/build.yml` at the repo root) runs the same command on every push and
pull request and publishes the jar and test reports as build artifacts.

## Saved with your Burp project

Everything you capture is saved into the **Burp project file** every 30 seconds (when
something changed) and on unload: endpoints, captured values (including pinned choices),
coverage, the imported endpoint list, ignored prefixes, the loaded client collection, and the
fingerprints that keep history rescans from double-counting. Reopen the project (or reload the
extension) and the engagement picks up where it left off.

- Per-engagement settings — scope mode and hosts, *Capture from*, base URL override, collection
  name — are saved in the project too.
- Personal preferences — placeholder / match formats, export format, auto-fill tools and toggles —
  are saved in Burp's user preferences, so they follow you to new projects.
- Burp Community only has temporary projects, so there state lasts until Burp closes.
- The project file now contains captured credentials; handle it like any engagement data.

## Workflow in Burp

1. **Import** — load the in-scope endpoint list (OpenAPI/Swagger, Postman, Bruno folder,
   Excel/CSV, or freeform paste). Rows land in Coverage as "not seen".
2. **Scope** — use Burp target scope, or list custom hosts (one per line, subdomains match).
   **Capture from** chooses which tools' traffic is recorded: Proxy (default), Repeater,
   Extensions. Scanner and Intruder are not offered, so their probes never pollute values or
   mark endpoints "seen".
3. Walk the web app through Burp. In-scope Proxy traffic is captured automatically; existing
   proxy history is back-filled on load. **Rescan history** runs in the background and skips
   anything already captured, so it never double-counts.
4. **Coverage** updates live, matched by normalized endpoint shape. Each imported endpoint is:
   - *seen* — at least one successful response (2xx, or 304);
   - *no success* — it answered, but only with errors or redirects (401, 403, 400, 500, a 302 to
     a login page, ...);
   - *not found* — only 404 / 405 / 410 / 501;
   - *not seen* — never requested.

   The table also shows the last status, every status code seen, and the **error message**
   each failing status returned (hover for the full text), and the filter has
   **Without a successful response** to list everything that never succeeded. The status bar
   counts endpoints with no successful response. Coverage % counts every endpoint that was
   reached (seen + no success). When an endpoint has both failed and successful exchanges, the
   successful one is what gets exported.
5. **Captured values** — pick the active value per parameter (pinned values never auto-refresh;
   right-click > Unpin to resume).
6. **Export** — write the Postman/Bruno collection + environment, and the client deliverables:
   - **Not-seen list, CSV** — every imported endpoint without a successful response (not seen,
     not found, or no success).
   - **Full coverage report, CSV** — every imported endpoint, seen included.

   Columns: Method, Endpoint (exactly as written in the client's spec), Coverage, Last HTTP
   status, Status codes seen, Error messages (e.g. `403: Refunds require the finance role |
   500: Unhandled exception`), Hits, Source file. Cells are quoted and formula-injection safe
   (anything starting with `= + - @` is prefixed with `'`).

### Error messages

For every 4xx/5xx response the start of the body (up to 64 KB; images and other binary types
are skipped) is read for a short message, by format rather than one regex:
JSON — the first string under `message`, `error_description`, `detail`, `title`, `error`, ...
(nested objects and `errors[]` arrays included; RFC 7807 problem+json gives "title: detail");
HTML — the `<title>` or first `<h1>`; XML/SOAP — `faultstring` / `message`; plain text — the
first line. Messages are whitespace-collapsed and capped at 200 characters; the latest message
per status code is kept. They are the target's own words, so they can include internal detail
(stack traces, hostnames) — review the CSV before it goes to the client.

### Gateway / version prefixes

If traffic goes through a prefix the spec doesn't have (`/api/v1/users/42` vs `/users/{id}`), or
the other way round, click **Prefixes…** above the Coverage table and list it (`/api/v1`,
`/tenants/{id}`, …). Listed prefixes are stripped from both the spec and the traffic before
matching. **Suggest** tries the leading 1–3 segments of every path and proposes the prefix that
matches the most extra endpoints.

## What the export contains

- One request per endpoint *per host*. Each captured host gets its own base-URL variable
  (`{{baseUrl}}` for the most-used host, `{{baseUrl_auth_client_com}}` for others). The
  "Base URL override" setting optionally repoints the primary host.
- Request bodies are templated **in place**: JSON keeps its nesting, types and exact numbers;
  form bodies stay form-encoded; XML / text are exported as captured.
- **File uploads** (multipart/form-data) export as Postman *form-data* / Bruno *multipart-form*
  bodies. Text fields are templated like form fields; each uploaded file is saved byte-for-byte
  next to the collection (Postman: `<name>_files/`, Bruno: `<collection>/files/`) and referenced
  from the request. Bruno resolves these paths itself; in Postman, set *Settings > General >
  Working directory* to the export folder so the relative `src` paths resolve. The captured
  `Content-Type` (with its old boundary) is dropped — the client generates a fresh one.
- Only values that matter for chaining become placeholders: path IDs, values that were also
  returned by a response, identifier/token-like names (`userId`, `order_id`, `refreshToken`)
  and credential headers. Generic `id` fields are qualified (`user.id` -> `{{userId}}`, a
  top-level `id` under `/orders` -> `{{orderId}}`). Everything else is exported literally.
- Credentials: `Authorization: Bearer {{accessToken}}` / `Basic {{basicAuth}}`, `Cookie:
  {{cookie}}`, and API-key / token / CSRF-style headers (`X-Api-Key: {{xApiKey}}`). Browser
  noise (User-Agent, sec-*, Accept-Encoding, ...) is dropped.
- The environment holds only the variables the collection uses, with captured values.
  **It contains live credentials** — treat exported environment files as engagement data.
- Endpoints that only ever returned 404/405/410/501 are not exported.

## Live auto-fill (API-only testing)

"Auto-fill live requests" replaces placeholders in outgoing requests (from Proxy and/or
Repeater, ticked under "Apply to") with captured values. Values come from the target's own responses, so each
one is encoded for where it lands — percent-encoded in the path/query, JSON-escaped in JSON
bodies, form-encoded in form bodies, XML-escaped in XML — and **refused** (logged, placeholder
left in place) when it contains CR/LF or other control characters destined for a header, the
URL or a raw body. The request is rewritten part by part through Montoya, so Content-Length is
recomputed from real bytes and HTTP/2 / binary bodies are preserved. Chunked bodies are skipped.

## Layout

    apicollector/
      ApiCollectorExtension     BurpExtension entry point (wires everything, unload handler)
      burp/                     Montoya adapter (the only Burp-coupled code)
        ExchangeSnapshots       HttpRequest/HttpResponse -> RawExchange (copy only, on Burp's thread)
        LiveHttpHandler         capture (tool-filtered) + context-aware live auto-fill
        ProxyHistoryImporter    background, filtered, idempotent proxy-history import
        ProjectPersistence      save / restore state + settings in the Burp project and preferences
        ScopeController         Burp scope vs custom host include-list
      core/                     pure logic, unit-tested with no Burp dependency
        CapturePipeline         single worker, queue bounded by count AND bytes: parse + record off Burp's thread
        ObservationBuilder      RawExchange -> Observation (query, JSON/form/multipart bodies, JSON responses)
        Multipart               byte-exact multipart/form-data parser
        CaptureFilter           size caps, JSON gating, static assets, CORS preflights
        HeaderPolicy            which headers are exported; credential templating
        PathNormalizer + IdentifierHeuristic + PathLearner + EndpointShape   grouping / coverage
        CaptureStore            central state (endpoints per host + known values + coverage)
        ParameterRegistry       bounded known-values store
        CoverageTracker         seen / not found, ignored prefixes + suggestion; CoverageReport (CSV / text)
        StateCodec              CaptureStore <-> gzipped JSON (what ProjectPersistence stores)
        JsonFlattener           JSON body -> leaves (name, parent, exact value)
        CollectionBuilder       captured endpoints -> export IR + environment
        LiveSubstitution, PlaceholderHydrator, Text
      ingest/                   endpoint-list importers (OpenAPI, Postman, Bruno, tabular, freeform)
      export/                   exporter-agnostic IR + Postman/Bruno exporters + Json + writer
      ui/ApiCollectorTab        Swing suite tab
    src/test/java/...           JUnit 5 tests
    src/main/resources/META-INF/services/burp.api.montoya.BurpExtension   ServiceLoader hook

## Design decisions

1. One normalized `EndpointShape` drives BOTH grouping and coverage, so they can never
   disagree about "the same endpoint". Short codes the regex misses (`A7K2Q9`) are learned
   from cardinality: once a path slot has 4 distinct digit-bearing values it collapses.
   Plain words (`/api/users` vs `/api/orders`) and versions (`v1`, `v2`) never merge.
2. The exporter-agnostic `Collection` IR sits between capture and output; exporters read
   only the IR. Adding Insomnia/OpenAPI = one new `CollectionExporter`.
3. Placeholder templating happens at export time, so one app-walk emits Postman OR Bruno
   with no re-capture.
4. Burp's HTTP thread only copies bytes; all parsing runs on one background worker. The queue
   is bounded at 10k items and 256 MB of queued bodies; drops are counted in the status bar
   rather than slowing Burp or filling its heap.
5. Hostile input is bounded: JSON nesting depth 256, bodies over 2 MB are not parsed, at most
   50 values per name and 200k remembered fingerprints.

## Import formats

OpenAPI/Swagger (JSON **and** YAML), Postman collections (incl. API-export wrapped),
Bruno collection folders (`.bru`), Excel `.xlsx`, CSV, and freeform paste. Text files are
read as UTF-8, falling back to Windows-1252 (what Excel writes). YAML uses SnakeYAML's
`SafeConstructor`; Excel uses Apache POI 5.4.1. Both are bundled (and relocated) by the shadow build.

The prebuilt `api-collector.jar` bundles SnakeYAML but not POI, so JSON/YAML/Postman/
Bruno/CSV/text work immediately. Excel needs the packaged build — run `./gradlew shadowJar`;
until then, `.xlsx` import shows a message pointing you to CSV.

## Verify the core without Gradle

    javac -d out $(find src/main -name '*.java' | grep -v /burp/ | grep -v /ui/ | grep -v Extension | grep -v Xlsx | grep -v Yaml | grep -v ImportDispatcher)
    java  -cp out apicollector.demo.CoreDemo
