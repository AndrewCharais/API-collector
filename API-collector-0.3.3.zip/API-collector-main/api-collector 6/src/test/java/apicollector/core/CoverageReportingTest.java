package apicollector.core;

import org.junit.jupiter.api.Test;

import java.util.List;

import static apicollector.core.TestData.*;
import static org.junit.jupiter.api.Assertions.*;

class CoverageReportingTest {
    @Test void ignoredPrefixMatchesGatewayTrafficToSpecPaths() {
        CaptureStore st = new CaptureStore();
        st.importExpected("GET", "/users/{id}", "spec.yaml");
        st.importExpected("POST", "/orders", "spec.yaml");
        st.record(obs("GET", "/api/v1/users/42"));
        st.record(obs("POST", "/api/v1/orders"));
        assertEquals(0, st.coverage().seenExpectedCount());

        var sug = st.coverage().suggestPrefix();
        assertTrue(sug.isPresent());
        assertEquals("/api/v1", sug.get().prefix());
        assertEquals(2, sug.get().gained());

        st.setIgnoredPrefixes(List.of("/api/v1"));
        assertEquals(2, st.coverage().seenExpectedCount());
        var row = st.coverageRows().get(0);
        assertEquals(1, row.hits(), "hits follow the prefix-stripped match");
        assertEquals(200, row.lastStatus());
    }

    @Test void prefixesWorkInTheOtherDirectionAndWithParams() {
        CaptureStore st = new CaptureStore();
        st.importExpected("GET", "/v2/tenants/{t}/items", "spec");
        st.record(obs("GET", "/tenants/7/items"));
        st.setIgnoredPrefixes(List.of("/v2"));
        assertEquals(1, st.coverage().seenExpectedCount());

        CaptureStore st2 = new CaptureStore();
        st2.importExpected("GET", "/items", "spec");
        st2.record(obs("GET", "/tenants/7/items"));
        st2.setIgnoredPrefixes(List.of("/tenants/{id}", "# comment", ""));
        assertEquals(1, st2.coverage().seenExpectedCount());
        assertEquals(List.of("/tenants/{id}"), st2.coverage().ignoredPrefixes());
    }

    @Test void noSuggestionWhenNothingWouldImprove() {
        CaptureStore st = new CaptureStore();
        st.importExpected("GET", "/a", "spec");
        st.record(obs("GET", "/a"));
        assertTrue(st.coverage().suggestPrefix().isEmpty());
    }

    @Test void csvDeliverableKeepsSpecPathsStatusesAndSources() {
        CaptureStore st = new CaptureStore();
        st.importExpected("GET", "/users/{userId}", "client-spec.json");
        st.importExpected("DELETE", "/users/{userId}", "client-spec.json");
        st.importExpected("GET", "/admin/{x}", "notes, v2.csv");
        st.importExpected("POST", "/reports", "client-spec.json");
        st.record(obs("GET", "/users/5"));
        st.record(obs("GET", "/admin/1", 404));
        st.record(obs("POST", "/reports", 403));
        st.record(obs("POST", "/reports", 500));
        String all = CoverageReport.csv(st.coverageRows(), false);
        String[] lines = all.split("\r\n");
        assertEquals("Method,Endpoint,Coverage,Last HTTP status,Status codes seen,Error messages,Hits,Source", lines[0]);
        assertEquals("GET,/users/{userId},Seen,200,200,,1,client-spec.json", lines[1]);
        assertEquals("DELETE,/users/{userId},Not seen,,,,0,client-spec.json", lines[2]);
        assertEquals("GET,/admin/{x},Not found (only 404/405/410/501),404,404,,1,\"notes, v2.csv\"", lines[3]);
        assertEquals("POST,/reports,\"Reached, no successful response\",500,\"403, 500\",,2,client-spec.json", lines[4]);

        String notSeen = CoverageReport.csv(st.coverageRows(), true);
        assertEquals(4, notSeen.split("\r\n").length, notSeen);    // header + not seen + not found + no success
        assertFalse(notSeen.contains(",Seen,"));
        assertTrue(notSeen.contains("POST,/reports,"));
    }

    @Test void onlySuccessfulResponsesCountAsSeen() {
        CaptureStore st = new CaptureStore();
        st.importExpected("GET", "/a", "s"); st.importExpected("GET", "/b", "s");
        st.importExpected("GET", "/c", "s"); st.importExpected("GET", "/d", "s");
        st.record(obs("GET", "/a", 403));                       // forbidden only
        st.record(obs("GET", "/b", 302));                       // redirect (e.g. to login) only
        st.record(obs("GET", "/c", 304));                       // not modified = success
        st.record(obs("GET", "/d", 401));
        st.record(obs("GET", "/d", 201));                       // later succeeds
        var rows = st.coverageRows();
        assertEquals(CoverageTracker.Status.NO_SUCCESS, rows.get(0).status());
        assertEquals(CoverageTracker.Status.NO_SUCCESS, rows.get(1).status());
        assertEquals(CoverageTracker.Status.SEEN, rows.get(2).status());
        assertEquals(CoverageTracker.Status.SEEN, rows.get(3).status());
        assertEquals("201, 401", rows.get(3).statusCodes());
        assertEquals(4, st.coverage().seenExpectedCount(), "all four were reached");
        assertEquals(2, st.coverage().noSuccessExpectedCount());
    }

    @Test void exportUsesASuccessfulExampleWhenThereIsOne() {
        CaptureStore st2 = new CaptureStore();
        var forbidden = raw("GET", "h", "/me?try=1"); forbidden.status = 403;
        st2.record(obs(forbidden));
        st2.record(obs(raw("GET", "h", "/me?try=2")));                                       // 200
        var r = new CollectionBuilder(apicollector.export.PlaceholderStyle.DOUBLE_CURLY)
            .build("c", "L", st2, "").collection().folders.get(0).requests.get(0);
        assertEquals("2", r.query.get(0)[1], "the 200 exchange is exported, not the 403");
    }

    @Test void savedStateWithoutSuccessFlagIsDerivedFromStatusCodes() {
        CaptureStore a = new CaptureStore();
        a.importExpected("GET", "/x", "s"); a.importExpected("GET", "/y", "s");
        a.record(obs("GET", "/x", 200));
        a.record(obs("GET", "/y", 403));
        java.util.Map<String, Object> state = a.exportState();
        for (Object o : (List<?>) state.get("endpoints")) ((java.util.Map<?, ?>) o).remove("succeeded");   // a 0.3.0 save
        CaptureStore b = new CaptureStore();
        b.importState(state);
        assertEquals(CoverageTracker.Status.SEEN, b.coverageRows().get(0).status());
        assertEquals(CoverageTracker.Status.NO_SUCCESS, b.coverageRows().get(1).status());
    }

    @Test void csvCellsCannotBecomeFormulas() {
        assertEquals("\"'=HYPERLINK(\"\"x\"\")\"", CoverageReport.cell("=HYPERLINK(\"x\")"));
        assertEquals("'+1", CoverageReport.cell("+1"));
        assertEquals("'-cmd", CoverageReport.cell("-cmd"));
        assertEquals("'@SUM(A1)", CoverageReport.cell("@SUM(A1)"));
        assertEquals("/plain/path", CoverageReport.cell("/plain/path"));
    }

    @Test void sameEndpointFromTwoFilesListsBothSources() {
        CaptureStore st = new CaptureStore();
        st.importExpected("GET", "/a/{id}", "one.json");
        st.importExpected("GET", "/a/:id", "two.csv");
        var rows = st.coverageRows();
        assertEquals(1, rows.size());
        assertEquals("one.json; two.csv", rows.get(0).sources());
        assertEquals("/a/{id}", rows.get(0).specPath());
    }
}
