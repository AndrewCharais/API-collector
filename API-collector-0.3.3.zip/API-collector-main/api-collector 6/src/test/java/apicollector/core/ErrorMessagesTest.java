package apicollector.core;

import apicollector.model.RawExchange;
import org.junit.jupiter.api.Test;

import java.nio.charset.StandardCharsets;
import java.util.List;

import static apicollector.core.TestData.*;
import static org.junit.jupiter.api.Assertions.*;

class ErrorMessagesTest {
    private static String json(String body) { return ErrorMessages.extract("application/json", body, null); }

    @Test void commonJsonShapes() {
        assertEquals("Access denied", json("{\"message\":\"Access denied\",\"code\":403}"));
        assertEquals("Token expired", json("{\"error\":{\"code\":\"E1\",\"message\":\"Token expired\"}}"));
        assertEquals("The refresh token is invalid", json("{\"error\":\"invalid_grant\",\"error_description\":\"The refresh token is invalid\"}"));
        assertEquals("Insufficient scope", json("{\"error\":\"Insufficient scope\"}"));
        assertEquals("name is required", json("{\"errors\":[{\"field\":\"name\",\"message\":\"name is required\"}]}"));
        assertEquals("quota exceeded", json("{\"errors\":[\"quota exceeded\"]}"));
        assertEquals("Forbidden: You do not own this order", json("{\"type\":\"about:blank\",\"title\":\"Forbidden\",\"detail\":\"You do not own this order\",\"status\":403}"));
        assertEquals("Not allowed", json("\"Not allowed\""));
        assertEquals("Bad thing", json("{\"Message\":\"Bad thing\"}"));          // case-insensitive (ASP.NET style)
        assertNull(json("{\"code\":403,\"ok\":false}"));
    }

    @Test void htmlXmlAndText() {
        assertEquals("403 Forbidden", ErrorMessages.extract("text/html", "<html><head><title>403 Forbidden</title></head><body>…</body></html>", null));
        assertEquals("Internal Server Error", ErrorMessages.extract("text/html", "<html><body><h1>Internal <b>Server</b> Error</h1></body></html>", null));
        assertEquals("Invalid & expired token", ErrorMessages.extract("text/html", "<title>Invalid &amp; expired token</title>", null));
        assertEquals("Server was unable to process request.", ErrorMessages.extract("text/xml",
            "<soap:Envelope><soap:Body><soap:Fault><faultcode>soap:Server</faultcode><faultstring>Server was unable to process request.</faultstring></soap:Fault></soap:Body></soap:Envelope>", null));
        assertEquals("Rate limit exceeded", ErrorMessages.extract("text/plain", "\n\nRate limit exceeded\nRetry after 60s", null));
    }

    @Test void messagesAreCleanedAndCapped() {
        String longMsg = "x".repeat(500);
        String out = json("{\"message\":\"" + longMsg + "\"}");
        assertEquals(ErrorMessages.MAX_LENGTH, out.length());
        assertTrue(out.endsWith("…"));
        assertEquals("line one line two", json("{\"message\":\"line one\\n\\n  line two\"}"));
        assertNull(json("[" .repeat(30_000)));                                   // hostile: no crash, no message
        assertNull(ErrorMessages.extract("text/html", "", null));
    }

    @Test void endToEndIntoCoverageAndCsv() {
        CaptureStore st = new CaptureStore();
        st.importExpected("POST", "/orders/{id}/refund", "spec.json");
        RawExchange a = withJsonResponse(raw("POST", "h", "/orders/9/refund"), "{\"message\":\"Refunds require the finance role\"}");
        a.status = 403;
        RawExchange b = raw("POST", "h", "/orders/9/refund");
        b.status = 500; b.responseContentType = "text/html";
        b.responseBody = "<html><title>Unhandled exception, request id 7f3a</title></html>".getBytes(StandardCharsets.UTF_8);
        b.responseBodyLength = b.responseBody.length;
        st.record(obs(a)); st.record(obs(b));
        var row = st.coverageRows().get(0);
        assertEquals(CoverageTracker.Status.NO_SUCCESS, row.status());
        assertEquals("403: Refunds require the finance role | 500: Unhandled exception, request id 7f3a", row.errors());
        String csv = CoverageReport.csv(List.of(row), true);
        assertTrue(csv.contains(",\"403, 500\",\"403: Refunds require the finance role | 500: Unhandled exception, request id 7f3a\",2,spec.json"), csv);
    }

    @Test void successfulResponsesNeverProduceAMessage() {
        RawExchange ok = withJsonResponse(raw("GET", "h", "/x"), "{\"message\":\"all good\"}");
        assertNull(obs(ok).errorMessage);
    }

    @Test void errorBodiesAreCopiedButBinaryOnesAreNot() {
        assertTrue(CaptureFilter.wantErrorBody("text/html; charset=utf-8", 500, 10_000_000));
        assertTrue(CaptureFilter.wantErrorBody(null, 403, 10));
        assertFalse(CaptureFilter.wantErrorBody("text/html", 302, 100));
        assertFalse(CaptureFilter.wantErrorBody("image/png", 404, 100));
        assertFalse(CaptureFilter.wantErrorBody("application/octet-stream", 500, 100));
    }

    @Test void errorMessagesSurviveSaveAndLoad() {
        CaptureStore a = new CaptureStore();
        a.importExpected("GET", "/admin", "spec");
        RawExchange x = withJsonResponse(raw("GET", "h", "/admin"), "{\"detail\":\"Admins only\"}");
        x.status = 403;
        a.record(obs(x));
        CaptureStore b = new CaptureStore();
        StateCodec.load(b, StateCodec.save(a));
        assertEquals("403: Admins only", b.coverageRows().get(0).errors());
    }
}
