package apicollector.core;

import apicollector.export.Json;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class JsonParsingTest {
    @Test void deepNestingIsRejectedNotStackOverflow() {
        assertThrows(IllegalArgumentException.class, () -> Json.read("[".repeat(20_000)));
        assertTrue(new JsonFlattener().leaves("[".repeat(20_000)).isEmpty());
    }

    @Test void reasonableNestingStillParses() {
        String deep = "[".repeat(200) + "1" + "]".repeat(200);
        assertDoesNotThrow(() -> Json.read(deep));
    }

    @Test void sixtyFourBitIdsAreExact() {
        assertEquals("1234567890123456789", new JsonFlattener().leaves("{\"id\":1234567890123456789}").get(0).value());
        assertEquals("1.50", new JsonFlattener().leaves("{\"p\":1.50}").get(0).value());
    }

    @Test void numbersRoundTripVerbatim() {
        Object tree = Json.read("{\"a\":1234567890123456789,\"b\":1e400,\"c\":true}");
        String out = Json.write(tree);
        assertTrue(out.contains("1234567890123456789"));
        assertTrue(out.contains("1e400"));
        assertTrue(out.contains("true"));
    }

    @Test void truncatedUnicodeEscapeIsAParseErrorNotACrash() {
        assertThrows(IllegalArgumentException.class, () -> Json.read("\"\\u12"));
        assertThrows(IllegalArgumentException.class, () -> Json.read("\"\\uZZZZ\""));
    }

    @Test void rawIsWrittenUnquotedAndStringsEscaped() {
        String out = Json.write(Map.of("n", new Json.Raw("{{qty}}")));
        assertTrue(out.contains("\"n\": {{qty}}"), out);
        assertEquals("a\\\"b\\nc", Json.escape("a\"b\nc"));
    }

    @Test void leavesCarryParentKey() {
        List<JsonFlattener.Leaf> l = new JsonFlattener().leaves("{\"user\":{\"id\":1},\"org\":{\"id\":2}}");
        assertEquals(2, l.size());
        assertEquals("user", l.get(0).parent());
        assertEquals("org", l.get(1).parent());
    }
}
