package apicollector.core;

import apicollector.model.Observation;
import apicollector.model.Observation.BodyKind;
import apicollector.model.RawExchange;
import org.junit.jupiter.api.Test;

import java.nio.charset.StandardCharsets;

import static apicollector.core.TestData.*;
import static org.junit.jupiter.api.Assertions.*;

class ObservationBuilderTest {
    @Test void parsesQueryJsonBodyAndJsonResponse() {
        RawExchange x = withJsonResponse(withJsonBody(raw("post", "API.Example.com", "/api/orders?page=2&q=a%20b"),
            "{\"user\":{\"id\":7},\"qty\":2}"), "{\"orderId\":\"o-1\"}");
        Observation o = obs(x);
        assertEquals("POST", o.method);
        assertEquals("https://api.example.com", o.origin);
        assertEquals("/api/orders", o.path);
        assertEquals("a b", o.queryParams.get("q"));
        assertEquals("a%20b", o.queryRaw.get(1)[1]);
        assertEquals(BodyKind.JSON, o.bodyKind);
        assertEquals("7", o.bodyParams.get("id"));
        assertEquals("o-1", o.responseParams.get("orderId"));
    }

    @Test void nonDefaultPortIsPartOfOrigin() {
        RawExchange x = raw("GET", "h", "/"); x.port = 8443;
        assertEquals("https://h:8443", x.origin());
    }

    @Test void formBodyIsParsedAsForm() {
        RawExchange x = raw("POST", "h", "/login");
        x.requestHeaders.add(new String[]{"Content-Type", "application/x-www-form-urlencoded"});
        x.requestBody = "user=bob&pass=a%26b+c".getBytes(StandardCharsets.UTF_8);
        x.requestBodyLength = x.requestBody.length;
        Observation o = obs(x);
        assertEquals(BodyKind.FORM, o.bodyKind);
        assertEquals("a&b c", o.bodyParams.get("pass"));
    }

    @Test void nonJsonResponseIsIgnored() {
        RawExchange x = raw("GET", "h", "/");
        x.responseContentType = "text/plain";
        x.responseBody = "hello".getBytes(StandardCharsets.UTF_8);
        x.responseBodyLength = 5;
        assertTrue(obs(x).responseParams.isEmpty());
    }

    @Test void oversizedBodyIsFlaggedNotKept() {
        RawExchange x = raw("POST", "h", "/upload");
        x.requestBodyLength = CaptureFilter.MAX_BODY_BYTES + 1;   // snapshot did not copy it
        Observation o = obs(x);
        assertTrue(o.bodyTruncated);
        assertNull(o.bodyText);
    }

    @Test void fingerprintIsStableAndSensitiveToContent() {
        long a = obs(raw("GET", "h", "/a")).fingerprint;
        assertEquals(a, obs(raw("GET", "h", "/a")).fingerprint);
        assertNotEquals(a, obs(raw("GET", "h", "/b")).fingerprint);
    }

    @Test void captureFilterSkipsCorsPreflightAndStatic() {
        assertTrue(CaptureFilter.skip("OPTIONS", "/api/x", true, true));
        assertFalse(CaptureFilter.skip("OPTIONS", "/api/x", false, true));
        assertTrue(CaptureFilter.skip("GET", "/app.js?v=3", false, true));
        assertFalse(CaptureFilter.skip("GET", "/app.js", false, false));
        assertFalse(CaptureFilter.skip("GET", "/api/v1.2/users", false, true));
    }

    @Test void responseBodyGate() {
        assertTrue(CaptureFilter.wantResponseBody("application/json; charset=utf-8", 100));
        assertTrue(CaptureFilter.wantResponseBody("application/vnd.api+json", 100));
        assertFalse(CaptureFilter.wantResponseBody("image/png", 100));
        assertFalse(CaptureFilter.wantResponseBody("application/json", CaptureFilter.MAX_BODY_BYTES + 1));
    }
}
