package apicollector.core;

import apicollector.export.BrunoExporter;
import apicollector.export.Collection;
import apicollector.export.CollectionWriter;
import apicollector.export.PlaceholderStyle;
import apicollector.export.PostmanExporter;
import apicollector.model.Observation;
import apicollector.model.RawExchange;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;

import static apicollector.core.TestData.*;
import static org.junit.jupiter.api.Assertions.*;

class MultipartAndStateTest {
    static final byte[] PNG = {(byte) 0x89, 'P', 'N', 'G', 0, (byte) 0xFF, (byte) 0xFE, '\r', '\n', 0x1A};

    static RawExchange upload() {
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        String bnd = "----WebKitFormBoundaryX7";
        b.writeBytes(("--" + bnd + "\r\nContent-Disposition: form-data; name=\"orderId\"\r\n\r\no-77\r\n").getBytes(StandardCharsets.UTF_8));
        b.writeBytes(("--" + bnd + "\r\nContent-Disposition: form-data; name=\"note\"\r\n\r\nhello\r\n").getBytes(StandardCharsets.UTF_8));
        b.writeBytes(("--" + bnd + "\r\nContent-Disposition: form-data; name=\"file\"; filename=\"C:\\\\evil\\\\..\\\\r\u00e9sum\u00e9.png\"\r\n"
            + "Content-Type: image/png\r\n\r\n").getBytes(StandardCharsets.UTF_8));
        b.writeBytes(PNG);
        b.writeBytes(("\r\n--" + bnd + "--\r\n").getBytes(StandardCharsets.UTF_8));
        RawExchange x = raw("POST", "api.example.com", "/orders/o-77/attachments");
        x.requestHeaders.add(new String[]{"Content-Type", "multipart/form-data; boundary=" + bnd});
        x.requestBody = b.toByteArray();
        x.requestBodyLength = x.requestBody.length;
        return x;
    }

    @Test void multipartIsParsedByteExact() {
        Observation o = obs(upload());
        assertEquals(Observation.BodyKind.MULTIPART, o.bodyKind);
        assertEquals(3, o.parts.size());
        assertEquals("o-77", o.bodyParams.get("orderId"));
        var file = o.parts.get(2);
        assertTrue(file.isFile());
        assertEquals("image/png", file.contentType());
        assertTrue(file.filename().endsWith("r\u00e9sum\u00e9.png"), file.filename());
        assertArrayEquals(PNG, file.data());
    }

    @Test void malformedMultipartFallsBackToRawText() {
        RawExchange x = upload();
        x.requestHeaders.set(0, new String[]{"Content-Type", "multipart/form-data"});   // no boundary
        Observation o = obs(x);
        assertTrue(o.parts.isEmpty());
        CaptureStore st = new CaptureStore(); st.record(o);
        var r = new CollectionBuilder(PlaceholderStyle.DOUBLE_CURLY).build("c", "Local", st, "").collection().folders.get(0).requests.get(0);
        assertEquals("raw", r.bodyMode);
    }

    @Test void uploadsExportAsFormDataWithAttachments() throws Exception {
        CaptureStore st = new CaptureStore();
        st.record(obs(upload()));
        var built = new CollectionBuilder(PlaceholderStyle.DOUBLE_CURLY).build("c", "Local", st, "");
        Collection.Request r = built.collection().folders.get(0).requests.get(0);
        assertEquals("formdata", r.bodyMode);
        assertTrue(r.headers.stream().noneMatch(h -> h[0].equalsIgnoreCase("Content-Type")), "stale boundary header dropped");
        assertEquals("{{orderId}}", r.formParts.get(0).value);        // chained path id -> placeholder
        assertEquals("hello", r.formParts.get(1).value);
        assertEquals("001_r_sum_.png", r.formParts.get(2).attachmentName);   // directories stripped, safe name

        String postman = new PostmanExporter().export(built.collection(), null, "c").get("c.postman_collection.json");
        assertTrue(postman.contains("\"mode\": \"formdata\""));
        assertTrue(postman.contains("\"src\": \"c_files/001_r_sum_.png\""), postman);
        String bru = new BrunoExporter().export(built.collection(), null, "c").values().stream()
            .filter(s -> s.contains("multipart")).findFirst().orElseThrow();
        assertTrue(bru.contains("body: multipartForm"));
        assertTrue(bru.contains("file: @file(files/001_r_sum_.png)"), bru);

        Path dir = Files.createTempDirectory("ac-mp");
        var pm = new PostmanExporter();
        new CollectionWriter().writeBinary(dir, pm.attachments(built.collection(), "c"));
        assertArrayEquals(PNG, Files.readAllBytes(dir.resolve("c_files/001_r_sum_.png")));
        var br = new BrunoExporter();
        new CollectionWriter().writeBinary(dir, br.attachments(built.collection(), "c"));
        assertArrayEquals(PNG, Files.readAllBytes(dir.resolve("c/files/001_r_sum_.png")));
    }

    @Test void stateRoundTripsThroughSaveAndLoad() {
        CaptureStore a = new CaptureStore();
        a.importExpected("GET", "/users/{userId}", "spec.json");
        a.importExpected("DELETE", "/users/{id}", "spec.json");
        a.setIgnoredPrefixes(List.of("/api/v1"));
        a.record(obs(header(raw("GET", "api.example.com", "/api/v1/users/42?page=2"), "Authorization", "Bearer t1")));
        a.record(obs(withJsonResponse(raw("POST", "auth.example.com", "/token"), "{\"refreshToken\":\"r-1\"}")));
        a.record(obs(upload()));
        for (String id : List.of("A7K2Q9", "B8L3R0", "C9M4S1", "D0N5T2")) a.record(obs("GET", "/codes/" + id));
        a.params().setActive("page", "2");
        a.loadCollection(new LoadedCollection("client.json", "{\"u\":\"{{userId}}\"}", PlaceholderStyle.DOUBLE_CURLY));

        byte[] saved = StateCodec.save(a);
        CaptureStore b = new CaptureStore();
        StateCodec.load(b, saved);

        assertEquals(a.endpointCount(), b.endpointCount());
        assertEquals(a.coverageRows(), b.coverageRows());
        assertEquals(a.params().rows(), b.params().rows());
        assertTrue(b.params().isPinned("page"));
        assertEquals(List.of("/api/v1"), b.coverage().ignoredPrefixes());
        assertEquals("client.json", b.collection().fileName());
        assertEquals(a.baseUrlVars(""), b.baseUrlVars(""));

        // exports are identical, including the uploaded file bytes
        var ea = new CollectionBuilder(PlaceholderStyle.DOUBLE_CURLY).build("c", "L", a, "");
        var eb = new CollectionBuilder(PlaceholderStyle.DOUBLE_CURLY).build("c", "L", b, "");
        assertEquals(new PostmanExporter().export(ea.collection(), ea.environment(), "c").toString()
                         .replaceAll("[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}", "ID"),
                     new PostmanExporter().export(eb.collection(), eb.environment(), "c").toString()
                         .replaceAll("[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}", "ID"));
        assertTrue(Arrays.equals(PNG, new PostmanExporter().attachments(eb.collection(), "c").values().iterator().next()));
        // learned path slot survives: a 5th code joins the existing endpoint instead of creating a new one
        b.record(obs("GET", "/codes/E1P6U3"));
        assertEquals(a.endpointCount(), b.endpointCount());
        // fingerprints survive: rescanning an already-captured exchange is skipped
        assertNull(b.record(obs(header(raw("GET", "api.example.com", "/api/v1/users/42?page=2"), "Authorization", "Bearer t1")), true));
    }

    @Test void corruptOrForeignStateIsRejectedCleanly() {
        CaptureStore st = new CaptureStore();
        assertThrows(IllegalArgumentException.class, () -> StateCodec.load(st, "not gzip".getBytes(StandardCharsets.UTF_8)));
        assertEquals(0, st.endpointCount());
    }

    @Test void queueIsBoundedByBytesNotJustCount() {
        CaptureStore st = new CaptureStore();
        CapturePipeline p = new CapturePipeline(st, null, 3_000);     // tiny byte budget for the test
        RawExchange big = raw("GET", "h", "/big");
        big.responseBody = new byte[5_000]; big.responseBodyLength = 5_000;
        assertFalse(p.submit(big), "a snapshot larger than the budget is dropped, not queued");
        assertEquals(1, p.dropped());
        assertEquals(0, p.queuedBytes());
        assertTrue(p.submit(raw("GET", "h", "/small")));
        p.shutdown();
    }
}
