package apicollector.core;

import apicollector.export.Json;
import apicollector.model.Observation;
import apicollector.model.Observation.BodyKind;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/**
 * Serialises a {@link CaptureStore} to bytes (gzipped JSON) and back, so an engagement survives
 * Burp restarts and extension reloads. Pure — the Burp side only stores the bytes in the project.
 */
public final class StateCodec {
    private StateCodec() {}

    public static final int VERSION = 1;
    /** Refuse to inflate more than this (guards against a corrupted or hostile project file). */
    static final int MAX_INFLATED_BYTES = 512 * 1024 * 1024;

    public static byte[] save(CaptureStore store) {
        Map<String, Object> root = new LinkedHashMap<>();
        root.put("version", VERSION);
        root.put("state", store.exportState());
        byte[] json = Json.write(root).getBytes(StandardCharsets.UTF_8);
        ByteArrayOutputStream bos = new ByteArrayOutputStream(Math.max(1024, json.length / 4));
        try (GZIPOutputStream gz = new GZIPOutputStream(bos)) { gz.write(json); }
        catch (IOException e) { throw new IllegalStateException(e); }
        return bos.toByteArray();
    }

    /** @throws IllegalArgumentException if the data is corrupt or from an unknown version. */
    @SuppressWarnings("unchecked")
    public static void load(CaptureStore store, byte[] data) {
        String json;
        try { json = inflate(data); }
        catch (IOException e) { throw new IllegalArgumentException("Saved state is not readable: " + e.getMessage(), e); }
        Object root = Json.read(json);
        if (!(root instanceof Map<?, ?> m)) throw new IllegalArgumentException("Saved state has no root object");
        int v = integer(m.get("version"));
        if (v != VERSION) throw new IllegalArgumentException("Saved state version " + v + " is not supported");
        store.importState((Map<String, Object>) m.get("state"));
    }

    private static String inflate(byte[] data) throws IOException {
        try (InputStream in = new GZIPInputStream(new ByteArrayInputStream(data))) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[64 * 1024];
            for (int n; (n = in.read(buf)) > 0; ) {
                if (out.size() + n > MAX_INFLATED_BYTES) throw new IOException("saved state larger than " + MAX_INFLATED_BYTES + " bytes");
                out.write(buf, 0, n);
            }
            return out.toString(StandardCharsets.UTF_8);
        }
    }

    // ---------------- observation (endpoint representative) ----------------
    static Map<String, Object> observationToMap(Observation o) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("method", o.method);
        m.put("origin", o.origin);
        m.put("path", o.path);
        m.put("status", o.status);
        m.put("queryRaw", pairs(o.queryRaw));
        m.put("headers", pairs(o.headers));
        m.put("bodyKind", o.bodyKind.name());
        if (o.bodyBytes != null) m.put("bodyBytes", Base64.getEncoder().encodeToString(o.bodyBytes));
        else if (o.bodyText != null) m.put("bodyText", o.bodyText);
        m.put("bodyTruncated", o.bodyTruncated);
        return m;
    }

    static Observation observationFromMap(Map<String, Object> m) {
        Observation o = new Observation();
        o.method = String.valueOf(m.get("method"));
        o.origin = String.valueOf(m.getOrDefault("origin", ""));
        o.path = String.valueOf(m.getOrDefault("path", "/"));
        o.status = integer(m.get("status"));
        o.queryRaw.addAll(unpairs(m.get("queryRaw")));
        o.headers.addAll(unpairs(m.get("headers")));
        try { o.bodyKind = BodyKind.valueOf(String.valueOf(m.get("bodyKind"))); } catch (RuntimeException e) { o.bodyKind = BodyKind.NONE; }
        o.bodyTruncated = Boolean.TRUE.equals(m.get("bodyTruncated"));
        if (m.get("bodyBytes") instanceof String b64) {
            o.bodyBytes = Base64.getDecoder().decode(b64);
            o.bodyText = Text.decodeBody(o.bodyBytes);
            if (o.bodyKind == BodyKind.MULTIPART) o.parts.addAll(Multipart.parse(o.bodyBytes, o.header("Content-Type")));
        } else if (m.get("bodyText") instanceof String t) o.bodyText = t;
        return o;
    }

    // ---------------- helpers ----------------
    private static List<Object> pairs(List<String[]> l) {
        List<Object> out = new ArrayList<>(l.size());
        for (String[] p : l) out.add(List.of(p[0], p[1]));
        return out;
    }
    private static List<String[]> unpairs(Object o) {
        List<String[]> out = new ArrayList<>();
        if (o instanceof List<?> l) for (Object p : l)
            if (p instanceof List<?> kv && kv.size() == 2) out.add(new String[]{String.valueOf(kv.get(0)), String.valueOf(kv.get(1))});
        return out;
    }
    static List<String> strings(Object o) {
        List<String> out = new ArrayList<>();
        if (o instanceof List<?> l) for (Object x : l) out.add(String.valueOf(x));
        return out;
    }
    static int integer(Object o) {
        if (o == null) return 0;
        try { return (int) Double.parseDouble(String.valueOf(o)); } catch (NumberFormatException e) { return 0; }
    }
    static String longsToBase64(Collection<Long> longs) {
        ByteBuffer bb = ByteBuffer.allocate(longs.size() * Long.BYTES);
        for (long l : longs) bb.putLong(l);
        return Base64.getEncoder().encodeToString(bb.array());
    }
    static List<Long> base64ToLongs(String b64) {
        List<Long> out = new ArrayList<>();
        if (b64 == null || b64.isEmpty()) return out;
        ByteBuffer bb = ByteBuffer.wrap(Base64.getDecoder().decode(b64));
        while (bb.remaining() >= Long.BYTES) out.add(bb.getLong());
        return out;
    }
}
