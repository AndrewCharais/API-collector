package apicollector.core;

import apicollector.export.Collection;
import apicollector.export.EnvironmentModel;
import apicollector.export.Json;
import apicollector.export.PlaceholderStyle;
import apicollector.model.Endpoint;
import apicollector.model.EndpointShape;
import apicollector.model.MultipartPart;
import apicollector.model.Observation;

import java.util.*;
import java.util.regex.Pattern;

/**
 * Turns captured endpoints into the export IR plus a matching environment. Pure — no Burp, no
 * exporter specifics.
 *
 * <p>What becomes a placeholder (everything else is exported literally, as captured):
 * <ul>
 *   <li>path parameters;</li>
 *   <li>a query/body value that was also seen in a RESPONSE or as a path id for the same name —
 *       i.e. a value chained from another call;</li>
 *   <li>identifier / token-like names ({@code userId}, {@code order_id}, {@code refreshToken});</li>
 *   <li>credential headers (see {@link HeaderPolicy}).</li>
 * </ul>
 * Generic names are qualified so unrelated fields do not share a variable: {@code user.id} ->
 * {@code userId}, a top-level {@code id} under {@code /orders} -> {@code orderId}.
 *
 * <p>Bodies are templated <em>in place</em> on the original text: JSON structure, types and
 * nesting are preserved; form bodies stay form-encoded; XML / multipart / text are kept verbatim.
 * The environment holds only variables the collection actually uses, plus one base URL per host.
 */
public final class CollectionBuilder {
    private static final Pattern ID_LIKE = Pattern.compile(
        "^(?i:_?id|uuid|guid)$|.*[a-z0-9](Id|ID|Uuid|UUID|Guid)$|(?i).*[_-](id|uuid|guid)$|(?i).*token.*");
    private static final Set<String> GENERIC = Set.of("id", "_id", "uuid", "guid");

    private final PlaceholderStyle ph;

    public record Result(Collection collection, EnvironmentModel environment) {}

    public CollectionBuilder(PlaceholderStyle ph) { this.ph = ph; }

    public Result build(String name, String envName, CaptureStore store, String baseUrlOverride) {
        Collection c = new Collection(name);
        EnvironmentModel env = new EnvironmentModel(envName);
        ParameterRegistry reg = store.params();

        Map<String, String> originVars = store.originVarNames();
        store.baseUrlVars(baseUrlOverride).forEach(env::put);
        boolean multiOrigin = originVars.size() > 1;
        int[] attachmentSeq = {0};

        for (Endpoint ep : store.endpoints()) {
            Observation o = ep.representative;
            if (o == null || !ep.reachable) continue;          // never-found routes are not exported
            Ctx x = new Ctx(reg, env, ep.shape);

            Collection.Request r = new Collection.Request();
            r.method = ep.shape.method();
            r.name = ep.shape.method() + " " + ep.shape.displayTemplate()
                   + (multiOrigin ? "  [" + hostOf(ep.origin) + "]" : "");
            String baseVar = originVars.getOrDefault(ep.origin, "baseUrl");
            r.urlTemplate = ph.wrap(baseVar) + pathTemplate(ep.shape, o.path, x);

            for (String[] q : o.queryRaw) {
                String k = Text.urlDecode(q[0], true), v = Text.urlDecode(q[1], true);
                String var = x.templateVar(k, null, v);
                r.query(q[0], var != null ? ph.wrap(var) : q[1]);
            }

            for (String[] h : o.headers) {
                switch (HeaderPolicy.classify(h[0])) {
                    case DROP -> { }
                    case LITERAL -> r.header(h[0], h[1]);
                    case CREDENTIAL -> {
                        String var = HeaderPolicy.varFor(h[0], h[1]);
                        x.put(var, firstNonNull(reg.active(var), HeaderPolicy.credentialValue(h[0], h[1])));
                        r.header(h[0], HeaderPolicy.templated(h[0], h[1], ph));
                    }
                }
            }

            body(o, r, x, attachmentSeq);
            // form-data is re-encoded by the client with a NEW boundary: the captured header would be wrong
            if ("formdata".equals(r.bodyMode)) r.headers.removeIf(h -> h[0].equalsIgnoreCase("Content-Type"));
            c.folder(folderOf(ep.shape)).requests.add(r);
        }
        return new Result(c, env);
    }

    // ---------------- body ----------------
    private void body(Observation o, Collection.Request r, Ctx x, int[] attachmentSeq) {
        if (o.bodyTruncated) {
            r.description = "Request body omitted: larger than " + (CaptureFilter.MAX_BODY_BYTES / (1024 * 1024)) + " MB.";
            return;
        }
        if (o.bodyText == null || o.bodyText.isEmpty()) return;
        if (o.bodyKind == Observation.BodyKind.MULTIPART && !o.parts.isEmpty()) {
            r.bodyMode = "formdata";
            for (MultipartPart part : o.parts) {
                Collection.FormPart fp = new Collection.FormPart();
                fp.key = part.name();
                fp.contentType = part.contentType();
                if (part.isFile()) {
                    fp.type = "file";
                    fp.fileName = part.filename();
                    fp.data = part.data();
                    fp.attachmentName = String.format("%03d_%s", ++attachmentSeq[0], safeFileName(part.filename()));
                } else {
                    String v = Text.decodeBody(part.data());
                    String var = x.templateVar(part.name(), null, v);
                    fp.value = var != null ? ph.wrap(var) : v;
                }
                r.formParts.add(fp);
            }
            return;
        }
        r.bodyMode = "raw";
        switch (o.bodyKind) {
            case JSON -> {
                try {
                    Object tree = Json.read(o.bodyText);
                    r.bodyRaw = Json.write(templateJson(tree, null, null, false, x));
                } catch (RuntimeException | StackOverflowError e) { r.bodyRaw = o.bodyText; }
                r.bodyLanguage = "json";
            }
            case FORM -> { r.bodyRaw = templateForm(o.bodyText, x); r.bodyLanguage = "text"; }
            case XML  -> { r.bodyRaw = o.bodyText; r.bodyLanguage = "xml"; }
            default   -> { r.bodyRaw = o.bodyText; r.bodyLanguage = "text"; }
        }
    }

    /** Walk the parsed body, replacing chained/identifier leaves; keeps order, nesting and types. */
    private Object templateJson(Object node, String key, String parent, boolean inMultiList, Ctx x) {
        if (node instanceof Map<?, ?> m) {
            Map<String, Object> out = new LinkedHashMap<>();
            for (Map.Entry<?, ?> e : m.entrySet())
                out.put(String.valueOf(e.getKey()), templateJson(e.getValue(), String.valueOf(e.getKey()), key, inMultiList, x));
            return out;
        }
        if (node instanceof List<?> l) {
            List<Object> out = new ArrayList<>();
            // several elements would all collapse to ONE variable — keep those literal
            for (Object it : l) out.add(templateJson(it, key, parent, inMultiList || l.size() > 1, x));
            return out;
        }
        if (node == null || key == null || inMultiList) return node;
        String var = x.templateVar(key, parent, String.valueOf(node));
        if (var == null) return node;
        return node instanceof String ? ph.wrap(var) : new Json.Raw(ph.wrap(var));
    }

    private String templateForm(String body, Ctx x) {
        StringBuilder sb = new StringBuilder();
        for (String pair : body.split("&", -1)) {
            if (sb.length() > 0) sb.append('&');
            int eq = pair.indexOf('=');
            if (eq < 0) { sb.append(pair); continue; }
            String k = Text.urlDecode(pair.substring(0, eq), true), v = Text.urlDecode(pair.substring(eq + 1), true);
            String var = x.templateVar(k.trim(), null, v);
            sb.append(var != null ? pair.substring(0, eq) + "=" + ph.wrap(var) : pair);
        }
        return sb.toString();
    }

    // ---------------- path ----------------
    private String pathTemplate(EndpointShape shape, String concretePath, Ctx x) {
        List<String> segs = shape.segments();
        List<String> concrete = new ArrayList<>();
        for (String s : (concretePath == null ? "" : concretePath).split("/")) if (!s.isEmpty()) concrete.add(s);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < segs.size(); i++) {
            sb.append('/');
            if (EndpointShape.PARAM.equals(segs.get(i))) {
                String var = PathParamNamer.nameFor(segs, i);
                String literal = i < concrete.size() ? Text.urlDecode(concrete.get(i), false) : null;
                x.put(var, firstNonNull(x.reg.active(var), literal));
                sb.append(ph.wrap(var));
            } else sb.append(segs.get(i));
        }
        return sb.toString();
    }

    // ---------------- naming ----------------
    /** Per-request context: decides templating and fills the environment. */
    private static final class Ctx {
        final ParameterRegistry reg; final EnvironmentModel env; final EndpointShape shape;
        Ctx(ParameterRegistry reg, EnvironmentModel env, EndpointShape shape) { this.reg = reg; this.env = env; this.shape = shape; }

        /** Variable to use for this field, or null to keep the literal value. */
        String templateVar(String name, String parent, String value) {
            if (name == null || name.isBlank() || value == null || value.isEmpty()) return null;
            boolean chained = reg.seenFrom(name, value, "resp:", "path:");
            if (!chained && !isIdLike(name)) return null;
            String var = qualify(name, parent, shape);
            String envValue = var.equals(name) ? firstNonNull(reg.active(var), value) : value;
            put(var, envValue);
            return var;
        }
        void put(String var, String value) {
            if (value != null && !env.values.containsKey(var)) env.put(var, value);
        }
    }

    static boolean isIdLike(String name) { return ID_LIKE.matcher(name).matches(); }

    /** {@code user.id} -> userId; top-level {@code id} under /orders -> orderId; others unchanged. */
    static String qualify(String name, String parent, EndpointShape shape) {
        if (!GENERIC.contains(name.toLowerCase(Locale.ROOT))) return name;
        String base = parent;
        if (base == null) {
            List<String> segs = shape.segments();
            for (int i = segs.size() - 1; i >= 0 && base == null; i--)
                if (!EndpointShape.PARAM.equals(segs.get(i))) base = segs.get(i);
        }
        if (base == null || base.isBlank()) return name;
        String singular = singular(lowerCamel(base));
        String suffix = name.toLowerCase(Locale.ROOT).contains("uuid") ? "Uuid"
                      : name.toLowerCase(Locale.ROOT).contains("guid") ? "Guid" : "Id";
        return singular + suffix;
    }
    private static String singular(String s) {
        if (s.endsWith("ies") && s.length() > 3) return s.substring(0, s.length() - 3) + "y";
        if (s.endsWith("ses") || s.endsWith("xes")) return s.substring(0, s.length() - 2);
        if (s.endsWith("s") && !s.endsWith("ss") && s.length() > 1) return s.substring(0, s.length() - 1);
        return s;
    }
    private static String lowerCamel(String s) {
        StringBuilder sb = new StringBuilder(); boolean up = false;
        for (char ch : s.toCharArray()) {
            if (!Character.isLetterOrDigit(ch)) { up = sb.length() > 0; continue; }
            sb.append(sb.length() == 0 ? Character.toLowerCase(ch) : up ? Character.toUpperCase(ch) : ch);
            up = false;
        }
        return sb.toString();
    }

    static String safeFileName(String name) {
        String n = name == null ? "" : name.replace('\\', '/');
        n = n.substring(n.lastIndexOf('/') + 1)                      // drop any client-side directory
             .replaceAll("[^A-Za-z0-9._-]+", "_").replaceAll("^[._]+", "");
        return n.isEmpty() ? "file" : n.length() > 80 ? n.substring(n.length() - 80) : n;
    }

    private static String folderOf(EndpointShape shape) {
        for (String s : shape.segments()) if (!EndpointShape.PARAM.equals(s) && !s.equals("api")) return s;
        return "root";
    }
    private static String hostOf(String origin) { return origin == null ? "" : origin.replaceFirst("^[a-zA-Z]+://", ""); }
    private static String firstNonNull(String a, String b) { return a != null ? a : b; }
}
