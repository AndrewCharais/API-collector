package apicollector.core;

import apicollector.model.MultipartPart;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Byte-exact multipart/form-data parser. Works on an ISO-8859-1 view of the bytes (one char per
 * byte) so binary file parts are recovered unchanged. Returns an empty list on anything malformed.
 */
public final class Multipart {
    private Multipart() {}

    public static final int MAX_PARTS = 200;
    private static final Pattern BOUNDARY = Pattern.compile("(?i)boundary=(?:\"([^\"]+)\"|([^;\\s]+))");
    private static final Pattern NAME     = Pattern.compile("(?i)(?:^|;)\\s*name=(?:\"((?:[^\"\\\\]|\\\\.)*)\"|([^;]+))");
    private static final Pattern FILENAME = Pattern.compile("(?i)(?:^|;)\\s*filename=(?:\"((?:[^\"\\\\]|\\\\.)*)\"|([^;]+))");

    public static String boundary(String contentType) {
        if (contentType == null) return null;
        Matcher m = BOUNDARY.matcher(contentType);
        return m.find() ? (m.group(1) != null ? m.group(1) : m.group(2).trim()) : null;
    }

    public static List<MultipartPart> parse(byte[] body, String contentType) {
        List<MultipartPart> out = new ArrayList<>();
        String b = boundary(contentType);
        if (body == null || b == null || b.isEmpty()) return out;
        String view = new String(body, StandardCharsets.ISO_8859_1);
        String delim = "--" + b;
        int pos = view.indexOf(delim);
        if (pos < 0) return out;
        while (out.size() < MAX_PARTS) {
            pos += delim.length();
            if (view.startsWith("--", pos)) break;                       // closing delimiter
            if (view.startsWith("\r\n", pos)) pos += 2; else if (view.startsWith("\n", pos)) pos += 1; else return List.of();
            int hEnd = view.indexOf("\r\n\r\n", pos); int sepLen = 4;
            int lfEnd = view.indexOf("\n\n", pos);
            if (hEnd < 0 || (lfEnd >= 0 && lfEnd < hEnd)) { hEnd = lfEnd; sepLen = 2; }
            if (hEnd < 0) return List.of();
            String headers = view.substring(pos, hEnd);
            int dataStart = hEnd + sepLen;
            int next = view.indexOf("\r\n" + delim, dataStart); int nl = 2;
            int lfNext = view.indexOf("\n" + delim, dataStart);
            if (next < 0 || (lfNext >= 0 && lfNext < next - 1)) { next = lfNext; nl = 1; }
            if (next < 0) return List.of();
            out.add(part(headers, Arrays.copyOfRange(body, dataStart, next)));
            pos = next + nl;
        }
        return out;
    }

    private static MultipartPart part(String headerBlock, byte[] data) {
        String name = null, filename = null, ct = null;
        for (String line : headerBlock.split("\r?\n")) {
            int colon = line.indexOf(':');
            if (colon < 0) continue;
            String h = line.substring(0, colon).trim(), v = utf8(line.substring(colon + 1).trim());
            if (h.equalsIgnoreCase("Content-Disposition")) { name = param(NAME, v); filename = param(FILENAME, v); }
            else if (h.equalsIgnoreCase("Content-Type")) ct = v;
        }
        return new MultipartPart(name == null ? "" : name, filename, ct, data);
    }

    private static String param(Pattern p, String v) {
        Matcher m = p.matcher(v);
        if (!m.find()) return null;
        return m.group(1) != null ? m.group(1).replace("\\\"", "\"").replace("\\\\", "\\") : m.group(2).trim();
    }
    /** Header bytes were read as ISO-8859-1; filenames are usually UTF-8. */
    private static String utf8(String latin1) { return Text.decodeBody(latin1.getBytes(StandardCharsets.ISO_8859_1)); }
}
