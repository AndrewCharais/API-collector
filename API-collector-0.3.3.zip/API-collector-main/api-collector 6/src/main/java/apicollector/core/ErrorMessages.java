package apicollector.core;

import apicollector.export.Json;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Pulls a short, human-readable error message out of an error response body — for the coverage
 * table and CSV. No guessing with one big regex: the body's format decides.
 *
 * <ul>
 *   <li>JSON — the first non-blank string under a well-known key, searched breadth-first
 *       ({@code message}, {@code error_description}, {@code detail}, {@code title}, {@code error},
 *       ...). RFC 7807 problem+json gives "title: detail".</li>
 *   <li>HTML — the {@code <title>}, else the first {@code <h1>}.</li>
 *   <li>XML — {@code <faultstring>}, {@code <message>} or {@code <error>} (SOAP faults, XML APIs).</li>
 *   <li>Text — the first non-blank line.</li>
 * </ul>
 * Results are whitespace-collapsed and capped at {@link #MAX_LENGTH} characters.
 */
public final class ErrorMessages {
    private ErrorMessages() {}

    public static final int MAX_LENGTH = 200;
    private static final int MAX_DEPTH = 4;

    /** Keys tried in order; matching is case-insensitive. */
    private static final List<String> KEYS = List.of(
        "message", "error_description", "errormessage", "error_message", "detail", "details",
        "title", "error", "msg", "reason", "description", "faultstring", "errors");

    private static final Pattern TITLE = Pattern.compile("(?is)<title[^>]*>(.*?)</title>");
    private static final Pattern H1    = Pattern.compile("(?is)<h1[^>]*>(.*?)</h1>");
    private static final Pattern XML_MSG = Pattern.compile(
        "(?is)<(?:[\\w-]+:)?(faultstring|message|error|errorMessage|description)[^>]*>(.*?)</(?:[\\w-]+:)?\\1>");
    private static final Pattern TAGS  = Pattern.compile("(?s)<[^>]*>");

    /** @param jsonTree the already-parsed body when the caller has one (avoids parsing twice), else null. */
    public static String extract(String contentType, String body, Object jsonTree) {
        if (body == null || body.isBlank()) return null;
        String ct = contentType == null ? "" : contentType.toLowerCase(Locale.ROOT);
        String trimmed = body.stripLeading();
        String msg = null;
        if (jsonTree != null || ct.contains("json") || trimmed.startsWith("{") || trimmed.startsWith("[")) {
            Object tree = jsonTree;
            if (tree == null) { try { tree = Json.read(body); } catch (RuntimeException | StackOverflowError notJson) { tree = null; } }
            if (tree != null) msg = fromJson(tree);
        } else if (ct.contains("html") || startsWithIgnoreCase(trimmed, "<!doctype html") || startsWithIgnoreCase(trimmed, "<html")) {
            msg = firstGroup(TITLE, body, 1);
            if (blank(msg)) msg = firstGroup(H1, body, 1);
        } else if (ct.contains("xml") || trimmed.startsWith("<")) {
            msg = firstGroup(XML_MSG, body, 2);
        } else {
            for (String line : body.split("\\R")) if (!line.isBlank()) { msg = line; break; }
        }
        return clean(msg);
    }

    static String fromJson(Object tree) {
        if (tree instanceof Map<?, ?> top) {                      // RFC 7807 problem details
            String title = str(get(top, "title")), detail = str(get(top, "detail"));
            if (!blank(title) && !blank(detail) && !title.equals(detail)) return title + ": " + detail;
        }
        if (tree instanceof String s) return s;                   // a bare JSON string body
        for (String key : KEYS) {
            String v = findString(tree, key);
            if (!blank(v)) return v;
        }
        return null;
    }

    /** Breadth-first: the shallowest string value under {@code key} (or inside a list/object under it). */
    private static String findString(Object root, String key) {
        Deque<Object[]> q = new ArrayDeque<>();
        q.add(new Object[]{root, 0});
        while (!q.isEmpty()) {
            Object[] cur = q.poll();
            Object node = cur[0]; int depth = (int) cur[1];
            if (depth > MAX_DEPTH) continue;
            if (node instanceof Map<?, ?> m) {
                Object hit = get(m, key);
                if (hit instanceof String s && !s.isBlank()) return s;
                if (hit instanceof List<?> l) for (Object it : l) if (it instanceof String s && !s.isBlank()) return s;
                for (Object v : m.values()) q.add(new Object[]{v, depth + 1});
            } else if (node instanceof List<?> l) {
                for (Object v : l) q.add(new Object[]{v, depth + 1});
            }
        }
        return null;
    }

    private static Object get(Map<?, ?> m, String key) {
        for (Map.Entry<?, ?> e : m.entrySet()) if (String.valueOf(e.getKey()).equalsIgnoreCase(key)) return e.getValue();
        return null;
    }
    private static String str(Object o) { return o instanceof String s ? s : null; }
    private static boolean blank(String s) { return s == null || s.isBlank(); }
    private static boolean startsWithIgnoreCase(String s, String p) { return s.regionMatches(true, 0, p, 0, p.length()); }
    private static String firstGroup(Pattern p, String s, int g) { Matcher m = p.matcher(s); return m.find() ? m.group(g) : null; }

    /** Strip tags, decode the common entities, collapse whitespace, cap the length. */
    static String clean(String s) {
        if (blank(s)) return null;
        String t = TAGS.matcher(s).replaceAll(" ")
            .replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&#39;", "'")
            .replace("&apos;", "'").replace("&nbsp;", " ").replace("&amp;", "&");
        t = t.replaceAll("[\\s\\p{Cntrl}]+", " ").trim();
        if (t.isEmpty()) return null;
        return t.length() > MAX_LENGTH ? t.substring(0, MAX_LENGTH - 1) + "…" : t;
    }
}
