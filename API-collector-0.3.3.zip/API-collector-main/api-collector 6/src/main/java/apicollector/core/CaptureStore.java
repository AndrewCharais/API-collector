package apicollector.core;

import apicollector.model.Endpoint;
import apicollector.model.EndpointShape;
import apicollector.model.Observation;

import java.util.*;

/**
 * Central, thread-safe state tying grouping + coverage + known-values together.
 * Montoya-free: fed Observation DTOs. This is the object the UI tabs read from.
 *
 * <p>Endpoints are keyed by origin + shape (so two hosts never merge); coverage is keyed by
 * shape only (a spec has no host). Readers get copies, never live objects.
 */
public final class CaptureStore {
    /** Fingerprints remembered for history-import dedupe. */
    static final int MAX_FINGERPRINTS = 200_000;

    private record Key(String origin, EndpointShape shape) {}

    private final PathNormalizer norm;
    private final PathLearner learner;
    private Map<Key, Endpoint> endpoints = new LinkedHashMap<>();
    private final ParameterRegistry params = new ParameterRegistry();
    private final CoverageTracker coverage = new CoverageTracker();
    private final LinkedHashSet<Long> fingerprints = new LinkedHashSet<>();
    private final Map<String, Integer> originHits = new LinkedHashMap<>();
    private volatile long version;
    private volatile LoadedCollection collection;

    public CaptureStore() { this(new PathNormalizer()); }
    public CaptureStore(PathNormalizer norm) { this(norm, new PathLearner()); }
    public CaptureStore(PathNormalizer norm, PathLearner learner) { this.norm = norm; this.learner = learner; }

    public Endpoint record(Observation o) { return record(o, false); }

    /**
     * Record one observation. With {@code skipIfDuplicate} (proxy-history import) an exchange whose
     * fingerprint was already recorded is ignored, so rescans never double-count.
     *
     * @return a copy of the updated endpoint, or null if skipped.
     */
    public synchronized Endpoint record(Observation o, boolean skipIfDuplicate) {
        if (o == null) return null;
        boolean fresh = fingerprints.add(o.fingerprint);
        if (!fresh && skipIfDuplicate) return null;
        if (fresh && fingerprints.size() > MAX_FINGERPRINTS) {
            Iterator<Long> it = fingerprints.iterator(); it.next(); it.remove();
        }

        EndpointShape shape = learner.apply(norm.shapeObserved(o.method, o.path));
        if (learner.observe(shape)) { shape = learner.apply(shape); relearn(); }

        boolean reachable = CoverageTracker.isReachable(o.status);
        boolean success = CoverageTracker.isSuccess(o.status);
        String origin = o.origin == null ? "" : o.origin;
        Endpoint ep = endpoints.computeIfAbsent(new Key(origin, shape), k -> new Endpoint(k.shape(), k.origin()));
        ep.observe(o, reachable, success);
        coverage.markObserved(shape, reachable, success);
        originHits.merge(origin, 1, Integer::sum);

        recordPathParams(shape, o.path);
        String src = "req:" + shape.canonical();
        o.queryParams.forEach((k, v) -> params.record(k, v, src));
        o.bodyParams.forEach((k, v)  -> params.record(k, v, src));
        // response fields are the important ones (order_id needed as input elsewhere)
        String rsrc = "resp:" + shape.canonical();
        o.responseParams.forEach((k, v) -> params.record(k, v, rsrc));
        // credentials: a constant source per header, so a fresh token always refreshes the active one
        for (String[] h : o.headers) {
            if (HeaderPolicy.classify(h[0]) != HeaderPolicy.Kind.CREDENTIAL) continue;
            params.record(HeaderPolicy.varFor(h[0], h[1]), HeaderPolicy.credentialValue(h[0], h[1]), "hdr:" + h[0]);
        }
        version++;
        return ep.copy();
    }

    private void recordPathParams(EndpointShape shape, String path) {
        List<String> concrete = split(path);
        List<String> shaped = shape.segments();
        for (int i = 0; i < shaped.size() && i < concrete.size(); i++) {
            if (EndpointShape.PARAM.equals(shaped.get(i))) {
                params.record(PathParamNamer.nameFor(shaped, i), Text.urlDecode(concrete.get(i), false), "path:" + shape.canonical());
            }
        }
    }

    /** A slot just became variable: re-key every endpoint and merge the ones that now collide. */
    private void relearn() {
        Map<Key, Endpoint> merged = new LinkedHashMap<>();
        for (Endpoint ep : endpoints.values()) {
            EndpointShape ns = learner.apply(ep.shape);
            Key k = new Key(ep.origin, ns);
            Endpoint into = merged.get(k);
            if (into == null) merged.put(k, ns.equals(ep.shape) ? ep : ep.reshaped(ns));
            else into.mergeFrom(ep);
            if (!ns.equals(ep.shape) && ep.representative != null) recordPathParams(ns, ep.representative.path);
        }
        endpoints = merged;
        coverage.rebuildObserved(endpoints.values());
    }

    /** Add one endpoint from the client's list; {@code source} is the file it came from (for the deliverable). */
    public synchronized void importExpected(String method, String path, String source) {
        coverage.addExpected(norm.shapeExpected(method, path), path, source);
        version++;
    }

    /** Ignored path prefixes for coverage matching (one per entry, e.g. "/api/v1"). */
    public synchronized void setIgnoredPrefixes(List<String> prefixes) { coverage.setIgnoredPrefixes(prefixes); version++; }

    /** One row per imported endpoint: status plus hits / last status of the traffic that matched it. */
    public record CoverageRow(String method, String specPath, String template, CoverageTracker.Status status,
                              int lastStatus, String statusCodes, String errors, int hits, String sources) {}

    public synchronized List<CoverageRow> coverageRows() {
        Map<EndpointShape, int[]> byKey = new HashMap<>();   // key -> {hits, lastStatus, reachableSeen}
        Map<EndpointShape, TreeSet<Integer>> codes = new HashMap<>();
        Map<EndpointShape, TreeMap<Integer, String>> errs = new HashMap<>();
        for (Endpoint e : endpoints.values()) {
            EndpointShape k = coverage.key(e.shape);
            int[] a = byKey.computeIfAbsent(k, x -> new int[3]);
            a[0] += e.count;
            if (a[1] == 0 || (e.reachable && a[2] == 0)) a[1] = e.lastStatus;
            if (e.reachable) a[2] = 1;
            for (int s : e.statuses) if (s > 0) codes.computeIfAbsent(k, x -> new TreeSet<>()).add(s);
            e.errors.forEach((s, msg) -> errs.computeIfAbsent(k, x -> new TreeMap<>()).putIfAbsent(s, msg));
        }
        List<CoverageRow> out = new ArrayList<>();
        for (CoverageTracker.Expected x : coverage.expected()) {
            EndpointShape k = coverage.key(x.shape);
            int[] a = byKey.getOrDefault(k, new int[3]);
            StringJoiner sc = new StringJoiner(", ");
            for (int s : codes.getOrDefault(k, new TreeSet<>())) sc.add(String.valueOf(s));
            StringJoiner em = new StringJoiner(" | ");
            errs.getOrDefault(k, new TreeMap<>()).forEach((s, msg) -> em.add(s + ": " + msg));
            out.add(new CoverageRow(x.method(), x.specPath, x.shape.displayTemplate(), coverage.status(x.shape),
                a[1], sc.toString(), em.toString(), a[0], String.join("; ", x.sources)));
        }
        return out;
    }

    /** The client-provided collection being hydrated, if one is loaded. */
    public LoadedCollection collection() { return collection; }

    public synchronized void loadCollection(LoadedCollection lc) {
        this.collection = lc;
        params.clearWanted();
        if (lc != null) for (String n : lc.placeholderNames()) params.markWanted(n);
        version++;
    }
    public synchronized void unloadCollection() { this.collection = null; params.clearWanted(); version++; }

    /** Bumped on every mutation so the UI can refresh only when something actually changed. */
    public long version() { return version; }
    /** For UI-side changes that live outside the store (e.g. pin/unpin). */
    public void touch() { version++; }

    /** Forget captured traffic (endpoints + known values + seen marks); keeps the imported list. */
    public synchronized void clearCaptured() {
        endpoints.clear(); params.clear(); coverage.clearSeen(); fingerprints.clear(); originHits.clear();
        learner.clear(); version++;
    }
    /** Forget the imported expected-endpoint list; keeps captured traffic. */
    public synchronized void clearExpected() { coverage.clearExpected(); version++; }

    public synchronized void clearAll() {
        clearCaptured(); coverage.clearExpected();
        collection = null; params.clearWanted();   // a full reset drops the loaded client collection too
        version++;
    }

    /** Copies — safe to read without the lock. */
    public synchronized List<Endpoint> endpoints() {
        List<Endpoint> out = new ArrayList<>(endpoints.size());
        for (Endpoint e : endpoints.values()) out.add(e.copy());
        return out;
    }
    public synchronized int endpointCount() { return endpoints.size(); }

    /**
     * One base-URL variable per captured origin, most-hit first: {@code baseUrl}, then
     * {@code baseUrl_auth_client_com}, ... A non-blank override replaces the primary value.
     */
    public synchronized LinkedHashMap<String, String> baseUrlVars(String override) {
        String ov = override == null ? "" : override.trim();
        while (ov.endsWith("/")) ov = ov.substring(0, ov.length() - 1);
        LinkedHashMap<String, String> out = new LinkedHashMap<>();
        for (Map.Entry<String, String> e : originVarNames().entrySet())
            out.put(e.getValue(), out.isEmpty() && !ov.isEmpty() ? ov : e.getKey());
        if (out.isEmpty() && !ov.isEmpty()) out.put("baseUrl", ov);
        return out;
    }

    /** origin -> base-URL variable name, most-hit origin first (that one is {@code baseUrl}). */
    public synchronized LinkedHashMap<String, String> originVarNames() {
        List<Map.Entry<String, Integer>> byHits = new ArrayList<>(originHits.entrySet());
        byHits.removeIf(e -> e.getKey().isEmpty());
        byHits.sort((a, b) -> Integer.compare(b.getValue(), a.getValue()));
        LinkedHashMap<String, String> out = new LinkedHashMap<>();
        Set<String> used = new HashSet<>();
        for (Map.Entry<String, Integer> e : byHits) {
            String var = used.isEmpty() ? "baseUrl" : "baseUrl_" + hostLabel(e.getKey());
            String v = var;
            for (int n = 2; used.contains(v); n++) v = var + "_" + n;
            used.add(v);
            out.put(e.getKey(), v);
        }
        return out;
    }
    static String hostLabel(String origin) {
        String h = origin.replaceFirst("^[a-zA-Z]+://", "");
        return h.replaceAll("[^A-Za-z0-9]+", "_").replaceAll("^_+|_+$", "");
    }

    /** Values for live auto-fill: active known values plus base URLs (override wins for baseUrl). */
    public Map<String, String> substitutionValues(String baseUrlOverride) {
        Map<String, String> values = new LinkedHashMap<>(params.activeSnapshot());
        baseUrlVars(baseUrlOverride).forEach(values::putIfAbsent);
        return values;
    }

    // ---------------- persistence (see StateCodec) ----------------
    /** Everything needed to resume an engagement, as plain maps / lists / strings. */
    synchronized Map<String, Object> exportState() {
        Map<String, Object> out = new LinkedHashMap<>();
        List<Object> eps = new ArrayList<>();
        for (Endpoint e : endpoints.values()) {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("origin", e.origin);
            m.put("method", e.shape.method());
            m.put("segments", e.shape.segments());
            m.put("count", e.count);
            m.put("lastStatus", e.lastStatus);
            m.put("statuses", new ArrayList<>(e.statuses));
            m.put("reachable", e.reachable);
            m.put("succeeded", e.succeeded);
            Map<String, Object> errors = new LinkedHashMap<>();
            e.errors.forEach((s, msg) -> errors.put(String.valueOf(s), msg));
            m.put("errors", errors);
            if (e.representative != null) m.put("rep", StateCodec.observationToMap(e.representative));
            eps.add(m);
        }
        out.put("endpoints", eps);
        out.put("params", params.exportState());
        List<Object> exp = new ArrayList<>();
        for (CoverageTracker.Expected x : coverage.expected()) {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("method", x.shape.method());
            m.put("segments", x.shape.segments());
            m.put("specPath", x.specPath);
            m.put("sources", new ArrayList<>(x.sources));
            exp.add(m);
        }
        out.put("expected", exp);
        out.put("ignoredPrefixes", coverage.ignoredPrefixes());
        out.put("learner", learner.exportState());
        out.put("originHits", new LinkedHashMap<>(originHits));
        out.put("fingerprints", StateCodec.longsToBase64(fingerprints));
        LoadedCollection lc = collection;
        if (lc != null) {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("fileName", lc.fileName());
            m.put("text", lc.text());
            m.put("prefix", lc.style().prefix);
            m.put("suffix", lc.style().suffix);
            out.put("collection", m);
        }
        return out;
    }

    /** Replace all state with a previously exported snapshot. */
    @SuppressWarnings("unchecked")
    synchronized void importState(Map<String, Object> st) {
        endpoints.clear(); params.clear(); coverage.clearSeen(); coverage.clearExpected();
        fingerprints.clear(); originHits.clear(); learner.clear(); collection = null;

        learner.importState((Map<String, Object>) st.getOrDefault("learner", Map.of()));
        for (Object o : (List<Object>) st.getOrDefault("endpoints", List.of())) {
            Map<String, Object> m = (Map<String, Object>) o;
            EndpointShape shape = new EndpointShape(String.valueOf(m.get("method")), StateCodec.strings(m.get("segments")));
            Endpoint e = new Endpoint(shape, String.valueOf(m.getOrDefault("origin", "")));
            e.count = StateCodec.integer(m.get("count"));
            e.lastStatus = StateCodec.integer(m.get("lastStatus"));
            for (Object s : (List<Object>) m.getOrDefault("statuses", List.of())) e.statuses.add(StateCodec.integer(s));
            e.reachable = Boolean.TRUE.equals(m.get("reachable"));
            e.succeeded = m.containsKey("succeeded") ? Boolean.TRUE.equals(m.get("succeeded"))   // 0.3.0 saves lack it:
                        : e.statuses.stream().anyMatch(CoverageTracker::isSuccess);           // derive from status codes
            if (m.get("errors") instanceof Map<?, ?> errors)
                errors.forEach((s, msg) -> e.errors.put(StateCodec.integer(s), String.valueOf(msg)));
            if (m.get("rep") instanceof Map<?, ?> rep) e.representative = StateCodec.observationFromMap((Map<String, Object>) rep);
            endpoints.put(new Key(e.origin, shape), e);
        }
        coverage.rebuildObserved(endpoints.values());
        params.importState((Map<String, Object>) st.getOrDefault("params", Map.of()));

        List<CoverageTracker.Expected> exp = new ArrayList<>();
        for (Object o : (List<Object>) st.getOrDefault("expected", List.of())) {
            Map<String, Object> m = (Map<String, Object>) o;
            var x = CoverageTracker.newExpected(new EndpointShape(String.valueOf(m.get("method")),
                StateCodec.strings(m.get("segments"))), String.valueOf(m.getOrDefault("specPath", "")));
            x.sources.addAll(StateCodec.strings(m.getOrDefault("sources", List.of())));
            exp.add(x);
        }
        coverage.restoreExpected(exp);
        coverage.setIgnoredPrefixes(StateCodec.strings(st.getOrDefault("ignoredPrefixes", List.of())));

        ((Map<String, Object>) st.getOrDefault("originHits", Map.of())).forEach((k, v) -> originHits.put(k, StateCodec.integer(v)));
        fingerprints.addAll(StateCodec.base64ToLongs(String.valueOf(st.getOrDefault("fingerprints", ""))));
        if (st.get("collection") instanceof Map<?, ?> c) {
            Map<String, Object> m = (Map<String, Object>) c;
            var style = new apicollector.export.PlaceholderStyle(String.valueOf(m.get("prefix")), String.valueOf(m.get("suffix")));
            collection = new LoadedCollection(String.valueOf(m.get("fileName")), String.valueOf(m.get("text")), style);
        }
        version++;
    }

    public ParameterRegistry params()  { return params; }
    public CoverageTracker coverage()  { return coverage; }

    private static List<String> split(String p) {
        List<String> out = new ArrayList<>();
        if (p == null) return out;
        int q = p.indexOf('?'); if (q >= 0) p = p.substring(0, q);
        for (String s : p.split("/")) if (!s.isEmpty()) out.add(s);
        return out;
    }
}
