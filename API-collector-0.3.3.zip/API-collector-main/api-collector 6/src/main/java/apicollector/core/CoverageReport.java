package apicollector.core;

import apicollector.core.CaptureStore.CoverageRow;

import java.util.List;

/**
 * Client deliverables built from {@link CaptureStore#coverageRows()}.
 *
 * <p>CSV is RFC-4180 quoted and formula-injection safe: the spec paths come from client-supplied
 * files, so any cell starting with {@code = + - @}, tab or CR is prefixed with an apostrophe before
 * it can be opened in Excel.
 */
public final class CoverageReport {
    private CoverageReport() {}

    public static final String[] HEADER =
        {"Method", "Endpoint", "Coverage", "Last HTTP status", "Status codes seen", "Error messages", "Hits", "Source"};

    /**
     * @param notSeenOnly true = the client deliverable: every endpoint without a successful response
     *                    (not seen, not found, or reached but only errors/redirects).
     */
    public static String csv(List<CoverageRow> rows, boolean notSeenOnly) {
        StringBuilder sb = new StringBuilder();
        line(sb, HEADER);
        for (CoverageRow r : rows) {
            if (notSeenOnly && r.status() == CoverageTracker.Status.SEEN) continue;
            line(sb, r.method(), r.specPath(), label(r.status()),
                 r.lastStatus() == 0 ? "" : String.valueOf(r.lastStatus()), r.statusCodes(), r.errors(),
                 String.valueOf(r.hits()), r.sources());
        }
        return sb.toString();
    }

    public static String label(CoverageTracker.Status s) {
        return switch (s) {
            case SEEN -> "Seen";
            case NO_SUCCESS -> "Reached, no successful response";
            case NOT_FOUND -> "Not found (only 404/405/410/501)";
            case NOT_SEEN -> "Not seen";
        };
    }

    private static void line(StringBuilder sb, String... cells) {
        for (int i = 0; i < cells.length; i++) {
            if (i > 0) sb.append(',');
            sb.append(cell(cells[i]));
        }
        sb.append("\r\n");
    }

    static String cell(String v) {
        String s = v == null ? "" : v;
        if (!s.isEmpty() && "=+-@\t\r".indexOf(s.charAt(0)) >= 0) s = "'" + s;
        boolean quote = s.indexOf(',') >= 0 || s.indexOf('"') >= 0 || s.indexOf('\n') >= 0 || s.indexOf('\r') >= 0
                     || s.startsWith(" ") || s.endsWith(" ");
        return quote ? '"' + s.replace("\"", "\"\"") + '"' : s;
    }
}
