package apicollector.core;

import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.regex.Pattern;

/**
 * Conservative "is this path segment an identifier?" test. Bias is toward LITERAL:
 * a segment is only treated as an id when it clearly looks like one, so real route
 * words (users, v1, me, search) are never collapsed.
 */
public final class IdentifierHeuristic {
    private static final Pattern NUMERIC   = Pattern.compile("^\\d+$");
    private static final Pattern UUID      = Pattern.compile(
        "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$");
    private static final Pattern HEX32     = Pattern.compile("^[0-9a-fA-F]{32}$");
    private static final Pattern OBJECTID  = Pattern.compile("^[0-9a-fA-F]{24}$");
    /** 2024-01-31, 2024-01-31T10:15:00Z, 2024-01-31T10:15:00.123+02:00 */
    private static final Pattern DATE      = Pattern.compile(
        "^\\d{4}-\\d{2}-\\d{2}([T ]\\d{2}:\\d{2}(:\\d{2}(\\.\\d+)?)?(Z|[+-]\\d{2}:?\\d{2})?)?$");
    private static final Pattern HAS_DIGIT = Pattern.compile(".*\\d.*");
    private static final Pattern TOKENISH  = Pattern.compile("^[A-Za-z0-9_.~-]+$");

    private static final int LONG_TOKEN_MIN_LENGTH = 16;

    public boolean looksLikeIdentifier(String segment) {
        if (segment == null || segment.isEmpty()) return false;
        String s = decode(segment);
        if (NUMERIC.matcher(s).matches())  return true;
        if (UUID.matcher(s).matches())     return true;
        if (HEX32.matcher(s).matches())    return true;
        if (OBJECTID.matcher(s).matches()) return true;
        if (DATE.matcher(s).matches())     return true;
        return s.length() >= LONG_TOKEN_MIN_LENGTH
            && HAS_DIGIT.matcher(s).matches()
            && TOKENISH.matcher(s).matches();
    }

    private static String decode(String s) {
        try { return URLDecoder.decode(s, StandardCharsets.UTF_8); }
        catch (Exception e) { return s; }
    }
}
