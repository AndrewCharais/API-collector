package apicollector.core;

import apicollector.export.PlaceholderStyle;

import java.util.*;
import java.util.regex.Matcher;

/**
 * A client-provided collection held in memory while testing. Its placeholders are the
 * "shopping list" of values to capture; as traffic is walked, they resolve. Format-agnostic
 * (Postman JSON, Bruno, raw dumps) because matching is text-level.
 */
public final class LoadedCollection {
    private final String fileName;
    private final String text;
    private final PlaceholderStyle style;
    private final List<String> placeholders;   // distinct, in first-seen order

    public LoadedCollection(String fileName, String text, PlaceholderStyle style) {
        this.fileName = fileName == null ? "collection" : fileName;
        this.text = text == null ? "" : text;
        this.style = style;
        LinkedHashSet<String> found = new LinkedHashSet<>();
        Matcher m = style.pattern().matcher(this.text);
        while (m.find()) found.add(m.group(1));
        this.placeholders = new ArrayList<>(found);
    }

    public String fileName() { return fileName; }
    public String text() { return text; }
    public PlaceholderStyle style() { return style; }
    public List<String> placeholderNames() { return Collections.unmodifiableList(placeholders); }
    public int distinctPlaceholders() { return placeholders.size(); }

    /** Placeholder names that have no value yet in the registry. */
    public List<String> unresolved(ParameterRegistry reg) {
        List<String> out = new ArrayList<>();
        for (String p : placeholders) if (reg.active(p) == null) out.add(p);
        return out;
    }
    public int resolvedCount(ParameterRegistry reg) {
        return placeholders.size() - unresolved(reg).size();
    }

}
