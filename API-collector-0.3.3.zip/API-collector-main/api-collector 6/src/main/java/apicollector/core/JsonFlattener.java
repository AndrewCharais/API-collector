package apicollector.core;

import apicollector.export.Json;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Flattens a JSON body into leaf field-name -> value pairs, which is how the Known Values
 * registry keys things. Used for request AND response bodies.
 *
 * <p>Numbers keep their exact source text (no double rounding). {@link #leaves} also reports the
 * nearest enclosing object key, so generic names like {@code id} can be qualified later.
 */
public final class JsonFlattener {
    /** One scalar leaf: its key, the key of the object that holds it (or null), and the value. */
    public record Leaf(String name, String parent, String value) {}

    /** Every scalar leaf in document order. Non-JSON or hostile input yields an empty list. */
    public List<Leaf> leaves(String jsonBody) {
        List<Leaf> out = new ArrayList<>();
        if (jsonBody == null || jsonBody.isBlank()) return out;
        Object root;
        try { root = Json.read(jsonBody); } catch (RuntimeException notJson) { return out; }
        walk(null, null, root, out);
        return out;
    }

    /** Parse an already-decoded tree (e.g. from {@link Json#read}). */
    public List<Leaf> leaves(Object tree) {
        List<Leaf> out = new ArrayList<>();
        walk(null, null, tree, out);
        return out;
    }

    private void walk(String key, String parent, Object node, List<Leaf> out) {
        if (node instanceof Map<?, ?> m) {
            for (Map.Entry<?, ?> e : m.entrySet()) walk(String.valueOf(e.getKey()), key, e.getValue(), out);
        } else if (node instanceof List<?> l) {
            for (Object it : l) walk(key, parent, it, out); // array elements keep the field name
        } else if (key != null && node != null) {
            out.add(new Leaf(key, parent, String.valueOf(node)));
        }
    }
}
