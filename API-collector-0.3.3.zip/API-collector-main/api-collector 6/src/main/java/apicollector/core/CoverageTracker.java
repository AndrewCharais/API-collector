package apicollector.core;

import apicollector.model.Endpoint;
import apicollector.model.EndpointShape;

import java.util.*;

/**
 * Expected (from spec) vs observed (from traffic), compared on EndpointShape.
 *
 * <p>An endpoint only counts as SEEN when a response showed it exists. One that only ever returned
 * 404 / 405 / 410 / 501 (or no response) is NOT_FOUND and stays on the not-seen deliverable.
 *
 * <p><b>Ignored prefixes.</b> When traffic goes through a gateway ({@code /api/v1/users/42}) but the
 * spec says {@code /users/{id}} — or the other way round — list the prefix once and it is stripped
 * from BOTH sides before matching. {@link #suggestPrefix} finds the prefix that matches the most.
 */
public final class CoverageTracker {
    /**
     * SEEN = at least one successful (2xx / 304) response. NO_SUCCESS = the route answered, but only
     * with errors or redirects (401, 403, 400, 500, 302 to login, ...). NOT_FOUND = only 404 / 405 /
     * 410 / 501. NOT_SEEN = never requested.
     */
    public enum Status { SEEN, NO_SUCCESS, NOT_FOUND, NOT_SEEN }

    /** One endpoint from the imported list: its shape, the path as the client wrote it, and where it came from. */
    public static final class Expected {
        public final EndpointShape shape;
        public final String specPath;
        public final Set<String> sources = new LinkedHashSet<>();
        Expected(EndpointShape shape, String specPath) { this.shape = shape; this.specPath = specPath; }
        Expected copy() { Expected e = new Expected(shape, specPath); e.sources.addAll(sources); return e; }
        public String method() { return shape.method(); }
    }

    /** A suggested prefix and how many more expected endpoints it would match. */
    public record Suggestion(String prefix, int gained) {}

    private final Map<EndpointShape, Expected> expected = new LinkedHashMap<>();
    private final Set<EndpointShape> seen     = new LinkedHashSet<>();
    private final Set<EndpointShape> notFound = new LinkedHashSet<>();
    private final Set<EndpointShape> succeeded = new LinkedHashSet<>();
    private List<List<String>> prefixes = List.of();      // longest first
    private List<String> prefixText = List.of();
    private Set<EndpointShape> seenKeys, notFoundKeys, successKeys;   // cached, null when stale

    /** Did this response prove the route exists? */
    public static boolean isReachable(int status) {
        return status >= 100 && status != 404 && status != 405 && status != 410 && status != 501;
    }

    /** Did this response succeed? 2xx, or 304 Not Modified. Redirects (e.g. to a login page) do not count. */
    public static boolean isSuccess(int status) {
        return (status >= 200 && status < 300) || status == 304;
    }

    public synchronized void addExpected(EndpointShape s, String specPath, String source) {
        Expected e = expected.computeIfAbsent(s, k -> new Expected(k, specPath == null || specPath.isBlank() ? k.displayTemplate() : specPath));
        if (source != null && !source.isBlank()) e.sources.add(source);
    }

    public synchronized void markObserved(EndpointShape s, boolean reachable, boolean success) {
        if (reachable) { if (seen.add(s) | notFound.remove(s)) stale(); }
        else if (!seen.contains(s) && notFound.add(s)) stale();
        if (success && succeeded.add(s)) stale();
    }

    /** Recompute observed sets from endpoints (after path learning merges shapes). */
    public synchronized void rebuildObserved(Collection<Endpoint> endpoints) {
        seen.clear(); notFound.clear(); succeeded.clear(); stale();
        for (Endpoint ep : endpoints) markObserved(ep.shape, ep.reachable, ep.succeeded);
    }

    // ---------------- prefixes ----------------
    /** One prefix per line, e.g. "/api/v1" or "/tenants/{id}". Blank lines and #comments ignored. */
    public synchronized void setIgnoredPrefixes(List<String> lines) {
        List<String> text = new ArrayList<>();
        List<List<String>> segs = new ArrayList<>();
        for (String raw : lines == null ? List.<String>of() : lines) {
            String l = raw.trim();
            if (l.isEmpty() || l.startsWith("#")) continue;
            List<String> s = segments(l);
            if (!s.isEmpty() && !segs.contains(s)) { segs.add(s); text.add(l); }
        }
        segs.sort((a, b) -> Integer.compare(b.size(), a.size()));
        prefixes = List.copyOf(segs);
        prefixText = List.copyOf(text);
        stale();
    }
    public synchronized List<String> ignoredPrefixes() { return prefixText; }

    /** The shape used for matching: the longest ignored prefix stripped (if it leaves something). */
    public synchronized EndpointShape key(EndpointShape s) { return strip(s, prefixes); }

    private static EndpointShape strip(EndpointShape s, List<List<String>> prefixes) {
        List<String> segs = s.segments();
        for (List<String> p : prefixes) {
            if (segs.size() <= p.size()) continue;
            boolean match = true;
            for (int i = 0; i < p.size() && match; i++) match = p.get(i).equals(segs.get(i));
            if (match) return new EndpointShape(s.method(), segs.subList(p.size(), segs.size()));
        }
        return s;
    }

    static List<String> segments(String path) {
        List<String> out = new ArrayList<>();
        for (String seg : path.split("/")) {
            if (seg.isEmpty()) continue;
            boolean param = (seg.startsWith("{") && seg.endsWith("}")) || (seg.startsWith(":") && seg.length() > 1);
            out.add(param ? EndpointShape.PARAM : seg);
        }
        return out;
    }

    private void stale() { seenKeys = null; notFoundKeys = null; successKeys = null; }
    private void ensureKeys() {
        if (seenKeys != null) return;
        seenKeys = new HashSet<>(); notFoundKeys = new HashSet<>(); successKeys = new HashSet<>();
        for (EndpointShape s : seen) seenKeys.add(strip(s, prefixes));
        for (EndpointShape s : succeeded) successKeys.add(strip(s, prefixes));
        for (EndpointShape s : notFound) notFoundKeys.add(strip(s, prefixes));
        notFoundKeys.removeAll(seenKeys);
    }

    // ---------------- queries ----------------
    public synchronized Status status(EndpointShape expectedShape) {
        ensureKeys();
        EndpointShape k = strip(expectedShape, prefixes);
        if (successKeys.contains(k)) return Status.SEEN;
        if (seenKeys.contains(k)) return Status.NO_SUCCESS;
        if (notFoundKeys.contains(k)) return Status.NOT_FOUND;
        return Status.NOT_SEEN;
    }

    /** Every imported endpoint, in import order (copies). */
    public synchronized List<Expected> expected() {
        List<Expected> out = new ArrayList<>(expected.size());
        for (Expected e : expected.values()) out.add(e.copy());
        return out;
    }
    public synchronized int expectedCount() { return expected.size(); }
    /** Imported endpoints that were reached at all (SEEN or NO_SUCCESS) — the coverage figure. */
    public synchronized int seenExpectedCount() {
        int n = 0;
        for (EndpointShape e : expected.keySet()) { Status s = status(e); if (s == Status.SEEN || s == Status.NO_SUCCESS) n++; }
        return n;
    }
    /** Imported endpoints that answered but never successfully. */
    public synchronized int noSuccessExpectedCount() {
        int n = 0; for (EndpointShape e : expected.keySet()) if (status(e) == Status.NO_SUCCESS) n++; return n;
    }
    public synchronized void clearExpected() { expected.clear(); }
    public synchronized void clearSeen() { seen.clear(); notFound.clear(); succeeded.clear(); stale(); }

    // ---------------- prefix suggestion ----------------
    /**
     * Try the leading 1–3 segments of every expected and observed path as an ignored prefix (on top
     * of the current ones) and return the one that matches the most extra expected endpoints.
     */
    public synchronized Optional<Suggestion> suggestPrefix() {
        Set<List<String>> candidates = new LinkedHashSet<>();
        for (EndpointShape s : expected.keySet()) addCandidates(strip(s, prefixes).segments(), candidates);
        for (EndpointShape s : seen) addCandidates(strip(s, prefixes).segments(), candidates);
        int base = matches(prefixes);
        Suggestion best = null;
        for (List<String> c : candidates) {
            if (prefixes.contains(c)) continue;
            List<List<String>> trial = new ArrayList<>(prefixes);
            trial.add(c);
            trial.sort((a, b) -> Integer.compare(b.size(), a.size()));
            int gained = matches(trial) - base;
            if (gained > 0 && (best == null || gained > best.gained()))
                best = new Suggestion("/" + String.join("/", c).replace(EndpointShape.PARAM, "{id}"), gained);
        }
        return Optional.ofNullable(best);
    }
    private static void addCandidates(List<String> segs, Set<List<String>> out) {
        for (int n = 1; n <= 3 && n < segs.size(); n++) out.add(List.copyOf(segs.subList(0, n)));
    }
    private int matches(List<List<String>> pfx) {
        Set<EndpointShape> keys = new HashSet<>();
        for (EndpointShape s : seen) keys.add(strip(s, pfx));
        int n = 0;
        for (EndpointShape e : expected.keySet()) if (keys.contains(strip(e, pfx))) n++;
        return n;
    }

    // ---------------- persistence ----------------
    synchronized void restoreExpected(List<Expected> list) {
        expected.clear();
        for (Expected e : list) expected.put(e.shape, e);
    }
    static Expected newExpected(EndpointShape shape, String specPath) { return new Expected(shape, specPath); }
}
