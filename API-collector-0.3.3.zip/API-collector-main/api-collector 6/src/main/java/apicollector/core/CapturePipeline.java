package apicollector.core;

import apicollector.model.RawExchange;

import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.BiConsumer;

/**
 * Moves parsing + recording off Burp's HTTP thread. Burp hands us a cheap {@link RawExchange}
 * snapshot; a single worker builds the Observation and records it.
 *
 * <p>The queue is bounded twice — by item count AND by the bytes the queued snapshots hold — so a
 * burst of large bodies can never pile gigabytes into Burp's heap. When full we drop (and count)
 * rather than block Burp's traffic.
 */
public final class CapturePipeline {
    public static final int QUEUE_CAPACITY = 10_000;
    public static final long MAX_QUEUED_BYTES = 256L * 1024 * 1024;

    private final CaptureStore store;
    private final ObservationBuilder builder = new ObservationBuilder();
    private final BiConsumer<String, Throwable> errorLog;
    private final AtomicLong dropped = new AtomicLong();
    private final AtomicLong queuedBytes = new AtomicLong();
    private final long maxQueuedBytes;
    private final ThreadPoolExecutor exec;

    /** A queued exchange that knows how many bytes it holds. */
    private final class Task implements Runnable {
        final RawExchange x; final long bytes;
        Task(RawExchange x) { this.x = x; this.bytes = sizeOf(x); }
        @Override public void run() {
            try { process(x, false); } finally { queuedBytes.addAndGet(-bytes); }
        }
    }

    public CapturePipeline(CaptureStore store, BiConsumer<String, Throwable> errorLog) {
        this(store, errorLog, MAX_QUEUED_BYTES);
    }
    CapturePipeline(CaptureStore store, BiConsumer<String, Throwable> errorLog, long maxQueuedBytes) {
        this.store = store;
        this.errorLog = errorLog == null ? (m, t) -> { } : errorLog;
        this.maxQueuedBytes = maxQueuedBytes;
        this.exec = new ThreadPoolExecutor(1, 1, 0L, TimeUnit.MILLISECONDS,
            new ArrayBlockingQueue<>(QUEUE_CAPACITY),
            r -> { Thread t = new Thread(r, "api-collector-capture"); t.setDaemon(true); return t; },
            (r, e) -> {                                   // count-bound hit (or shut down): release its bytes
                dropped.incrementAndGet();
                if (r instanceof Task t) queuedBytes.addAndGet(-t.bytes);
            });
    }

    /** Non-blocking. Returns false when the exchange was dropped (queue full by count or bytes, or shut down). */
    public boolean submit(RawExchange x) {
        if (exec.isShutdown()) return false;
        Task t = new Task(x);
        if (queuedBytes.addAndGet(t.bytes) > maxQueuedBytes) {
            queuedBytes.addAndGet(-t.bytes);
            dropped.incrementAndGet();
            return false;
        }
        long before = dropped.get();
        exec.execute(t);
        return dropped.get() == before;
    }

    /** Synchronous variant for the proxy-history importer (already on its own background thread). */
    public boolean processNow(RawExchange x) { return process(x, true); }

    private boolean process(RawExchange x, boolean skipIfDuplicate) {
        try {
            return store.record(builder.build(x), skipIfDuplicate) != null;
        } catch (Exception | StackOverflowError e) {   // never let hostile input kill the worker
            errorLog.accept("API Collector capture error", e);
            return false;
        }
    }

    static long sizeOf(RawExchange x) {
        long n = 512 + (x.path == null ? 0 : x.path.length());
        for (String[] h : x.requestHeaders) n += h[0].length() + h[1].length() + 32;
        if (x.requestBody != null) n += x.requestBody.length;
        if (x.responseBody != null) n += x.responseBody.length;
        return n;
    }

    public long dropped() { return dropped.get(); }
    long queuedBytes() { return queuedBytes.get(); }

    public void shutdown() { exec.shutdownNow(); }
}
