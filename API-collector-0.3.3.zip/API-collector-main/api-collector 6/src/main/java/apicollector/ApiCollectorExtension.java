package apicollector;

import apicollector.burp.*;
import apicollector.core.CapturePipeline;
import apicollector.core.CaptureStore;
import apicollector.ui.ApiCollectorTab;
import burp.api.montoya.BurpExtension;
import burp.api.montoya.MontoyaApi;

import java.util.concurrent.atomic.AtomicBoolean;

/** Entry point. Registered via META-INF/services/burp.api.montoya.BurpExtension. */
public final class ApiCollectorExtension implements BurpExtension {
    @Override public void initialize(MontoyaApi api) {
        api.extension().setName("API Collector");

        CaptureStore store = new CaptureStore();
        // Resume the engagement saved in this Burp project, if any (before history backfill, so its
        // fingerprints stop the backfill from double-counting).
        ProjectPersistence persistence = new ProjectPersistence(api, store);
        if (persistence.restoreState())
            api.logging().logToOutput("API Collector: restored " + store.endpointCount() + " endpoints and "
                + store.coverage().expectedCount() + " imported endpoints from this project.");
        ScopeController scope = new ScopeController(api);
        CapturePipeline pipeline = new CapturePipeline(store, (msg, err) -> api.logging().logToError(msg, err));

        // Live capture: every in-scope Proxy response is recorded automatically, no clicking.
        LiveHttpHandler handler = new LiveHttpHandler(store, scope, pipeline, api);
        api.http().registerHttpHandler(handler);

        ApiCollectorTab tab = new ApiCollectorTab(api, store, scope, pipeline, handler,
            persistence.loadProjectSettings(), persistence.loadPreferences());
        api.userInterface().registerSuiteTab("API Collector", tab.component());
        persistence.start(tab::projectSettings, tab::preferences);

        // Also backfill anything already in proxy history, off the UI thread so load isn't blocked.
        AtomicBoolean unloading = new AtomicBoolean(false);
        Thread backfill = new Thread(() -> {
            try {
                var r = new ProxyHistoryImporter().importInto(api, handler, pipeline, unloading::get, null);
                api.logging().logToOutput("API Collector: backfilled " + r.added() + " in-scope items from proxy history.");
            } catch (Exception e) {
                if (!unloading.get()) api.logging().logToError("API Collector: proxy history backfill failed", e);
            }
        }, "api-collector-backfill");
        backfill.setDaemon(true);
        backfill.start();

        // Stop every timer / thread we started, so unload + reload never leaves stale work behind.
        api.extension().registerUnloadingHandler(() -> {
            unloading.set(true);
            handler.setEnabled(false);
            handler.setSubstituteLive(false);
            tab.dispose();
            backfill.interrupt();
            pipeline.shutdown();
            persistence.stop();          // final save into the project
        });

        api.logging().logToOutput("API Collector loaded — capturing in-scope traffic automatically. Walk the app, then Export.");
    }
}
