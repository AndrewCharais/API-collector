package apicollector.ui;

import apicollector.burp.*;
import apicollector.core.*;
import apicollector.export.*;
import apicollector.ingest.ImportDispatcher;
import apicollector.ingest.ImportedEndpoint;
import apicollector.model.Endpoint;
import burp.api.montoya.MontoyaApi;
import burp.api.montoya.core.ToolType;

import javax.swing.*;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.awt.datatransfer.StringSelection;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.*;

/**
 * Single-page UI: a collapsible Scope + settings strip at the top, then the working area
 * (coverage + captured values). Layout of the working area is chosen by {@link Layout} so
 * the two arrangements can be compared. Refresh is driven by CaptureStore.version().
 */
public final class ApiCollectorTab {

    private final MontoyaApi api;
    private final CaptureStore store;
    private final ScopeController scope;
    private final CapturePipeline pipeline;
    private final LiveHttpHandler handler;
    private final ImportDispatcher dispatcher = new ImportDispatcher();

    private final CoverageModel coverageModel = new CoverageModel();
    private final KnownValuesModel kvModel = new KnownValuesModel();
    private final JPanel root = new JPanel(new BorderLayout(6, 6));
    private final JLabel status = new JLabel();

    private final JComboBox<String> formatBox = new JComboBox<>(new String[]{"Postman v2.1", "Bruno"});
    private final JTextField placeholderField = new JTextField("{{name}}", 10);
    private final JTextField collectionNameField = new JTextField("Client API", 14);
    /** Optional: replaces the captured primary host in exports / auto-fill. Blank = use captured hosts. */
    private final JTextField baseUrlField = new JTextField("", 20);
    private final JTextArea hostArea = new JTextArea(4, 24);
    // auto-fill (live) settings — deliberately separate from the export placeholder format
    private final JTextField matchFormatsField = new JTextField("{{name}}", 14);
    private final JCheckBox preferLatestBox = new JCheckBox("Auto-refresh from same call", true);
    private final JCheckBox skipStaticBox = new JCheckBox("Ignore static assets", true);
    private final Map<ToolType, JCheckBox> toolBoxes = new LinkedHashMap<>();
    private final Map<ToolType, JCheckBox> captureBoxes = new LinkedHashMap<>();

    private long lastVersion = -1;
    private final javax.swing.Timer timer;
    private JTable kvTable;
    private JButton historyBtn;
    private volatile boolean disposed;
    private SwingWorker<?, ?> historyWorker;
    private JRadioButton burpScopeRadio, customScopeRadio;
    /** Settings snapshots, refreshed on the EDT each tick so the background saver can read them safely. */
    private volatile Map<String, String> projectSettingsCache = Map.of(), preferencesCache = Map.of();

    /**
     * @param projectSettings saved per-engagement settings (scope, capture sources, base URL, collection name)
     * @param preferences     saved personal preferences (formats, export format, auto-fill tools, toggles)
     */
    public ApiCollectorTab(MontoyaApi api, CaptureStore store, ScopeController scope, CapturePipeline pipeline,
                           LiveHttpHandler handler, Map<String, String> projectSettings, Map<String, String> preferences) {
        this.api = api; this.store = store; this.scope = scope;
        this.pipeline = pipeline; this.handler = handler;

        root.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        root.add(topStrip(), BorderLayout.NORTH);
        root.add(workingArea(), BorderLayout.CENTER);
        root.add(status, BorderLayout.SOUTH);

        applySettings(projectSettings == null ? Map.of() : projectSettings, preferences == null ? Map.of() : preferences);
        syncHandlerSettings();
        cacheSettings();

        timer = new javax.swing.Timer(1000, e -> { refreshIfChanged(); cacheSettings(); });
        timer.start();
    }

    // ---------------- saved settings ----------------
    public Map<String, String> projectSettings() { return projectSettingsCache; }
    public Map<String, String> preferences() { return preferencesCache; }

    private void cacheSettings() {
        Map<String, String> p = new LinkedHashMap<>();
        p.put("scopeMode", customScopeRadio.isSelected() ? "CUSTOM" : "BURP");
        p.put("hosts", hostArea.getText());
        p.put("captureTools", selectedTools(captureBoxes));
        p.put("baseUrlOverride", baseUrlField.getText());
        p.put("collectionName", collectionNameField.getText());
        Map<String, String> q = new LinkedHashMap<>();
        q.put("placeholder", placeholderField.getText());
        q.put("matchFormats", matchFormatsField.getText());
        q.put("exportFormat", String.valueOf(formatBox.getSelectedIndex()));
        q.put("autofillTools", selectedTools(toolBoxes));
        q.put("skipStatic", String.valueOf(skipStaticBox.isSelected()));
        q.put("autoRefresh", String.valueOf(preferLatestBox.isSelected()));
        projectSettingsCache = Map.copyOf(p);
        preferencesCache = Map.copyOf(q);
    }

    private void applySettings(Map<String, String> p, Map<String, String> q) {
        if ("CUSTOM".equals(p.get("scopeMode"))) {
            customScopeRadio.setSelected(true); scope.setMode(ScopeController.Mode.CUSTOM); hostArea.setEnabled(true);
        }
        if (p.containsKey("hosts")) hostArea.setText(p.get("hosts"));          // DocumentListener updates scope
        if (p.containsKey("captureTools")) selectTools(captureBoxes, p.get("captureTools"));
        if (p.containsKey("baseUrlOverride")) baseUrlField.setText(p.get("baseUrlOverride"));
        if (p.containsKey("collectionName")) collectionNameField.setText(p.get("collectionName"));
        if (q.containsKey("placeholder")) placeholderField.setText(q.get("placeholder"));
        if (q.containsKey("matchFormats")) matchFormatsField.setText(q.get("matchFormats"));
        try { if (q.containsKey("exportFormat")) formatBox.setSelectedIndex(Integer.parseInt(q.get("exportFormat"))); }
        catch (RuntimeException ignore) { }
        if (q.containsKey("autofillTools")) selectTools(toolBoxes, q.get("autofillTools"));
        if (q.containsKey("skipStatic")) skipStaticBox.setSelected(Boolean.parseBoolean(q.get("skipStatic")));
        if (q.containsKey("autoRefresh")) preferLatestBox.setSelected(Boolean.parseBoolean(q.get("autoRefresh")));
    }

    private static String selectedTools(Map<ToolType, JCheckBox> boxes) {
        StringJoiner j = new StringJoiner(",");
        boxes.forEach((t, cb) -> { if (cb.isSelected()) j.add(t.name()); });
        return j.toString();
    }
    private static void selectTools(Map<ToolType, JCheckBox> boxes, String csv) {
        Set<String> on = new HashSet<>(Arrays.asList(csv == null ? new String[0] : csv.split(",")));
        boxes.forEach((t, cb) -> cb.setSelected(on.contains(t.name())));
    }

    public Component component() { return root; }

    /** Called from the extension's unloading handler: stop the refresh timer and any history scan. */
    public void dispose() {
        disposed = true;
        Runnable stop = () -> { cacheSettings(); timer.stop(); if (historyWorker != null) historyWorker.cancel(true); };
        if (SwingUtilities.isEventDispatchThread()) stop.run(); else SwingUtilities.invokeLater(stop);
    }

    /**
     * Rebuild the tables only when the store changed. While a Known-values cell is being edited the
     * reload is deferred (lastVersion is not advanced) so the edit is never cancelled mid-pick.
     */
    private void refreshIfChanged() {
        if (disposed) return;
        long v = store.version();
        if (v == lastVersion) return;
        if (kvTable != null && kvTable.isEditing()) return;      // retry next tick
        lastVersion = v;
        coverageModel.reload();
        reloadKnownValuesKeepingSelection();
        status.setText(statusText());
    }
    private void forceRefresh() { lastVersion = -1; refreshIfChanged(); status.setText(statusText()); }

    private String statusText() {
        int total = store.coverage().expectedCount();
        int seen = store.coverage().seenExpectedCount();
        int noSuccess = store.coverage().noSuccessExpectedCount();
        int pct = total == 0 ? 0 : (int) Math.round(100.0 * seen / total);
        long dropped = pipeline.dropped();
        return "  Coverage " + seen + "/" + total + " (" + pct + "%)"
             + (noSuccess > 0 ? ", " + noSuccess + " with no successful response" : "") + "   \u00b7   "
             + store.endpointCount() + " endpoints captured   \u00b7   "
             + store.params().nameCount() + " captured values   \u00b7   capture "
             + (handler.isEnabled() ? "ON" : "OFF")
             + (handler.isSubstituteLive() ? "   \u00b7   auto-fill LIVE" : "")
             + (dropped > 0 ? "   \u00b7   " + dropped + " dropped (capture queue full)" : "")
             + collectionStatus();
    }

    /** Push the placeholder format and base URL into the live handler. */
    private void syncHandlerSettings() {
        var styles = PlaceholderFormats.parse(matchFormatsField.getText());
        if (styles.isEmpty()) styles = List.of(styleFrom(placeholderField.getText()));
        handler.setPlaceholderStyles(styles);
        handler.setBaseUrlOverride(baseUrlField.getText());
        handler.setSkipStatic(skipStaticBox.isSelected());
        store.params().setAutoRefresh(preferLatestBox.isSelected());
        Set<ToolType> on = new LinkedHashSet<>();
        toolBoxes.forEach((t, cb) -> { if (cb.isSelected()) on.add(t); });
        handler.setTools(on);                    // always mirror the boxes (empty = auto-fill applies nowhere)
        Set<ToolType> cap = new LinkedHashSet<>();
        captureBoxes.forEach((t, cb) -> { if (cb.isSelected()) cap.add(t); });
        handler.setCaptureTools(cap);
    }

    private String collectionStatus() {
        var lc = store.collection();
        if (lc == null) return "";
        int total = lc.distinctPlaceholders();
        int done = lc.resolvedCount(store.params());
        return "   \u00b7   collection " + lc.fileName() + ": " + done + "/" + total + " placeholders resolved";
    }

    // ---------------- top strip: toolbar + collapsible scope/settings ----------------
    private JComponent topStrip() {
        JPanel strip = new JPanel(new BorderLayout());
        strip.add(toolbar(), BorderLayout.NORTH);

        JPanel config = new JPanel(new GridLayout(1, 3, 10, 0));
        config.setBorder(BorderFactory.createEmptyBorder(6, 2, 6, 2));
        config.add(scopePanel());
        config.add(autoFillPanel());
        config.add(exportPanel());

        // Collapsible so the working area gets full height once configured.
        JPanel collapsible = new JPanel(new BorderLayout());
        JToggleButton toggle = new JToggleButton("\u25be  Scope & export settings", true);
        toggle.setHorizontalAlignment(SwingConstants.LEFT);
        toggle.setBorderPainted(false);
        toggle.addActionListener(e -> {
            boolean open = toggle.isSelected();
            config.setVisible(open);
            toggle.setText((open ? "\u25be" : "\u25b8") + "  Scope & export settings");
        });
        collapsible.add(toggle, BorderLayout.NORTH);
        collapsible.add(config, BorderLayout.CENTER);
        strip.add(collapsible, BorderLayout.CENTER);
        return strip;
    }

    private JComponent toolbar() {
        JToolBar bar = new JToolBar();
        bar.setFloatable(false);

        JToggleButton capture = new JToggleButton("Capture ON", true);
        capture.addActionListener(e -> {
            handler.setEnabled(capture.isSelected());
            capture.setText(capture.isSelected() ? "Capture ON" : "Capture OFF");
            status.setText(statusText());
        });
        bar.add(capture);

        JToggleButton subst = new JToggleButton("Auto-fill live requests", false);
        subst.setToolTipText("API-only testing: replace placeholders in outgoing requests "
            + "with captured values (e.g. {{orderId}} from the create-order response)");
        subst.addActionListener(e -> {
            handler.setSubstituteLive(subst.isSelected());
            syncHandlerSettings();
            status.setText(statusText());
        });
        bar.add(subst);
        bar.addSeparator();

        JButton importBtn = new JButton("Import \u25be");
        importBtn.setToolTipText("OpenAPI/Swagger (JSON or YAML), Postman, Bruno, Excel, CSV, or pasted text. "
            + "Endpoints go to coverage; any placeholders make it the fill target.");
        importBtn.addActionListener(e -> {
            JPopupMenu m = new JPopupMenu();
            JMenuItem file = new JMenuItem("From file or folder...");
            file.addActionListener(x -> doImport());
            JMenuItem paste = new JMenuItem("Paste text...");
            paste.addActionListener(x -> doImportPaste());
            m.add(file); m.add(paste);
            m.show(importBtn, 0, importBtn.getHeight());
        });
        bar.add(importBtn);


        historyBtn = new JButton("Rescan history");
        historyBtn.setToolTipText("Traffic captures automatically; re-scan after changing scope. "
            + "Items already captured are skipped, so rescanning never double-counts.");
        historyBtn.addActionListener(e -> rescanHistory());
        bar.add(historyBtn);
        bar.addSeparator();

        JButton export = new JButton("Export \u25be");
        export.addActionListener(e -> exportMenu().show(export, 0, export.getHeight()));
        bar.add(export);

        JButton clear = new JButton("Clear \u25be");
        clear.addActionListener(e -> clearMenu().show(clear, 0, clear.getHeight()));
        bar.add(clear);
        return bar;
    }

    private JComponent scopePanel() {
        JPanel p = new JPanel(new BorderLayout(4, 4));
        p.setBorder(BorderFactory.createTitledBorder("Scope"));

        JRadioButton burp = new JRadioButton("Use Burp target scope", true);
        JRadioButton custom = new JRadioButton("Custom hosts (one per line, subdomains match)");
        burpScopeRadio = burp; customScopeRadio = custom;
        ButtonGroup g = new ButtonGroup(); g.add(burp); g.add(custom);

        hostArea.setEnabled(false);
        hostArea.setToolTipText("e.g.\napi.client.com\nlocalhost\napp.client.com");
        JScrollPane hostScroll = new JScrollPane(hostArea);

        burp.addActionListener(e -> { scope.setMode(ScopeController.Mode.BURP); hostArea.setEnabled(false); });
        custom.addActionListener(e -> { scope.setMode(ScopeController.Mode.CUSTOM); hostArea.setEnabled(true); hostArea.requestFocusInWindow(); });
        hostArea.getDocument().addDocumentListener(new SimpleDoc(() -> scope.setHosts(hostArea.getText())));

        JPanel radios = new JPanel(new GridLayout(0, 1));
        radios.add(burp); radios.add(custom);

        // Which tools' traffic is captured (Proxy by default). Scanner and Intruder are deliberately not
        // offered: their probes would pollute captured values and mark endpoints "seen".
        JPanel capFrom = new JPanel(new GridLayout(0, 3));
        capFrom.setBorder(BorderFactory.createTitledBorder("Capture from"));
        for (var t : List.of(ToolType.PROXY, ToolType.REPEATER, ToolType.EXTENSIONS)) {
            JCheckBox cb = new JCheckBox(t.toolName(), t == ToolType.PROXY);
            cb.setToolTipText("Record " + t.toolName() + " responses (counts toward coverage)");
            cb.addActionListener(e -> syncHandlerSettings());
            captureBoxes.put(t, cb);
            capFrom.add(cb);
        }
        p.add(radios, BorderLayout.NORTH);
        p.add(hostScroll, BorderLayout.CENTER);
        p.add(capFrom, BorderLayout.SOUTH);
        return p;
    }

    private JComponent autoFillPanel() {
        JPanel p = new JPanel(new BorderLayout(4, 4));
        p.setBorder(BorderFactory.createTitledBorder("Auto-fill live requests"));

        JPanel top = new JPanel(new BorderLayout(4, 2));
        JLabel l = new JLabel("Match formats");
        matchFormatsField.setToolTipText("Placeholder formats to look for in outgoing requests. "
            + "Comma-separate several, e.g.  {{name}}, :name, ${name}  \u2014 the client's collection "
            + "may not use the same format you export.");
        top.add(l, BorderLayout.WEST);
        top.add(matchFormatsField, BorderLayout.CENTER);

        JPanel opts = new JPanel(new GridLayout(0, 1));
        preferLatestBox.setToolTipText("If the SAME call returns a new value (e.g. re-login gives a fresh "
            + "token), update the active value. A same-named field from a different call never overrides it. "
            + "Values you pick by hand stay pinned.");
        skipStaticBox.setToolTipText("Don't capture values from .js/.css/image responses");
        preferLatestBox.addActionListener(e -> syncHandlerSettings());
        skipStaticBox.addActionListener(e -> syncHandlerSettings());
        opts.add(preferLatestBox);
        opts.add(skipStaticBox);

        JPanel tools = new JPanel(new GridLayout(0, 2));
        tools.setBorder(BorderFactory.createTitledBorder("Apply to"));
        for (var t : List.of(ToolType.PROXY, ToolType.REPEATER)) {
            JCheckBox cb = new JCheckBox(t.toolName(), true);
            cb.addActionListener(e -> syncHandlerSettings());
            toolBoxes.put(t, cb);
            tools.add(cb);
        }

        JPanel body = new JPanel(new BorderLayout(4, 4));
        body.add(opts, BorderLayout.NORTH);
        body.add(tools, BorderLayout.CENTER);
        p.add(top, BorderLayout.NORTH);
        p.add(body, BorderLayout.CENTER);
        return p;
    }

    private JComponent exportPanel() {
        JPanel p = new JPanel(new GridBagLayout());
        p.setBorder(BorderFactory.createTitledBorder("Export settings"));
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(2, 3, 2, 3); c.anchor = GridBagConstraints.WEST; c.fill = GridBagConstraints.HORIZONTAL;
        int y = 0;
        addRow(p, c, y++, "Format", formatBox);
        addRow(p, c, y++, "Placeholder", placeholderField);
        addRow(p, c, y++, "Collection name", collectionNameField);
        addRow(p, c, y++, "Base URL override", baseUrlField);
        baseUrlField.setToolTipText("Optional. Blank = use the captured host(s): one {{baseUrl}} per host, "
            + "most-used host first. Set this to point the primary host somewhere else.");
        baseUrlField.getDocument().addDocumentListener(new SimpleDoc(() -> handler.setBaseUrlOverride(baseUrlField.getText())));
        return p;
    }
    /** Fix a column's width so narrow numeric columns don't hog space. */
    private static void setWidth(JTable t, int col, int pref, int max) {
        var tc = t.getColumnModel().getColumn(col);
        tc.setPreferredWidth(pref);
        tc.setMaxWidth(max);
    }

    private void addRow(JPanel p, GridBagConstraints c, int y, String label, JComponent field) {
        c.gridx = 0; c.gridy = y; c.weightx = 0; p.add(new JLabel(label), c);
        c.gridx = 1; c.weightx = 1; p.add(field, c);
    }

    // ---------------- working area ----------------
    private JComponent workingArea() {
        JSplitPane sp = new JSplitPane(JSplitPane.VERTICAL_SPLIT, coveragePane(), knownValuesPane());
        sp.setResizeWeight(0.62);
        return sp;
    }

    private JComponent coveragePane() {
        JPanel p = new JPanel(new BorderLayout(4, 4));
        JTable table = new JTable(coverageModel);
        table.setAutoResizeMode(JTable.AUTO_RESIZE_LAST_COLUMN);
        table.setAutoCreateRowSorter(true);
        TableRowSorter<CoverageModel> sorter = new TableRowSorter<>(coverageModel);
        table.setRowSorter(sorter);
        setWidth(table, 0, 70, 90);    // Method
        setWidth(table, 2, 80, 100);   // Status
        setWidth(table, 3, 70, 90);    // Last status
        setWidth(table, 4, 90, 160);   // Status codes
        setWidth(table, 6, 55, 70);    // Hits
        // Error messages can be long: show the full text on hover.
        table.getColumnModel().getColumn(5).setCellRenderer(new javax.swing.table.DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(JTable t, Object v, boolean sel, boolean focus, int r, int c) {
                Component comp = super.getTableCellRendererComponent(t, v, sel, focus, r, c);
                String text = v == null ? "" : v.toString();
                setToolTipText(text.isEmpty() ? null : "<html><body style='width:420px'>"
                    + text.replace("&", "&amp;").replace("<", "&lt;").replace(" | ", "<br>") + "</body></html>");
                return comp;
            }
        });

        JTextField filter = new JTextField();
        filter.getDocument().addDocumentListener(new SimpleDoc(() -> {
            String q = filter.getText().trim();
            sorter.setRowFilter(q.isEmpty() ? null : RowFilter.regexFilter("(?i)" + java.util.regex.Pattern.quote(q)));
        }));
        JComboBox<String> show = new JComboBox<>(new String[]{
            "All", "Without a successful response", "Seen (successful)", "No success (errors / redirects only)", "Not found only", "Not seen only"});
        show.setToolTipText("<html>seen = at least one 2xx/304 response<br>no success = answered, but only errors or redirects (401, 403, 500, 302 ...)"
            + "<br>not found = only 404/405/410/501<br>not seen = never requested</html>");
        show.addActionListener(e -> {
            int i = show.getSelectedIndex();
            coverageModel.statusFilter = switch (i) {
                case 1 -> "unsuccessful"; case 2 -> "seen"; case 3 -> "no success"; case 4 -> "not found"; case 5 -> "not seen"; default -> null; };
            coverageModel.reload();
        });

        JPanel north = new JPanel(new BorderLayout(4, 0));
        north.add(new JLabel("Coverage "), BorderLayout.WEST);
        north.add(filter, BorderLayout.CENTER);
        JButton prefixBtn = new JButton("Prefixes\u2026");
        prefixBtn.setToolTipText("Path prefixes to ignore when matching the spec to traffic (e.g. a gateway's /api/v1)");
        prefixBtn.addActionListener(e -> editPrefixes());
        JPanel east = new JPanel(new BorderLayout(4, 0));
        east.add(show, BorderLayout.CENTER);
        east.add(prefixBtn, BorderLayout.EAST);
        north.add(east, BorderLayout.EAST);
        p.add(north, BorderLayout.NORTH);
        p.add(new JScrollPane(table), BorderLayout.CENTER);
        return p;
    }

    private JComponent knownValuesPane() {
        JPanel p = new JPanel(new BorderLayout(4, 4));
        JTable table = new JTable(kvModel);
        kvTable = table;
        TableRowSorter<KnownValuesModel> sorter = new TableRowSorter<>(kvModel);
        table.setRowSorter(sorter);
        table.getColumnModel().getColumn(1).setCellEditor(new ValueEditor());
        setWidth(table, 0, 140, 240);  // Parameter
        setWidth(table, 2, 50, 60);    // Count
        setWidth(table, 3, 50, 60);    // Pinned

        // search box: filters across name + value + sources
        JTextField search = new JTextField();
        search.setToolTipText("Values pulled from requests and responses as you test. "
            + "The selected value for each name is what gets used to fill placeholders and the environment file.");
        search.getDocument().addDocumentListener(new SimpleDoc(() -> {
            String q = search.getText().trim();
            sorter.setRowFilter(q.isEmpty() ? null : RowFilter.regexFilter("(?i)" + java.util.regex.Pattern.quote(q)));
        }));
        JComboBox<String> showKv = new JComboBox<>(new String[]{"All", "Waiting", "Captured"});
        showKv.setToolTipText("Waiting = placeholders from the imported collection with no value captured yet");
        showKv.addActionListener(e -> {
            int i = showKv.getSelectedIndex();
            kvModel.rowFilter = i == 0 ? null : (i == 1 ? "waiting" : "captured");
            kvModel.reload();
        });

        JPanel north = new JPanel(new BorderLayout(4, 0));
        north.add(new JLabel("Captured values "), BorderLayout.WEST);
        north.add(search, BorderLayout.CENTER);
        north.add(showKv, BorderLayout.EAST);

        // copy: double-click copies the value; right-click offers copy variants
        table.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2 && e.getButton() == MouseEvent.BUTTON1) {
                    int vr = table.rowAtPoint(e.getPoint());
                    if (vr >= 0) copyValue(table, vr);
                }
            }
            @Override public void mousePressed(MouseEvent e) { maybePopup(e); }
            @Override public void mouseReleased(MouseEvent e) { maybePopup(e); }
            private void maybePopup(MouseEvent e) {
                if (!e.isPopupTrigger()) return;
                int vr = table.rowAtPoint(e.getPoint());
                if (vr >= 0) { table.setRowSelectionInterval(vr, vr); kvPopup(table, vr).show(table, e.getX(), e.getY()); }
            }
        });

        p.add(north, BorderLayout.NORTH);
        p.add(new JScrollPane(table), BorderLayout.CENTER);
        return p;
    }

    private String[] nameValueAt(JTable table, int viewRow) {
        int mr = table.convertRowIndexToModel(viewRow);
        String name = kvModel.nameAt(mr);
        String value = store.params().active(name);
        return new String[]{name, value == null ? "" : value};
    }
    private void copyToClipboard(String text) {
        Toolkit.getDefaultToolkit().getSystemClipboard().setContents(new StringSelection(text), null);
    }
    private void copyValue(JTable table, int viewRow) {
        String[] nv = nameValueAt(table, viewRow);
        copyToClipboard(nv[1]);
        status.setText("  Copied value of " + nv[0] + " to clipboard");
    }
    private JPopupMenu kvPopup(JTable table, int viewRow) {
        String[] nv = nameValueAt(table, viewRow);
        String ph = styleFrom(placeholderField.getText()).wrap(nv[0]);
        JPopupMenu m = new JPopupMenu();
        if (store.params().isPinned(nv[0])) {
            JMenuItem unpin = new JMenuItem("Unpin " + nv[0] + " (resume auto-refresh)");
            unpin.addActionListener(e -> { store.params().unpin(nv[0]); store.touch(); forceRefresh(); });
            m.add(unpin); m.addSeparator();
        }
        addCopy(m, "Copy value", nv[1]);
        addCopy(m, "Copy placeholder  " + ph, ph);
        addCopy(m, "Copy name", nv[0]);
        addCopy(m, "Copy  name=value", nv[0] + "=" + nv[1]);
        m.addSeparator();
        addCopy(m, "Copy all values as JSON", allValuesJson());
        return m;
    }
    private void addCopy(JPopupMenu m, String label, String payload) {
        JMenuItem it = new JMenuItem(label);
        it.addActionListener(e -> { copyToClipboard(payload); status.setText("  Copied to clipboard"); });
        m.add(it);
    }
    private String allValuesJson() {
        return Json.write(store.params().activeSnapshot());   // properly escaped
    }

    // ---------------- menus & actions ----------------
    private JPopupMenu exportMenu() {
        JPopupMenu m = new JPopupMenu();
        JMenuItem full = new JMenuItem("New collection + environment...");
        full.setToolTipText("Build a collection from the traffic you captured");
        full.addActionListener(e -> doExport(true));
        JMenuItem collOnly = new JMenuItem("New collection only...");
        collOnly.addActionListener(e -> doExport(false));
        m.add(full); m.add(collOnly);

        var lc = store.collection();
        JMenuItem filled = new JMenuItem(lc == null
            ? "Filled client collection... (none imported)"
            : "Filled client collection (" + lc.fileName() + ")...");
        filled.setToolTipText("Save the collection you imported, with placeholders replaced by captured values");
        filled.setEnabled(lc != null);
        filled.addActionListener(e -> doSaveFilled());
        m.addSeparator(); m.add(filled);

        JMenuItem nsCsv = new JMenuItem("Not-seen list, CSV (client deliverable)...");
        nsCsv.setToolTipText("Every imported endpoint without a successful (2xx/304) response: not seen, not found, or no success");
        nsCsv.addActionListener(e -> saveText(deliverableName("not-seen") + ".csv", CoverageReport.csv(store.coverageRows(), true)));
        JMenuItem fullCsv = new JMenuItem("Full coverage report, CSV...");
        fullCsv.addActionListener(e -> saveText(deliverableName("coverage") + ".csv", CoverageReport.csv(store.coverageRows(), false)));
        m.addSeparator(); m.add(nsCsv); m.add(fullCsv);
        return m;
    }
    private JPopupMenu clearMenu() {
        JPopupMenu m = new JPopupMenu();
        JMenuItem cap = new JMenuItem("Clear captured traffic");
        cap.addActionListener(e -> { if (confirm("Clear captured endpoints and captured values?\nImported endpoint list is kept.")) { store.clearCaptured(); forceRefresh(); } });
        JMenuItem exp = new JMenuItem("Clear imported endpoint list");
        exp.addActionListener(e -> { if (confirm("Clear the imported endpoint list?\nCaptured traffic is kept.")) { store.clearExpected(); forceRefresh(); } });
        var lc = store.collection();
        JMenuItem unload = new JMenuItem(lc == null ? "Unload client collection" : "Unload \"" + lc.fileName() + "\"");
        unload.setEnabled(lc != null);
        unload.addActionListener(e -> { store.unloadCollection(); forceRefresh(); });

        JMenuItem all = new JMenuItem("Reset everything");
        all.addActionListener(e -> {
            if (confirm("Reset everything \u2014 captured traffic, imported endpoints,\nand the loaded client collection?")) {
                store.clearAll(); forceRefresh();
            }
        });
        m.add(cap); m.add(exp); m.add(unload); m.addSeparator(); m.add(all);
        return m;
    }
    private boolean confirm(String msg) {
        return JOptionPane.showConfirmDialog(root, msg, "Confirm", JOptionPane.OK_CANCEL_OPTION,
            JOptionPane.WARNING_MESSAGE) == JOptionPane.OK_OPTION;
    }
    private void doExport(boolean includeEnv) {
        JFileChooser fc = new JFileChooser();
        fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        if (fc.showSaveDialog(root) != JFileChooser.APPROVE_OPTION) return;
        try {
            PlaceholderStyle style = styleFrom(placeholderField.getText());
            CollectionBuilder.Result built = new CollectionBuilder(style)
                .build(collectionNameField.getText(), "Local", store, baseUrlField.getText());
            EnvironmentModel env = includeEnv ? built.environment() : null;
            CollectionExporter exporter = formatBox.getSelectedIndex() == 0 ? new PostmanExporter() : new BrunoExporter();
            String base = deliverableName(collectionNameField.getText());
            CollectionWriter writer = new CollectionWriter();
            writer.write(fc.getSelectedFile().toPath(), exporter.export(built.collection(), env, base));
            var files = exporter.attachments(built.collection(), base);
            writer.writeBinary(fc.getSelectedFile().toPath(), files);
            JOptionPane.showMessageDialog(root,
                "Exported " + formatBox.getSelectedItem()
                + (includeEnv ? " (collection + environment)" : " (collection only)")
                + (files.isEmpty() ? "" : "\n" + files.size() + " uploaded file(s) saved under "
                    + exporter.attachmentDir(built.collection(), base) + "/")
                + "\nBase name: " + base + "\nto " + fc.getSelectedFile());
        } catch (Exception ex) { error(ex); }
    }

    /** One import: adds endpoints to coverage AND, if the file has placeholders, loads it as the fill target. */
    private void doImport() {
        JFileChooser fc = new JFileChooser();
        fc.setDialogTitle("Import endpoint list or collection");
        fc.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES); // a Bruno collection is a folder
        if (fc.showOpenDialog(root) != JFileChooser.APPROVE_OPTION) return;
        java.nio.file.Path f = fc.getSelectedFile().toPath();
        try {
            boolean textFile = !java.nio.file.Files.isDirectory(f) && !isBinary(f);
            String text = textFile ? Text.readFile(f) : null;          // read once; UTF-8 or Windows-1252
            List<ImportedEndpoint> eps = textFile
                ? dispatcher.importText(f.getFileName().toString(), text)
                : dispatcher.importFile(f);
            for (ImportedEndpoint e : eps) store.importExpected(e.method, e.path, e.source);

            LoadedCollection lc = null;
            if (textFile) {
                for (PlaceholderStyle style : matchStyles()) {
                    LoadedCollection candidate = new LoadedCollection(f.getFileName().toString(), text, style);
                    if (candidate.distinctPlaceholders() > 0) { lc = candidate; break; }
                }
            }
            if (lc != null) store.loadCollection(lc);
            forceRefresh();

            StringBuilder msg = new StringBuilder();
            msg.append(eps.isEmpty() ? "No endpoints found."
                     : "Added " + eps.size() + " endpoint(s) to coverage.");
            if (lc != null) {
                msg.append("\n\nFound ").append(lc.distinctPlaceholders())
                   .append(" placeholder(s) \u2014 loaded as the fill target.\n")
                   .append(lc.resolvedCount(store.params())).append(" already have captured values; ")
                   .append("the rest show as \"waiting\" and fill in as you test.");
            } else if (java.nio.file.Files.isDirectory(f)) {
                msg.append("\n\n(Folder imported for coverage. To fill placeholders, import a single file.)");
            }
            JOptionPane.showMessageDialog(root, msg.toString(), "Import complete", JOptionPane.INFORMATION_MESSAGE);
        } catch (UnsupportedOperationException ux) {
            JOptionPane.showMessageDialog(root, ux.getMessage(), "Decoder needed", JOptionPane.WARNING_MESSAGE);
        } catch (Exception ex) { error(ex); }
    }

    private void doImportPaste() {
        JTextArea area = new JTextArea(10, 50);
        if (JOptionPane.showConfirmDialog(root, new JScrollPane(area), "Paste endpoint list",
                JOptionPane.OK_CANCEL_OPTION) != JOptionPane.OK_OPTION) return;
        List<ImportedEndpoint> eps = dispatcher.importText("paste.txt", area.getText());
        for (ImportedEndpoint e : eps) store.importExpected(e.method, e.path, "pasted text");
        forceRefresh();
        JOptionPane.showMessageDialog(root, "Added " + eps.size() + " endpoint(s) to coverage.");
    }

    private List<PlaceholderStyle> matchStyles() {
        var styles = PlaceholderFormats.parse(matchFormatsField.getText());
        return styles.isEmpty() ? List.of(styleFrom(placeholderField.getText())) : styles;
    }
    private static boolean isBinary(java.nio.file.Path f) {
        String n = f.getFileName().toString().toLowerCase();
        return n.endsWith(".xlsx") || n.endsWith(".xls");
    }

    private void doSaveFilled() {
        var lc = store.collection();
        if (lc == null) return;
        try {
            java.util.Map<String, String> values = store.substitutionValues(baseUrlField.getText());
            if (!baseUrlField.getText().isBlank()) values.put("baseUrl", baseUrlField.getText().trim());
            // JSON collections get JSON-escaped values, so a captured quote can't corrupt the file
            PlaceholderHydrator.Result r = new PlaceholderHydrator().hydrate(lc.text(), lc.style(), values);

            JFileChooser out = new JFileChooser();
            out.setDialogTitle("Save filled collection");
            out.setSelectedFile(new java.io.File(deliverableName("filled-" + lc.fileName())));
            if (out.showSaveDialog(root) != JFileChooser.APPROVE_OPTION) return;
            java.nio.file.Files.writeString(out.getSelectedFile().toPath(), r.text, java.nio.charset.StandardCharsets.UTF_8);

            String msg = "Filled " + r.replacements + " placeholder occurrence(s).";
            if (!r.unresolved.isEmpty())
                msg += "\n\nStill no value for (left as placeholders):\n  " + String.join(", ", r.unresolved);
            JOptionPane.showMessageDialog(root, msg,
                r.unresolved.isEmpty() ? "Saved" : "Saved \u2014 some placeholders unresolved",
                r.unresolved.isEmpty() ? JOptionPane.INFORMATION_MESSAGE : JOptionPane.WARNING_MESSAGE);
        } catch (Exception ex) { error(ex); }
    }



    /** Deliverable base name: <burp project>_<exportName>, sanitized. Project name auto from Burp. */
    private String deliverableName(String exportName) {
        String project = "";
        try { if (api != null && api.project() != null) project = api.project().name(); } catch (Exception ignore) {}
        String ex = exportName == null || exportName.isBlank() ? "export" : exportName;
        String combined = (project == null || project.isBlank() ? "" : project + "_") + ex;
        return combined.replaceAll("[^A-Za-z0-9._-]+", "-").replaceAll("^-+|-+$", "");
    }
    private static PlaceholderStyle styleFrom(String pattern) {
        int i = pattern == null ? -1 : pattern.indexOf("name");
        return i <= 0 ? PlaceholderStyle.DOUBLE_CURLY : new PlaceholderStyle(pattern.substring(0, i), pattern.substring(i + 4));
    }
    private void saveText(String suggested, String text) {
        JFileChooser fc = new JFileChooser(); fc.setSelectedFile(new java.io.File(suggested));
        if (fc.showSaveDialog(root) != JFileChooser.APPROVE_OPTION) return;
        try { Files.writeString(fc.getSelectedFile().toPath(), text, java.nio.charset.StandardCharsets.UTF_8); } catch (Exception ex) { error(ex); }
    }
    private void error(Exception ex) {
        if (api != null) api.logging().logToError("API Collector UI error", ex);
        JOptionPane.showMessageDialog(root, String.valueOf(ex.getMessage()), "Error", JOptionPane.ERROR_MESSAGE);
    }

    // ---------------- coverage prefixes ----------------
    /** Edit the ignored-prefix list; "Suggest" proposes the prefix that matches the most extra endpoints. */
    private void editPrefixes() {
        JTextArea area = new JTextArea(String.join("\n", store.coverage().ignoredPrefixes()), 6, 30);
        JLabel hint = new JLabel("<html>One prefix per line, e.g. <code>/api/v1</code> or <code>/tenants/{id}</code>.<br>"
            + "Stripped from BOTH the imported spec and captured traffic before matching.</html>");
        JButton suggest = new JButton("Suggest");
        suggest.addActionListener(e -> {
            store.setIgnoredPrefixes(lines(area.getText()));
            var sug = store.coverage().suggestPrefix();
            if (sug.isEmpty()) { JOptionPane.showMessageDialog(area, "No prefix would match more endpoints."); return; }
            if (JOptionPane.showConfirmDialog(area, "Add " + sug.get().prefix() + "? It matches "
                    + sug.get().gained() + " more imported endpoint(s).", "Suggested prefix",
                    JOptionPane.OK_CANCEL_OPTION) == JOptionPane.OK_OPTION) {
                String t = area.getText().strip();
                area.setText((t.isEmpty() ? "" : t + "\n") + sug.get().prefix());
            }
        });
        JPanel panel = new JPanel(new BorderLayout(4, 4));
        panel.add(hint, BorderLayout.NORTH);
        panel.add(new JScrollPane(area), BorderLayout.CENTER);
        panel.add(suggest, BorderLayout.SOUTH);
        List<String> before = store.coverage().ignoredPrefixes();
        if (JOptionPane.showConfirmDialog(root, panel, "Ignored path prefixes", JOptionPane.OK_CANCEL_OPTION,
                JOptionPane.PLAIN_MESSAGE) == JOptionPane.OK_OPTION) store.setIgnoredPrefixes(lines(area.getText()));
        else store.setIgnoredPrefixes(before);
        forceRefresh();
    }
    private static List<String> lines(String text) { return text == null ? List.of() : List.of(text.split("\\R")); }

    // ---------------- history rescan (background) ----------------
    /** Proxy history can be huge: scan on a SwingWorker so Burp's UI never freezes. */
    private void rescanHistory() {
        if (historyWorker != null && !historyWorker.isDone()) return;
        historyBtn.setEnabled(false);
        status.setText("  Scanning proxy history…");
        historyWorker = new SwingWorker<ProxyHistoryImporter.Result, Integer>() {
            @Override protected ProxyHistoryImporter.Result doInBackground() {
                return new ProxyHistoryImporter().importInto(api, handler, pipeline,
                    () -> isCancelled() || disposed, n -> publish(n));
            }
            @Override protected void process(List<Integer> chunks) {
                status.setText("  Scanning proxy history… " + chunks.get(chunks.size() - 1) + " items");
            }
            @Override protected void done() {
                historyBtn.setEnabled(true);
                if (isCancelled() || disposed) return;
                try {
                    var r = get();
                    forceRefresh();
                    JOptionPane.showMessageDialog(root, "Scanned " + r.matched() + " in-scope items from proxy history.\n"
                        + r.added() + " added, " + r.skipped() + " already captured (skipped).");
                } catch (Exception ex) { error(ex instanceof java.util.concurrent.ExecutionException ee && ee.getCause() instanceof Exception c ? c : ex); }
            }
        };
        historyWorker.execute();
    }

    /** Reload the Known values table, restoring the user's selection by parameter name. */
    private void reloadKnownValuesKeepingSelection() {
        Set<String> selected = new LinkedHashSet<>();
        if (kvTable != null) for (int vr : kvTable.getSelectedRows()) {
            int mr = kvTable.convertRowIndexToModel(vr);
            if (mr >= 0 && mr < kvModel.getRowCount()) selected.add(kvModel.nameAt(mr));
        }
        kvModel.reload();
        if (kvTable == null || selected.isEmpty()) return;
        for (int mr = 0; mr < kvModel.getRowCount(); mr++) {
            if (!selected.contains(kvModel.nameAt(mr))) continue;
            int vr = kvTable.convertRowIndexToView(mr);
            if (vr >= 0) kvTable.addRowSelectionInterval(vr, vr);
        }
    }

    // ---------------- models ----------------
    private final class CoverageModel extends AbstractTableModel {
        private final String[] cols = {"Method", "Endpoint", "Status", "Last status", "Status codes", "Error messages", "Hits"};
        private List<Object[]> rows = new ArrayList<>();
        /** null = all, "unsuccessful" (anything but seen), "seen", "no success", "not found", "not seen". */
        String statusFilter;
        void reload() {
            List<Object[]> r = new ArrayList<>();
            for (CaptureStore.CoverageRow c : store.coverageRows()) {
                String st = switch (c.status()) {
                    case SEEN -> "seen"; case NO_SUCCESS -> "no success"; case NOT_FOUND -> "not found"; case NOT_SEEN -> "not seen"; };
                if (statusFilter != null && !(statusFilter.equals("unsuccessful") ? c.status() != CoverageTracker.Status.SEEN
                                                                                   : statusFilter.equals(st))) continue;
                r.add(new Object[]{c.method(), c.specPath(), st, c.lastStatus() == 0 ? "" : String.valueOf(c.lastStatus()),
                                   c.statusCodes(), c.errors(), c.hits()});
            }
            rows = r; fireTableDataChanged();
        }
        public int getRowCount() { return rows.size(); }
        public int getColumnCount() { return cols.length; }
        public String getColumnName(int c) { return cols[c]; }
        public Class<?> getColumnClass(int c) { return c == 6 ? Integer.class : String.class; }
        public Object getValueAt(int r, int c) { return rows.get(r)[c]; }
    }
    /** Rows are an immutable snapshot taken once per reload — painting never touches the store. */
    private final class KnownValuesModel extends AbstractTableModel {
        private final String[] cols = {"Parameter", "Active value", "Count", "Pinned", "Sources"};
        private List<ParameterRegistry.Row> rows = new ArrayList<>();
        String rowFilter;   // null = all, "waiting" = no value yet, "captured" = has a value
        void reload() {
            List<ParameterRegistry.Row> all = store.params().rows();
            if (rowFilter != null) all.removeIf(r -> r.waiting() != rowFilter.equals("waiting"));
            rows = all;
            fireTableDataChanged();
        }
        public int getRowCount() { return rows.size(); }
        public int getColumnCount() { return cols.length; }
        public String getColumnName(int c) { return cols[c]; }
        public Class<?> getColumnClass(int c) { return c == 2 ? Integer.class : c == 3 ? Boolean.class : String.class; }
        public boolean isCellEditable(int r, int c) { return c == 1; }
        public Object getValueAt(int r, int c) {
            var row = rows.get(r);
            return switch (c) {
                case 0 -> row.name();
                case 1 -> row.active();
                case 2 -> row.count();
                case 3 -> row.pinned();
                default -> row.sources();
            };
        }
        /** Rows only change on reload, and reload is deferred while editing, so r is stable here. */
        public void setValueAt(Object val, int r, int c) {
            if (c != 1 || val == null || r >= rows.size()) return;
            store.params().setActive(rows.get(r).name(), String.valueOf(val));
            store.touch();
        }
        String nameAt(int modelRow) { return rows.get(modelRow).name(); }
    }
    private final class ValueEditor extends DefaultCellEditor {
        ValueEditor() { super(new JComboBox<String>()); }
        @Override public Component getTableCellEditorComponent(JTable t, Object v, boolean sel, int viewRow, int col) {
            @SuppressWarnings("unchecked") JComboBox<String> box = (JComboBox<String>) getComponent();
            box.removeAllItems();
            String name = ((KnownValuesModel) t.getModel()).nameAt(t.convertRowIndexToModel(viewRow));
            for (String val : store.params().valueStrings(name)) box.addItem(val);
            box.setSelectedItem(v);
            return box;
        }
    }
    private static final class SimpleDoc implements javax.swing.event.DocumentListener {
        private final Runnable r; SimpleDoc(Runnable r) { this.r = r; }
        public void insertUpdate(javax.swing.event.DocumentEvent e) { r.run(); }
        public void removeUpdate(javax.swing.event.DocumentEvent e) { r.run(); }
        public void changedUpdate(javax.swing.event.DocumentEvent e) { r.run(); }
    }
}
