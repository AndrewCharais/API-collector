package apicollector.export;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.Map;

/** Writes an exporter's filename->content map under a target directory — and never outside it. */
public final class CollectionWriter {
    public void write(Path dir, Map<String, String> files) throws IOException {
        for (Map.Entry<String, String> e : files.entrySet())
            Files.writeString(target(dir, e.getKey()), e.getValue(), StandardCharsets.UTF_8,
                StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE);
    }

    /** Binary attachments (multipart file uploads), same containment rule. */
    public void writeBinary(Path dir, Map<String, byte[]> files) throws IOException {
        for (Map.Entry<String, byte[]> e : files.entrySet())
            Files.write(target(dir, e.getKey()), e.getValue(),
                StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE);
    }

    private static Path target(Path dir, String key) throws IOException {
        Path base = dir.toAbsolutePath().normalize();
        Path p = base.resolve(key).normalize();
        if (!p.startsWith(base) || p.equals(base))
            throw new IOException("Refusing to write outside the export folder: " + key);
        if (p.getParent() != null) Files.createDirectories(p.getParent());
        return p;
    }
}
