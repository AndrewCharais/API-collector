package apicollector.export;

import java.util.LinkedHashMap;
import java.util.Map;

/** One format = one exporter. Returns filename -> UTF-8 text content (no filesystem coupling). */
public interface CollectionExporter {
    String id();
    /** @param baseName filename stem for the deliverable (e.g. "ACME_Q3_Client-API"). */
    Map<String, String> export(Collection c, EnvironmentModel env, String baseName);

    /** Binary files referenced by the export (multipart file uploads): path -> bytes. */
    default Map<String, byte[]> attachments(Collection c, String baseName) {
        Map<String, byte[]> out = new LinkedHashMap<>();
        String dir = attachmentDir(c, baseName);
        for (Collection.Folder f : c.folders)
            for (Collection.Request r : f.requests)
                for (Collection.FormPart p : r.formParts)
                    if (p.isFile() && p.data != null) out.put(dir + "/" + p.attachmentName, p.data);
        return out;
    }

    /** Folder (relative to the export directory) that holds attachments. */
    String attachmentDir(Collection c, String baseName);
}
