package apicollector.model;

/** One part of a multipart/form-data request body. {@code filename} is null for plain fields. */
public record MultipartPart(String name, String filename, String contentType, byte[] data) {
    public boolean isFile() { return filename != null; }
}
