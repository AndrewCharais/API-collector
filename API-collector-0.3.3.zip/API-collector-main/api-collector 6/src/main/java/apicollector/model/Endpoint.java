package apicollector.model;

import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

/**
 * A logical endpoint (one origin + normalized shape) plus a representative sample, a hit count and
 * the response statuses seen. Mutated only under CaptureStore's lock; readers get {@link #copy()}s.
 */
public final class Endpoint {
    private static final int MAX_STATUSES = 12;
    private static final int MAX_ERRORS = 6;

    public final EndpointShape shape;
    public final String origin;
    public Observation representative;
    public int count;
    public int lastStatus;
    public final Set<Integer> statuses = new LinkedHashSet<>();
    /** True once any response showed the endpoint actually exists (see CoverageTracker#isReachable). */
    public boolean reachable;
    /** True once any response was successful (2xx or 304, see CoverageTracker#isSuccess). */
    public boolean succeeded;
    /** Latest error message per error status code, e.g. 403 -> "Insufficient scope". */
    public final Map<Integer, String> errors = new TreeMap<>();

    public Endpoint(EndpointShape shape, String origin) { this.shape = shape; this.origin = origin == null ? "" : origin; }

    /**
     * Fold one observation in. The representative (what gets exported) is upgraded to the best
     * example seen: a successful exchange beats a merely-reachable one, which beats a not-found one.
     */
    public void observe(Observation o, boolean isReachable, boolean isSuccess) {
        count++;
        lastStatus = o.status;
        if (statuses.size() < MAX_STATUSES) statuses.add(o.status);
        if (representative == null || (isSuccess && !succeeded) || (isReachable && !reachable)) representative = o;
        reachable |= isReachable;
        succeeded |= isSuccess;
        if (o.errorMessage != null && (errors.containsKey(o.status) || errors.size() < MAX_ERRORS)) errors.put(o.status, o.errorMessage);
    }

    /** Same data under a new shape (used when path learning merges endpoints). */
    public Endpoint reshaped(EndpointShape newShape) {
        Endpoint e = new Endpoint(newShape, origin);
        e.mergeFrom(this);
        return e;
    }

    public void mergeFrom(Endpoint other) {
        if (representative == null || (other.succeeded && !succeeded) || (other.reachable && !reachable))
            representative = other.representative;
        count += other.count;
        lastStatus = other.lastStatus;
        for (Integer s : other.statuses) if (statuses.size() < MAX_STATUSES) statuses.add(s);
        reachable |= other.reachable;
        succeeded |= other.succeeded;
        other.errors.forEach((k, v) -> { if (errors.containsKey(k) || errors.size() < MAX_ERRORS) errors.put(k, v); });
    }

    public Endpoint copy() { return reshaped(shape); }
}
