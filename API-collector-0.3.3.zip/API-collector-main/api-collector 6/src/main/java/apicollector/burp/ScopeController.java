package apicollector.burp;

import burp.api.montoya.MontoyaApi;
import burp.api.montoya.http.message.requests.HttpRequest;

import java.util.*;

/**
 * Burp target scope, or a custom host list (one host per line; subdomains match).
 *
 * <p>Custom mode matches against {@code httpService().host()} — the host Burp actually connects
 * to — rather than re-parsing URL strings, so userinfo/fragment tricks cannot confuse it. The host
 * list is copy-on-write, so the per-request check takes no lock.
 */
public final class ScopeController {
    public enum Mode { BURP, CUSTOM }

    private final MontoyaApi api;
    private volatile Mode mode = Mode.BURP;
    private volatile List<String> includeHosts = List.of();

    public ScopeController(MontoyaApi api) { this.api = api; }

    public void setMode(Mode m) { this.mode = m; }

    /** Replace the whole list from a textarea: one host per line, blanks/comments ignored. */
    public void setHosts(String text) {
        LinkedHashSet<String> next = new LinkedHashSet<>();
        if (text != null) {
            for (String raw : text.split("\\R")) {
                String h = normalizeHost(raw);
                if (!h.isEmpty()) next.add(h);
            }
        }
        includeHosts = List.copyOf(next);
    }

    public boolean inScope(HttpRequest req) {
        if (req == null) return false;
        if (mode == Mode.BURP) return api != null && api.scope().isInScope(req.url());
        return hostMatches(req.httpService() == null ? null : req.httpService().host());
    }

    /** Custom-mode host test (exact host or any subdomain of a listed host). */
    boolean hostMatches(String host) {
        if (host == null || host.isEmpty()) return false;
        String h = host.toLowerCase(Locale.ROOT);
        if (h.startsWith("[") && h.endsWith("]")) h = h.substring(1, h.length() - 1);
        for (String inc : includeHosts) if (h.equals(inc) || h.endsWith("." + inc)) return true;
        return false;
    }

    /** Strip scheme, userinfo, port, path. Handles localhost, IPv4, and bracketed IPv6. Used for the pasted list only. */
    static String hostOf(String url) {
        if (url == null) return "";
        String s = url.trim();
        int scheme = s.indexOf("://"); if (scheme >= 0) s = s.substring(scheme + 3);
        else if (s.startsWith("//")) s = s.substring(2);          // scheme-relative ("//client.com")
        for (char stop : new char[]{'/', '?', '#'}) { int i = s.indexOf(stop); if (i >= 0) s = s.substring(0, i); }
        int at = s.lastIndexOf('@');   if (at >= 0)     s = s.substring(at + 1);
        if (s.startsWith("[")) { int c = s.indexOf(']'); return c > 0 ? s.substring(1, c).toLowerCase(Locale.ROOT) : ""; }
        int colon = s.indexOf(':');    if (colon >= 0)  s = s.substring(0, colon);
        return s.toLowerCase(Locale.ROOT);
    }
    private static String normalizeHost(String line) {
        String s = line.trim();
        if (s.isEmpty() || s.startsWith("#")) return "";
        return hostOf(s.contains("://") ? s : "//" + s); // tolerate pasted full URLs too
    }
}
