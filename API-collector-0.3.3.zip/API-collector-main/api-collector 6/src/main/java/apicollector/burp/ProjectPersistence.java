package apicollector.burp;

import apicollector.core.CaptureStore;
import apicollector.core.StateCodec;
import apicollector.export.Json;
import burp.api.montoya.MontoyaApi;
import burp.api.montoya.core.ByteArray;
import burp.api.montoya.persistence.PersistedObject;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;

/**
 * Keeps an engagement across Burp restarts and extension reloads.
 *
 * <ul>
 *   <li>Captured state (endpoints, known values, coverage, imported list, loaded collection,
 *       history fingerprints) — gzipped into the Burp <b>project file</b> via {@code extensionData()}.</li>
 *   <li>Per-engagement settings (scope, capture sources, base URL override, collection name) —
 *       also in the project.</li>
 *   <li>Personal preferences (placeholder formats, export format, auto-fill tools, toggles) — in
 *       Burp's user {@code preferences()}, so they follow you to new projects.</li>
 * </ul>
 * Saved every {@link #SAVE_INTERVAL_SECONDS}s when something changed, and once more on unload.
 * In Burp Community (temporary projects only) state lasts until Burp closes.
 */
public final class ProjectPersistence {
    static final String STATE = "apicollector.state.v1";
    static final String PROJECT_SETTINGS = "apicollector.projectSettings.v1";
    static final String PREFERENCES = "apicollector.preferences.v1";
    static final int SAVE_INTERVAL_SECONDS = 30;

    private final MontoyaApi api;
    private final CaptureStore store;
    private ScheduledExecutorService scheduler;
    private Supplier<Map<String, String>> projectSettings = Map::of, preferences = Map::of;
    private long savedVersion = Long.MIN_VALUE;
    private Map<String, String> savedProject, savedPrefs;

    public ProjectPersistence(MontoyaApi api, CaptureStore store) { this.api = api; this.store = store; }

    private PersistedObject data() { return api.persistence().extensionData(); }

    /** Restore captured state from the project. Returns false when there was nothing (or it was unreadable). */
    public boolean restoreState() {
        try {
            ByteArray b = data().getByteArray(STATE);
            if (b == null || b.length() == 0) return false;
            StateCodec.load(store, b.getBytes());
            savedVersion = store.version();
            return true;
        } catch (Exception e) {
            api.logging().logToError("API Collector: could not restore saved state (starting fresh)", e);
            return false;
        }
    }

    public Map<String, String> loadProjectSettings() { return decode(read(() -> data().getString(PROJECT_SETTINGS))); }
    public Map<String, String> loadPreferences() { return decode(read(() -> api.persistence().preferences().getString(PREFERENCES))); }

    /** Begin periodic saving. The suppliers must be cheap and thread-safe (the UI hands out cached copies). */
    public synchronized void start(Supplier<Map<String, String>> projectSettings, Supplier<Map<String, String>> preferences) {
        this.projectSettings = projectSettings;
        this.preferences = preferences;
        scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "api-collector-save"); t.setDaemon(true); return t;
        });
        scheduler.scheduleWithFixedDelay(this::saveIfChanged, SAVE_INTERVAL_SECONDS, SAVE_INTERVAL_SECONDS, TimeUnit.SECONDS);
    }

    /** Stop the timer and save one last time. */
    public void stop() {
        ScheduledExecutorService s;
        synchronized (this) { s = scheduler; scheduler = null; }
        if (s != null) s.shutdownNow();
        saveIfChanged();
    }

    public synchronized void saveIfChanged() {
        try {
            long v = store.version();
            if (v != savedVersion) {
                byte[] bytes = StateCodec.save(store);
                data().setByteArray(STATE, ByteArray.byteArray(bytes));
                savedVersion = v;
            }
            Map<String, String> p = projectSettings.get();
            if (!p.equals(savedProject)) { data().setString(PROJECT_SETTINGS, Json.write(p)); savedProject = p; }
            Map<String, String> q = preferences.get();
            if (!q.equals(savedPrefs)) { api.persistence().preferences().setString(PREFERENCES, Json.write(q)); savedPrefs = q; }
        } catch (Exception e) {
            api.logging().logToError("API Collector: saving state failed", e);
        }
    }

    private String read(Supplier<String> s) {
        try { return s.get(); } catch (Exception e) { return null; }
    }
    private static Map<String, String> decode(String json) {
        Map<String, String> out = new LinkedHashMap<>();
        if (json == null || json.isBlank()) return out;
        try { Json.readObject(json).forEach((k, v) -> { if (v != null) out.put(k, String.valueOf(v)); }); }
        catch (RuntimeException ignore) { /* corrupt settings: use defaults */ }
        return out;
    }
}
