plugins {
    java
    id("com.gradleup.shadow") version "8.3.5"   // maintained successor of com.github.johnrengelman.shadow
}

group = "apicollector"
version = "0.3.3"

java {
    toolchain { languageVersion = JavaLanguageVersion.of(21) }
}

repositories { mavenCentral() }

dependencies {
    compileOnly("net.portswigger.burp.extensions:montoya-api:2025.10")

    // Bundled into the extension jar (Burp does not provide these):
    implementation("org.yaml:snakeyaml:2.3")                 // OpenAPI/Swagger YAML import (SafeConstructor)
    implementation("org.apache.poi:poi-ooxml:5.4.1")         // Excel .xlsx import — 5.4.0+ fixes CVE-2025-31672

    testImplementation("net.portswigger.burp.extensions:montoya-api:2025.10")   // compileOnly is not on the test classpath
    testImplementation(platform("org.junit:junit-bom:5.10.2"))
    testImplementation("org.junit.jupiter:junit-jupiter")
    testRuntimeOnly("org.junit.platform:junit-platform-launcher")
}

tasks.test { useJUnitPlatform() }

tasks.shadowJar {
    archiveBaseName.set("api-collector")
    archiveClassifier.set("")   // produce api-collector.jar (no "-all" suffix)
    mergeServiceFiles()
    // Relocate bundled libraries so they can never clash with another extension's (or Burp's) copy.
    // POI / XMLBeans / log4j-api are left in place: they locate resources and providers by class name.
    val shaded = "apicollector.shaded"
    relocate("org.yaml.snakeyaml", "$shaded.snakeyaml")
    relocate("org.apache.commons.io", "$shaded.commons.io")
    relocate("org.apache.commons.compress", "$shaded.commons.compress")
    relocate("org.apache.commons.codec", "$shaded.commons.codec")
    relocate("org.apache.commons.collections4", "$shaded.commons.collections4")
    relocate("org.apache.commons.math3", "$shaded.commons.math3")
}

// Make `jar` build the fat jar, so ./gradlew jar or build both give a loadable extension.
tasks.jar { enabled = false }
tasks.build { dependsOn(tasks.shadowJar) }
